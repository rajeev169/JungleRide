using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.SceneManagement;

/// <summary>
/// The whole game starts here. The scene only contains one object with this script;
/// camera, light, jungle, bike and UI are all created from code.
/// </summary>
public class GameBootstrap : MonoBehaviour
{
    enum State { Menu, Countdown, Playing, Paused, Result }

    const int EndlessLives = 3;
    static readonly Color FogColor = new Color(0.6f, 0.72f, 0.56f);

    State state;
    Camera cam;
    CameraFollow camFollow;
    BikeInput input;
    BikeController bike;
    TrackBuilder builder;
    TrailPath path;
    GameUI ui;

    GameMode mode;
    int level = 1;
    TrackConfig cfg;
    readonly List<int> checkpoints = new List<int>();
    int nextCheckpoint;
    int progressIdx;
    int respawnIdx;
    int crashes;
    float raceTime;
    float countdownLeft;
    float distance;
    float crashCooldown;

    /// <summary>
    /// Starts the game even if the build used a different scene (for example a scene made by a
    /// build workflow): the scene's own objects are switched off and the game builds itself.
    /// </summary>
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    static void AutoStart()
    {
#if UNITY_2023_1_OR_NEWER
        if (FindAnyObjectByType<GameBootstrap>() != null) return;
#else
        if (FindObjectOfType<GameBootstrap>() != null) return;
#endif
        foreach (var go in SceneManager.GetActiveScene().GetRootGameObjects())
            go.SetActive(false);
        new GameObject("Game").AddComponent<GameBootstrap>();
    }

    void Awake()
    {
        Application.targetFrameRate = 60;
        Screen.sleepTimeout = SleepTimeout.NeverSleep;
        Screen.orientation = ScreenOrientation.LandscapeLeft;
        Time.timeScale = 1f;

        SetupWorld();

        input = new GameObject("BikeInput").AddComponent<BikeInput>();
        ui = GameUI.Create(input);
        bike = BikeController.Create(input);
        builder = new GameObject("Jungle").AddComponent<TrackBuilder>();
        camFollow.target = bike.transform;

        ui.OnTrailRace = () => StartRun(GameMode.TrailRace, 1);
        ui.OnEndless = () => StartRun(GameMode.Endless, 1);
        ui.OnLevel = l => StartRun(GameMode.Levels, l);
        ui.OnPause = Pause;
        ui.OnResume = Resume;
        ui.OnRestart = () => StartRun(mode, level);
        ui.OnMainMenu = GoToMenu;
        ui.OnNextLevel = () => StartRun(GameMode.Levels, Mathf.Min(level + 1, TrackConfig.LevelCount));
        ui.OnControlsChanged = () => { if (GameSettings.Control == ControlMode.Tilt) input.CalibrateTilt(); };

        GoToMenu();
    }

    void SetupWorld()
    {
        RenderSettings.fog = true;
        RenderSettings.fogMode = FogMode.Exponential;
        RenderSettings.fogDensity = 0.012f;
        RenderSettings.fogColor = FogColor;
        RenderSettings.ambientMode = AmbientMode.Trilight;
        RenderSettings.ambientSkyColor = new Color(0.62f, 0.72f, 0.62f);
        RenderSettings.ambientEquatorColor = new Color(0.42f, 0.5f, 0.36f);
        RenderSettings.ambientGroundColor = new Color(0.2f, 0.22f, 0.15f);
        RenderSettings.skybox = null;
        QualitySettings.shadowDistance = 60f;

        var camGo = new GameObject("Main Camera");
        camGo.tag = "MainCamera";
        cam = camGo.AddComponent<Camera>();
        cam.clearFlags = CameraClearFlags.SolidColor;
        cam.backgroundColor = FogColor;
        cam.fieldOfView = 62f;
        cam.nearClipPlane = 0.2f;
        cam.farClipPlane = 260f;
        camGo.AddComponent<AudioListener>();
        camFollow = camGo.AddComponent<CameraFollow>();

        var sun = new GameObject("Sun").AddComponent<Light>();
        sun.type = LightType.Directional;
        sun.transform.rotation = Quaternion.Euler(48f, -35f, 0f);
        sun.color = new Color(1f, 0.95f, 0.85f);
        sun.intensity = 1.15f;
        sun.shadows = LightShadows.Soft;
        sun.shadowStrength = 0.7f;
        RenderSettings.sun = sun;
    }

    // ------------------------------------------------------------------ flow
    void GoToMenu()
    {
        Time.timeScale = 1f;
        state = State.Menu;
        // show the first trail behind the menu, with the camera circling the bike
        Prepare(TrackConfig.TrailRace());
        bike.SetFrozen(true);
        input.InputActive = false;
        camFollow.orbit = true;
        ui.ShowMenu();
    }

    void StartRun(GameMode newMode, int newLevel)
    {
        Time.timeScale = 1f;
        mode = newMode;
        level = newLevel;
        switch (mode)
        {
            case GameMode.Endless: cfg = TrackConfig.Endless(); break;
            case GameMode.Levels: cfg = TrackConfig.Level(level); break;
            default: cfg = TrackConfig.TrailRace(); break;
        }
        Prepare(cfg);
        crashes = 0;
        raceTime = 0f;
        distance = 0f;
        countdownLeft = 3f;
        state = State.Countdown;
        bike.SetFrozen(true);
        input.InputActive = false;
        camFollow.orbit = false;
        camFollow.SnapBehind();
        ui.ShowHud();
        ui.SetHud(InfoText(), 0f);
    }

    void Prepare(TrackConfig config)
    {
        cfg = config;
        path = new TrailPath(cfg);
        checkpoints.Clear();
        int every = Mathf.Max(10, Mathf.RoundToInt(cfg.checkpointEvery / TrailPath.SegLen));
        int limit = cfg.endless ? 0 : path.FinishIndex - 10;
        if (!cfg.endless)
            for (int i = TrailPath.StartIndex + every; i < limit; i += every) checkpoints.Add(i);
        nextCheckpoint = 0;
        builder.Init(path, checkpoints);
        respawnIdx = TrailPath.StartIndex;
        progressIdx = TrailPath.StartIndex;
        PlaceBike(TrailPath.StartIndex);
    }

    void PlaceBike(int idx)
    {
        builder.UpdateAround(idx);
        Vector3 p = path.Point(idx) + Vector3.up * (BikeController.AxleHeight + 0.25f);
        bike.Respawn(p, Quaternion.LookRotation(path.Forward(idx), Vector3.up));
        progressIdx = idx;
        crashCooldown = 1.5f;
    }

    void Pause()
    {
        if (state != State.Playing && state != State.Countdown) return;
        state = State.Paused;
        Time.timeScale = 0f;
        ui.ShowPause();
    }

    void Resume()
    {
        if (state != State.Paused) return;
        ui.HidePause();
        Time.timeScale = 1f;
        state = countdownLeft > 0f ? State.Countdown : State.Playing;
        if (GameSettings.Control == ControlMode.Tilt) input.CalibrateTilt();
    }

    // ------------------------------------------------------------------ loop
    void Update()
    {
        switch (state)
        {
            case State.Countdown: UpdateCountdown(); break;
            case State.Playing: UpdatePlaying(); break;
        }
    }

    void UpdateCountdown()
    {
        countdownLeft -= Time.deltaTime;
        if (countdownLeft > 0f)
        {
            ui.SetCountdown(Mathf.CeilToInt(countdownLeft).ToString());
            return;
        }
        ui.SetCountdown("");
        ui.Toast("GO!", 1f);
        state = State.Playing;
        bike.SetFrozen(false);
        input.InputActive = true;
        input.CalibrateTilt();
    }

    void UpdatePlaying()
    {
        raceTime += Time.deltaTime;
        crashCooldown -= Time.deltaTime;

        Vector3 pos = bike.transform.position;
        progressIdx = path.ClosestIndex(pos, progressIdx);
        builder.UpdateAround(progressIdx);
        distance = Mathf.Max(distance, (progressIdx - TrailPath.StartIndex) * TrailPath.SegLen);

        // checkpoints
        if (nextCheckpoint < checkpoints.Count && progressIdx >= checkpoints[nextCheckpoint])
        {
            respawnIdx = checkpoints[nextCheckpoint];
            nextCheckpoint++;
            ui.Toast("CHECKPOINT " + nextCheckpoint + "/" + checkpoints.Count);
        }

        // finish
        if (!cfg.endless && progressIdx >= path.FinishIndex)
        {
            Finish();
            return;
        }

        // crash / fell off / left the trail
        float lateral = path.LateralOffset(pos, progressIdx);
        bool fell = pos.y < path.Point(progressIdx).y - 12f;
        bool lost = Mathf.Abs(lateral) > 28f;
        if (crashCooldown <= 0f && (bike.Crashed || fell || lost))
        {
            OnCrash();
            return;
        }

        ui.SetHud(InfoText(), bike.SpeedKmh);
    }

    string InfoText()
    {
        switch (mode)
        {
            case GameMode.Endless:
                return Mathf.FloorToInt(distance) + " m\nLives: " + Mathf.Max(0, EndlessLives - crashes);
            case GameMode.Levels:
                return "Level " + level + "   " + GameSettings.FormatTime(raceTime) + "\n" + Mathf.FloorToInt(distance) + " / " + Mathf.RoundToInt(cfg.length) + " m";
            default:
                return "Time " + GameSettings.FormatTime(raceTime) + "\n" + Mathf.FloorToInt(distance) + " / " + Mathf.RoundToInt(cfg.length) + " m";
        }
    }

    void OnCrash()
    {
        crashes++;
        if (mode == GameMode.Endless)
        {
            if (crashes >= EndlessLives)
            {
                EndEndless();
                return;
            }
            ui.Toast("CRASH!  " + (EndlessLives - crashes) + " left");
            PlaceBike(Mathf.Max(TrailPath.StartIndex, progressIdx - 1));
        }
        else
        {
            ui.Toast("CRASH! Back to checkpoint");
            PlaceBike(respawnIdx);
        }
    }

    void Finish()
    {
        state = State.Result;
        bike.SetFrozen(true);
        input.InputActive = false;
        string body;
        bool next = false;
        if (mode == GameMode.Levels)
        {
            float best = GameSettings.BestLevelTime(level);
            bool record = best <= 0f || raceTime < best;
            if (record) GameSettings.SetBestLevelTime(level, raceTime);
            if (level < TrackConfig.LevelCount)
            {
                GameSettings.LevelsUnlocked = Mathf.Max(GameSettings.LevelsUnlocked, level + 1);
                next = true;
            }
            body = "Time: " + GameSettings.FormatTime(raceTime) + (record ? "   NEW BEST!" : "   Best: " + GameSettings.FormatTime(best))
                 + "\nCrashes: " + crashes
                 + (level < TrackConfig.LevelCount ? "\nLevel " + (level + 1) + " unlocked!" : "\nAll levels complete!");
            ui.ShowResult("LEVEL " + level + " DONE!", body, next);
        }
        else
        {
            float best = GameSettings.BestTrailTime;
            bool record = best <= 0f || raceTime < best;
            if (record) GameSettings.BestTrailTime = raceTime;
            body = "Time: " + GameSettings.FormatTime(raceTime) + (record ? "   NEW BEST!" : "   Best: " + GameSettings.FormatTime(best))
                 + "\nCrashes: " + crashes;
            ui.ShowResult("FINISH!", body, false);
        }
    }

    void EndEndless()
    {
        state = State.Result;
        bike.SetFrozen(true);
        input.InputActive = false;
        float best = GameSettings.BestEndless;
        bool record = distance > best;
        if (record) GameSettings.BestEndless = distance;
        string body = "Distance: " + Mathf.FloorToInt(distance) + " m" + (record ? "   NEW BEST!" : "   Best: " + Mathf.FloorToInt(best) + " m")
                    + "\nTime: " + GameSettings.FormatTime(raceTime);
        ui.ShowResult("RIDE OVER", body, false);
    }

    void OnApplicationPause(bool paused)
    {
        if (paused && state == State.Playing) Pause();
    }
}
