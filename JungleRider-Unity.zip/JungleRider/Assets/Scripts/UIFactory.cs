using System;
using UnityEngine;
using UnityEngine.UI;

/// <summary>Small helpers to build the UI from code (no prefabs or image files needed).</summary>
public static class UIFactory
{
    static Font font;
    static Sprite rounded, circle;

    public static readonly Color Green = new Color(0.22f, 0.62f, 0.25f, 0.95f);
    public static readonly Color Dark = new Color(0.05f, 0.1f, 0.06f, 0.82f);
    public static readonly Color Orange = new Color(0.95f, 0.55f, 0.12f, 0.95f);
    public static readonly Color Grey = new Color(0.35f, 0.38f, 0.35f, 0.9f);
    public static readonly Color Red = new Color(0.8f, 0.2f, 0.18f, 0.95f);

    public static Font Font
    {
        get
        {
            if (font == null)
            {
                try { font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf"); } catch { }
                if (font == null) { try { font = Resources.GetBuiltinResource<Font>("Arial.ttf"); } catch { } }
            }
            return font;
        }
    }

    /// <summary>White rounded-rectangle sprite (9-sliced), made in code.</summary>
    public static Sprite Rounded
    {
        get
        {
            if (rounded == null) rounded = MakeSprite(64, 18f, new Vector4(22, 22, 22, 22));
            return rounded;
        }
    }

    public static Sprite Circle
    {
        get
        {
            if (circle == null) circle = MakeSprite(128, 64f, Vector4.zero);
            return circle;
        }
    }

    static Sprite MakeSprite(int size, float radius, Vector4 border)
    {
        var tex = new Texture2D(size, size, TextureFormat.RGBA32, false) { wrapMode = TextureWrapMode.Clamp, filterMode = FilterMode.Bilinear };
        var px = new Color32[size * size];
        for (int y = 0; y < size; y++)
            for (int x = 0; x < size; x++)
            {
                float cx = Mathf.Clamp(x + 0.5f, radius, size - radius);
                float cy = Mathf.Clamp(y + 0.5f, radius, size - radius);
                float d = Vector2.Distance(new Vector2(x + 0.5f, y + 0.5f), new Vector2(cx, cy));
                byte a = (byte)(Mathf.Clamp01(radius - d + 0.5f) * 255f);
                px[y * size + x] = new Color32(255, 255, 255, a);
            }
        tex.SetPixels32(px);
        tex.Apply();
        return Sprite.Create(tex, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), 100f, 0, SpriteMeshType.FullRect, border);
    }

    public static RectTransform MakeRect(string name, Transform parent, Vector2 anchor, Vector2 pos, Vector2 size)
    {
        var go = new GameObject(name, typeof(RectTransform));
        var rt = (RectTransform)go.transform;
        rt.SetParent(parent, false);
        rt.anchorMin = rt.anchorMax = anchor;
        rt.pivot = new Vector2(0.5f, 0.5f);
        rt.anchoredPosition = pos;
        rt.sizeDelta = size;
        return rt;
    }

    public static RectTransform Stretch(string name, Transform parent)
    {
        var go = new GameObject(name, typeof(RectTransform));
        var rt = (RectTransform)go.transform;
        rt.SetParent(parent, false);
        rt.anchorMin = Vector2.zero;
        rt.anchorMax = Vector2.one;
        rt.offsetMin = rt.offsetMax = Vector2.zero;
        return rt;
    }

    public static Image Panel(string name, Transform parent, Vector2 anchor, Vector2 pos, Vector2 size, Color color)
    {
        var rt = MakeRect(name, parent, anchor, pos, size);
        var img = rt.gameObject.AddComponent<Image>();
        img.sprite = Rounded;
        img.type = Image.Type.Sliced;
        img.color = color;
        return img;
    }

    public static Text Label(Transform parent, string text, int size, TextAnchor align, Color color, Vector2 anchor, Vector2 pos, Vector2 box)
    {
        var rt = MakeRect("Text", parent, anchor, pos, box);
        var t = rt.gameObject.AddComponent<Text>();
        t.font = Font;
        t.text = text;
        t.fontSize = size;
        t.alignment = align;
        t.color = color;
        t.horizontalOverflow = HorizontalWrapMode.Wrap;
        t.verticalOverflow = VerticalWrapMode.Overflow;
        t.raycastTarget = false;
        var sh = rt.gameObject.AddComponent<Shadow>();
        sh.effectColor = new Color(0, 0, 0, 0.6f);
        sh.effectDistance = new Vector2(2, -2);
        return t;
    }

    public static Text FillLabel(Transform parent, string text, int size, Color color)
    {
        var rt = Stretch("Text", parent);
        var t = rt.gameObject.AddComponent<Text>();
        t.font = Font;
        t.text = text;
        t.fontSize = size;
        t.alignment = TextAnchor.MiddleCenter;
        t.color = color;
        t.raycastTarget = false;
        return t;
    }

    public static Button MakeButton(Transform parent, string text, Vector2 anchor, Vector2 pos, Vector2 size, Color color, Action onClick, int fontSize = 44)
    {
        var img = Panel("Button " + text, parent, anchor, pos, size, color);
        var b = img.gameObject.AddComponent<Button>();
        b.targetGraphic = img;
        var colors = b.colors;
        colors.highlightedColor = new Color(1f, 1f, 1f, 1f);
        colors.pressedColor = new Color(0.75f, 0.75f, 0.75f, 1f);
        b.colors = colors;
        if (onClick != null) b.onClick.AddListener(() => onClick());
        FillLabel(img.transform, text, fontSize, Color.white);
        return b;
    }

    public static HoldButton MakeHoldButton(Transform parent, string text, Vector2 anchor, Vector2 pos, Vector2 size, Color color, int fontSize = 48)
    {
        var img = Panel("Hold " + text, parent, anchor, pos, size, color);
        FillLabel(img.transform, text, fontSize, Color.white);
        return img.gameObject.AddComponent<HoldButton>(); // added after the colour is set (it remembers it)
    }

    public static void SetButtonText(Button b, string text)
    {
        var t = b.GetComponentInChildren<Text>();
        if (t) t.text = text;
    }
}
