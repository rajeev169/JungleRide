using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

/// <summary>On-screen button that reports whether it is being held down.</summary>
public class HoldButton : MonoBehaviour, IPointerDownHandler, IPointerUpHandler, IPointerExitHandler, IPointerEnterHandler
{
    public bool Pressed { get; private set; }
    Image image;
    Color normal;

    void Awake()
    {
        image = GetComponent<Image>();
        if (image) normal = image.color;
    }

    void OnDisable() => SetPressed(false);

    public void OnPointerDown(PointerEventData e) => SetPressed(true);
    public void OnPointerUp(PointerEventData e) => SetPressed(false);
    public void OnPointerExit(PointerEventData e) { if (!e.dragging) SetPressed(false); }
    public void OnPointerEnter(PointerEventData e) { if (e.eligibleForClick || e.dragging) SetPressed(true); }

    void SetPressed(bool p)
    {
        Pressed = p;
        if (image) image.color = p ? new Color(normal.r, normal.g, normal.b, Mathf.Min(1f, normal.a + 0.35f)) : normal;
    }
}
