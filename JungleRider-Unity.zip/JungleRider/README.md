# Jungle Rider Offroad (Unity)

Simple jungle offroad cycling game using the TRELLIS rider + bike model (`Assets/Resources/RiderBike.glb`).

## Open and run (PC)
1. Install **Unity Hub** and **Unity 6 LTS (6000.0.x)** with the **Android Build Support** module (with OpenJDK + Android SDK & NDK).
2. Unzip this folder, then Unity Hub → **Add → Add project from disk** → choose the `JungleRider` folder → open it with Unity 6.
3. First open takes a few minutes (it downloads the glTFast and Input System packages).
   If Unity asks to enable the new Input System backends, click **Yes** (Unity restarts).
4. The project sets itself up automatically (scene, build settings, Android settings).
   If anything looks missing: menu **Jungle Rider → Run Project Setup**.
5. Press **Play** to test. Keyboard: arrows / WASD to steer and pedal, Space to brake.

## Build the APK
File → **Build Settings** → **Android** → **Switch Platform** → **Build**.
App name: *Jungle Rider Offroad*, package: `com.appforge.junglerider` (change in Player Settings if you like).

## Game
- **Trail Race** – one 1.2 km jungle trail with ramps and logs; checkpoints, timer, best time.
- **Endless Ride** – the trail never ends and gets harder; 3 lives; best distance.
- **Levels** – 5 levels, each longer and harder; finishing one unlocks the next.
- **Settings** – choose steering: **Buttons**, **Tilt phone** or **Joystick** (+ tilt sensitivity).
  Also reachable from the pause menu during a ride.

## Where things are
| File | What it does |
|---|---|
| `Scripts/GameBootstrap.cs` | Game flow: menu, countdown, race, checkpoints, crashes, results |
| `Scripts/BikeController.cs` | Bike physics (springy wheels, pedal, brake, steering, auto-balance) and model fitting |
| `Scripts/BikeInput.cs` | Buttons / tilt / joystick / keyboard |
| `Scripts/TrailPath.cs` | Trail shape (curves, hills) from a seed |
| `Scripts/TrackBuilder.cs` | Builds ground, trees, bushes, rocks, logs, ramps and gates in 48 m pieces |
| `Scripts/JungleProps.cs` | Low-poly jungle models made in code |
| `Scripts/TrackConfig.cs` | Length / difficulty of Trail Race, Endless and each level |
| `Scripts/GameUI.cs` | Menus, HUD, settings, pause, results |

Tuning: bike speed and handling are at the top of `BikeController.cs`; level difficulty in `TrackConfig.cs`.
If the model ever faces backwards, change `ModelYawOffset` to `180` in `BikeController.cs`.
