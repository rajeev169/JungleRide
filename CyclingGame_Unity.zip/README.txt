SIMPLE DOWNHILL CYCLING GAME (Unity, mobile)

1. Use a 3D Unity project (2021.3 LTS or newer, built-in or URP).
2. To import .glb files: Window > Package Manager > + > Add package by name:
      com.unity.cloud.gltfast
   (skip if your project already imports GLB files)
3. Copy the "CyclingGame" folder into your project's Assets folder.
4. Create Assets/Models and put rider_bike_fixed.glb in it. Wait for it to import.
5. Menu bar: Cycling > Build Game Scene. Then press Play.

Controls: touch left/right side = steer, bottom centre = brake.
Keyboard: A/D or arrows = steer, Space = brake, R = reset.

If you get an InputManager error (Unity 6): Project Settings > Player >
Other Settings > Active Input Handling > set to "Both".

Tweak on the Bike object (BikeController):
- Flip Model: tick if the bike rides backwards
- Model Scale: size of the bike (default 1.7)
- Max Pedal Speed, Brake Strength, Turn Rate: handling
Track settings are on the Track object (slope, length, tree count).

Android: File > Build Settings > Android > Switch Platform > Build And Run.
