#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;

// Menu: Cycling > Build Game Scene
// Creates the scene, materials, track, bike (using rider_bike_fixed.glb if found), camera and HUD.
public static class CyclingGameSetup
{
    const string Root = "Assets/CyclingGame";

    [MenuItem("Cycling/Build Game Scene")]
    public static void Build()
    {
        Directory.CreateDirectory(Root + "/Materials");
        Directory.CreateDirectory(Root + "/Scenes");
        AssetDatabase.Refresh();

        var scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);

        Material trackMat = MakeMat("Track", Color.white);
        Material trunkMat = MakeMat("Trunk", new Color(0.35f, 0.22f, 0.12f));
        Material leafMat = MakeMat("Leaves", new Color(0.12f, 0.45f, 0.15f));

        // Track
        var trackGO = new GameObject("Track");
        var track = trackGO.AddComponent<DownhillTrack>();
        track.trackMaterial = trackMat;
        track.trunkMaterial = trunkMat;
        track.leafMaterial = leafMat;

        // Find the model
        GameObject modelPrefab = null;
        foreach (var guid in AssetDatabase.FindAssets("rider_bike_fixed"))
        {
            var p = AssetDatabase.GUIDToAssetPath(guid);
            var go = AssetDatabase.LoadAssetAtPath<GameObject>(p);
            if (go != null) { modelPrefab = go; break; }
        }

        // Bike
        float startZ = 5f;
        float startX = track.PathX(startZ);
        var bike = new GameObject("Bike");
        bike.transform.position = new Vector3(startX, track.GetHeight(startX, startZ) + 1.2f, startZ);
        var rb = bike.AddComponent<Rigidbody>();
        rb.mass = 80f;
        var sc = bike.AddComponent<SphereCollider>();
        sc.radius = 0.5f;
        var ctrl = bike.AddComponent<BikeController>();

        var visualRoot = new GameObject("VisualRoot");
        visualRoot.transform.SetParent(bike.transform, false);
        visualRoot.transform.localPosition = new Vector3(0f, -0.5f, 0f);
        var modelHolder = new GameObject("Model");
        modelHolder.transform.SetParent(visualRoot.transform, false);

        if (modelPrefab != null)
        {
            PrefabUtility.InstantiatePrefab(modelPrefab, modelHolder.transform);
        }
        else
        {
            Debug.LogWarning("rider_bike_fixed.glb not found (or not imported). Using a placeholder capsule. " +
                             "Install glTFast, put the file in Assets/Models, then run Cycling > Build Game Scene again.");
            var cap = GameObject.CreatePrimitive(PrimitiveType.Capsule);
            cap.transform.SetParent(modelHolder.transform, false);
            cap.transform.localScale = new Vector3(0.4f, 0.8f, 0.4f);
            cap.transform.localRotation = Quaternion.Euler(90f, 0f, 0f);
            Object.DestroyImmediate(cap.GetComponent<Collider>());
        }
        ctrl.visualRoot = visualRoot.transform;
        ctrl.model = modelHolder.transform;

        // Camera
        var cam = Camera.main;
        cam.clearFlags = CameraClearFlags.SolidColor;
        cam.backgroundColor = new Color(0.62f, 0.78f, 0.92f);
        cam.farClipPlane = 400f;
        var fc = cam.gameObject.AddComponent<FollowCamera>();
        fc.target = bike.transform;
        cam.transform.position = bike.transform.position + new Vector3(0f, 3f, -6f);

        // Light and fog (cheap for mobile)
        var lightGO = GameObject.Find("Directional Light");
        if (lightGO != null) lightGO.GetComponent<Light>().shadows = LightShadows.None;
        RenderSettings.fog = true;
        RenderSettings.fogMode = FogMode.Linear;
        RenderSettings.fogColor = cam.backgroundColor;
        RenderSettings.fogStartDistance = 60f;
        RenderSettings.fogEndDistance = 300f;

        // HUD
        var hudGO = new GameObject("GameHud");
        var hud = hudGO.AddComponent<GameHud>();
        hud.bike = ctrl;
        hud.finishZ = track.length - 20f;

        // Save scene + build settings
        string scenePath = Root + "/Scenes/Downhill.unity";
        EditorSceneManager.SaveScene(scene, scenePath);
        EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(scenePath, true) };
        PlayerSettings.defaultInterfaceOrientation = UIOrientation.LandscapeLeft;

        Debug.Log("Cycling game scene built: " + scenePath + ". Press Play.");
    }

    static Material MakeMat(string name, Color c)
    {
        var rp = GraphicsSettings.currentRenderPipeline;
        Shader sh = (rp != null && rp.defaultShader != null) ? rp.defaultShader : Shader.Find("Standard");
        var m = new Material(sh);
        m.color = c;
        string path = Root + "/Materials/" + name + ".mat";
        AssetDatabase.DeleteAsset(path);
        AssetDatabase.CreateAsset(m, path);
        return AssetDatabase.LoadAssetAtPath<Material>(path);
    }
}
#endif
