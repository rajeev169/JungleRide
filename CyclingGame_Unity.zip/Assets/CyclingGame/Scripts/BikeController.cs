using UnityEngine;

// Simple arcade downhill bike. Rolls down the slope with gravity, auto-pedals gently,
// steers with left/right touch (or A/D, arrows), brakes with bottom-centre touch (or Space).
[RequireComponent(typeof(Rigidbody))]
public class BikeController : MonoBehaviour
{
    [Header("Model (filled in by the setup tool)")]
    public Transform visualRoot;
    public Transform model;
    public float modelScale = 1.7f;
    [Tooltip("Tick this if the bike rides backwards.")]
    public bool flipModel = false;

    [Header("Riding")]
    public float pedalAccel = 4f;
    public float maxPedalSpeed = 9f;
    public float brakeStrength = 3.5f;
    public float turnRate = 75f;
    public float sideGrip = 8f;
    public float dragCoef = 0.02f;
    public float leanAngle = 22f;
    public float wheelRadius = 0.5f;

    Rigidbody rb;
    float yaw, steerTarget, steerSmooth, lean, startYaw;
    bool braking, grounded;
    Vector3 groundNormal = Vector3.up;
    Vector3 startPos;

    public float Speed { get { return Vel.magnitude; } }

    Vector3 Vel
    {
        get
        {
#if UNITY_6000_0_OR_NEWER
            return rb.linearVelocity;
#else
            return rb.velocity;
#endif
        }
        set
        {
#if UNITY_6000_0_OR_NEWER
            rb.linearVelocity = value;
#else
            rb.velocity = value;
#endif
        }
    }

    void Awake()
    {
        rb = GetComponent<Rigidbody>();
        rb.constraints = RigidbodyConstraints.FreezeRotation;
        rb.interpolation = RigidbodyInterpolation.Interpolate;
        rb.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;

        // Frictionless collider so the bike slides smoothly; grip is handled in code.
        var sc = GetComponent<SphereCollider>();
        if (sc != null)
        {
#if UNITY_6000_0_OR_NEWER
            var pm = new PhysicsMaterial("BikeSlip");
            pm.frictionCombine = PhysicsMaterialCombine.Minimum;
#else
            var pm = new PhysicMaterial("BikeSlip");
            pm.frictionCombine = PhysicMaterialCombine.Minimum;
#endif
            pm.dynamicFriction = 0f;
            pm.staticFriction = 0f;
            sc.sharedMaterial = pm;
        }
    }

    void Start()
    {
        startPos = transform.position;
        startYaw = transform.eulerAngles.y;
        yaw = startYaw;
        FitModel();
    }

    // Scales the model, centres it on the bike and puts its wheels on the ground contact point.
    void FitModel()
    {
        if (model == null || visualRoot == null) return;
        model.localScale = Vector3.one * modelScale;
        model.localRotation = Quaternion.Euler(0f, flipModel ? 180f : 0f, 0f);
        model.localPosition = Vector3.zero;

        var rends = model.GetComponentsInChildren<Renderer>();
        if (rends.Length == 0) return;
        Bounds b = rends[0].bounds;
        for (int i = 1; i < rends.Length; i++) b.Encapsulate(rends[i].bounds);

        Vector3 target = visualRoot.position;
        model.position += new Vector3(target.x - b.center.x, target.y - b.min.y, target.z - b.center.z);
    }

    void Update()
    {
        ReadInput();
        if (Input.GetKeyDown(KeyCode.R)) ResetToStart();
        UpdateVisual();
    }

    void ReadInput()
    {
        float s = Input.GetAxisRaw("Horizontal");
        bool b = Input.GetKey(KeyCode.Space) || Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.DownArrow);

        for (int i = 0; i < Input.touchCount; i++)
        {
            Vector2 p = Input.GetTouch(i).position;
            if (p.x > Screen.width * 0.82f && p.y > Screen.height * 0.78f) continue; // reset button area
            float x = p.x / Screen.width;
            float y = p.y / Screen.height;
            if (x < 0.4f) s -= 1f;
            else if (x > 0.6f) s += 1f;
            else if (y < 0.4f) b = true;
        }

        steerTarget = Mathf.Clamp(s, -1f, 1f);
        braking = b;
        steerSmooth = Mathf.MoveTowards(steerSmooth, steerTarget, 5f * Time.deltaTime);
    }

    void UpdateVisual()
    {
        if (visualRoot == null) return;
        float speedFactor = Mathf.Clamp01(Speed / 6f);
        lean = Mathf.Lerp(lean, -steerSmooth * leanAngle * speedFactor, 6f * Time.deltaTime);

        Vector3 fwd = Vector3.ProjectOnPlane(Quaternion.Euler(0f, yaw, 0f) * Vector3.forward, groundNormal).normalized;
        if (fwd.sqrMagnitude < 0.01f) fwd = transform.forward;
        Quaternion target = Quaternion.LookRotation(fwd, groundNormal) * Quaternion.Euler(0f, 0f, lean);
        visualRoot.rotation = Quaternion.Slerp(visualRoot.rotation, target, 10f * Time.deltaTime);
    }

    void FixedUpdate()
    {
        float dt = Time.fixedDeltaTime;
        Vector3 v = Vel;
        float speed = v.magnitude;

        // Steering
        float steerFactor = Mathf.Clamp(speed / 3f, 0.25f, 1f);
        yaw += steerSmooth * turnRate * steerFactor * dt;
        rb.rotation = Quaternion.Euler(0f, yaw, 0f);

        // Ground detection
        RaycastHit hit;
        grounded = Physics.Raycast(transform.position, Vector3.down, out hit, wheelRadius + 0.4f, ~0, QueryTriggerInteraction.Ignore);
        Vector3 n = grounded ? hit.normal : Vector3.up;
        groundNormal = Vector3.Slerp(groundNormal, n, 8f * dt).normalized;

        Vector3 heading = Quaternion.Euler(0f, yaw, 0f) * Vector3.forward;
        Vector3 fwd = Vector3.ProjectOnPlane(heading, n).normalized;
        Vector3 right = Vector3.Cross(n, fwd).normalized;

        if (grounded)
        {
            float fwdSpeed = Vector3.Dot(v, fwd);
            if (!braking && fwdSpeed < maxPedalSpeed)
                rb.AddForce(fwd * pedalAccel, ForceMode.Acceleration);

            if (braking)
                rb.AddForce(-v * brakeStrength, ForceMode.Acceleration);

            // Side grip: kills sideways sliding so the bike follows where it points.
            float lateral = Vector3.Dot(v, right);
            rb.AddForce(-right * lateral * sideGrip, ForceMode.Acceleration);

            // Keep the bike stuck to the ground over bumps.
            rb.AddForce(-n * 6f, ForceMode.Acceleration);
        }

        // Air / rolling resistance (also sets a natural top speed)
        rb.AddForce(-v * speed * dragCoef, ForceMode.Acceleration);

        // Fell off the track? Go back to the start.
        var track = DownhillTrack.Instance;
        if (track != null)
        {
            Vector3 p = transform.position;
            if (p.y < track.GetHeight(p.x, p.z) - 8f || p.z > track.length + 8f)
                ResetToStart();
        }
    }

    public void ResetToStart()
    {
        rb.position = startPos;
        Vel = Vector3.zero;
        rb.angularVelocity = Vector3.zero;
        yaw = startYaw;
        steerSmooth = 0f;
    }
}
