using UnityEngine;

public class FollowCamera : MonoBehaviour
{
    public Transform target;
    public float distance = 6f;
    public float height = 3f;
    public float lookHeight = 1.2f;
    public float followSpeed = 5f;
    public float headingSpeed = 3f;

    Vector3 heading = Vector3.forward;

    void LateUpdate()
    {
        if (target == null) return;
        float dt = Time.deltaTime;

        Vector3 fwd = target.forward; fwd.y = 0f;
        if (fwd.sqrMagnitude > 0.001f) fwd.Normalize();
        heading = Vector3.Slerp(heading, fwd, headingSpeed * dt).normalized;

        Vector3 desired = target.position - heading * distance + Vector3.up * height;
        var track = DownhillTrack.Instance;
        if (track != null)
        {
            float ground = track.GetHeight(desired.x, desired.z) + 1f;
            if (desired.y < ground) desired.y = ground;
        }

        transform.position = Vector3.Lerp(transform.position, desired, followSpeed * dt);
        Vector3 look = target.position + Vector3.up * lookHeight - transform.position;
        if (look.sqrMagnitude > 0.001f)
            transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(look), 8f * dt);
    }
}
