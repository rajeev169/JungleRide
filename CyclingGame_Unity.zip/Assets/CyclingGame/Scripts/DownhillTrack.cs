using UnityEngine;

// Builds a winding downhill forest trail at runtime: smooth dirt path, bumpy sides,
// banked walls, trees and a finish arch. Everything is generated from the settings below.
public class DownhillTrack : MonoBehaviour
{
    public static DownhillTrack Instance;

    public Material trackMaterial;
    public Material trunkMaterial;
    public Material leafMaterial;

    public float length = 800f;
    public float halfWidth = 30f;
    public float cell = 2f;
    public float slope = 0.22f;
    public float bumpHeight = 3f;
    public float wallHeight = 14f;
    public float seed = 17.3f;
    public int treeCount = 160;

    void Awake()
    {
        Instance = this;
        BuildMesh();
        BuildTrees();
        BuildFinish();
    }

    public float PathX(float z)
    {
        return Mathf.Sin(z * 0.012f) * 10f + Mathf.Sin(z * 0.031f) * 4f;
    }

    public float GetHeight(float x, float z)
    {
        float d = Mathf.Abs(x - PathX(z));
        float baseH = -z * slope;
        float rough = Mathf.PerlinNoise(x * 0.08f + seed, z * 0.08f + seed) * bumpHeight;
        float trailBumps = Mathf.PerlinNoise(z * 0.15f + seed, 3.3f) * 0.25f;
        float blend = Mathf.SmoothStep(0f, 1f, (d - 4f) / 8f);
        float wallT = Mathf.Clamp01((d - 14f) / Mathf.Max(1f, halfWidth - 14f));
        return baseH + Mathf.Lerp(trailBumps, rough, blend) + wallT * wallT * wallHeight;
    }

    void BuildMesh()
    {
        int cols = Mathf.RoundToInt(halfWidth * 2f / cell) + 1;
        int rows = Mathf.RoundToInt(length / cell) + 1;
        var verts = new Vector3[cols * rows];
        var uvs = new Vector2[cols * rows];
        for (int j = 0; j < rows; j++)
        {
            float z = j * cell;
            float px = PathX(z);
            for (int i = 0; i < cols; i++)
            {
                float off = -halfWidth + i * cell;
                float x = px + off;
                int k = j * cols + i;
                verts[k] = new Vector3(x, GetHeight(x, z), z);
                uvs[k] = new Vector2((off + halfWidth) / (2f * halfWidth), z * 0.05f);
            }
        }

        var tris = new int[(cols - 1) * (rows - 1) * 6];
        int t = 0;
        for (int j = 0; j < rows - 1; j++)
        {
            for (int i = 0; i < cols - 1; i++)
            {
                int i0 = j * cols + i, i1 = i0 + 1, i2 = i0 + cols, i3 = i2 + 1;
                tris[t++] = i0; tris[t++] = i2; tris[t++] = i1;
                tris[t++] = i1; tris[t++] = i2; tris[t++] = i3;
            }
        }

        var mesh = new Mesh();
        mesh.name = "TrackMesh";
        mesh.indexFormat = UnityEngine.Rendering.IndexFormat.UInt32;
        mesh.vertices = verts;
        mesh.uv = uvs;
        mesh.triangles = tris;
        mesh.RecalculateNormals();
        mesh.RecalculateBounds();

        var go = new GameObject("TrackMesh");
        go.transform.SetParent(transform, false);
        go.AddComponent<MeshFilter>().sharedMesh = mesh;
        var mr = go.AddComponent<MeshRenderer>();
        go.AddComponent<MeshCollider>().sharedMesh = mesh;

        // Dirt in the middle fading to grass on the sides
        var tex = new Texture2D(256, 1, TextureFormat.RGBA32, false);
        tex.wrapMode = TextureWrapMode.Clamp;
        Color dirt = new Color(0.45f, 0.32f, 0.2f);
        Color grass = new Color(0.22f, 0.45f, 0.18f);
        for (int k = 0; k < 256; k++)
        {
            float off = -halfWidth + (k / 255f) * 2f * halfWidth;
            float f = Mathf.SmoothStep(0f, 1f, (Mathf.Abs(off) - 4f) / 8f);
            tex.SetPixel(k, 0, Color.Lerp(dirt, grass, f));
        }
        tex.Apply();

        Material mat = new Material(trackMaterial);
        mat.mainTexture = tex;
        mr.sharedMaterial = mat;
    }

    void BuildTrees()
    {
        var root = new GameObject("Trees");
        root.transform.SetParent(transform, false);
        var rng = new System.Random(42);
        for (int n = 0; n < treeCount; n++)
        {
            float z = 30f + (float)rng.NextDouble() * (length - 40f);
            float side = rng.NextDouble() < 0.5 ? -1f : 1f;
            float off = side * (9f + (float)rng.NextDouble() * (halfWidth - 14f));
            float x = PathX(z) + off;
            float y = GetHeight(x, z);
            float s = 0.8f + (float)rng.NextDouble() * 0.8f;

            var trunk = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            trunk.transform.SetParent(root.transform, false);
            trunk.transform.position = new Vector3(x, y + 1.5f * s, z);
            trunk.transform.localScale = new Vector3(0.4f * s, 1.5f * s, 0.4f * s);
            trunk.GetComponent<Renderer>().sharedMaterial = trunkMaterial;
            trunk.isStatic = true;

            var leaves = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            leaves.transform.SetParent(root.transform, false);
            leaves.transform.position = new Vector3(x, y + 4.5f * s, z);
            leaves.transform.localScale = new Vector3(3f * s, 4f * s, 3f * s);
            leaves.GetComponent<Renderer>().sharedMaterial = leafMaterial;
            Destroy(leaves.GetComponent<Collider>());
            leaves.isStatic = true;
        }
        StaticBatchingUtility.Combine(root);
    }

    void BuildFinish()
    {
        float z = length - 15f;
        float x = PathX(z);
        float y = GetHeight(x, z);
        var white = new Material(trunkMaterial);
        white.color = Color.white;

        for (int side = -1; side <= 1; side += 2)
        {
            var post = GameObject.CreatePrimitive(PrimitiveType.Cube);
            post.transform.SetParent(transform, false);
            post.transform.position = new Vector3(x + side * 6f, y + 2.5f, z);
            post.transform.localScale = new Vector3(0.5f, 5f, 0.5f);
            post.GetComponent<Renderer>().sharedMaterial = white;
            Destroy(post.GetComponent<Collider>());
        }
        var bar = GameObject.CreatePrimitive(PrimitiveType.Cube);
        bar.transform.SetParent(transform, false);
        bar.transform.position = new Vector3(x, y + 5f, z);
        bar.transform.localScale = new Vector3(12.5f, 0.8f, 0.5f);
        bar.GetComponent<Renderer>().sharedMaterial = white;
        Destroy(bar.GetComponent<Collider>());
    }
}
