using UnityEngine;
using UnityEngine.SceneManagement;

// Speed, timer, touch hints, reset button and finish screen (drawn with OnGUI, no Canvas needed).
public class GameHud : MonoBehaviour
{
    public BikeController bike;
    public float finishZ = 780f;

    float time;
    bool started, finished;
    GUIStyle big, small, center;

    void Update()
    {
        if (bike == null) return;
        if (!started && bike.Speed > 0.5f) started = true;
        if (started && !finished) time += Time.deltaTime;
        if (!finished && bike.transform.position.z > finishZ) finished = true;

        if (finished)
        {
            bool tap = Input.touchCount > 0 && Input.GetTouch(0).phase == TouchPhase.Began;
            if (tap || Input.GetKeyDown(KeyCode.R))
                SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        }
    }

    void OnGUI()
    {
        if (bike == null) return;
        if (big == null)
        {
            big = new GUIStyle(GUI.skin.label) { fontSize = 34, fontStyle = FontStyle.Bold };
            big.normal.textColor = Color.white;
            small = new GUIStyle(GUI.skin.label) { fontSize = 22 };
            small.normal.textColor = new Color(1f, 1f, 1f, 0.55f);
            center = new GUIStyle(GUI.skin.label) { fontSize = 44, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleCenter };
            center.normal.textColor = Color.white;
        }

        float s = Screen.height / 540f;
        GUI.matrix = Matrix4x4.Scale(new Vector3(s, s, 1f));
        float w = Screen.width / s;
        float h = Screen.height / s;

        GUI.Label(new Rect(20, 12, 300, 44), (bike.Speed * 3.6f).ToString("0") + " km/h", big);
        GUI.Label(new Rect(20, 52, 300, 44), time.ToString("0.0") + " s", big);

        if (GUI.Button(new Rect(w - 110, 15, 95, 40), "RESET"))
        {
            bike.ResetToStart();
            time = 0f; started = false; finished = false;
        }

        GUI.Label(new Rect(20, h - 50, 200, 40), "< LEFT", small);
        GUI.Label(new Rect(w - 120, h - 50, 200, 40), "RIGHT >", small);
        GUI.Label(new Rect(w / 2f - 40, h - 50, 200, 40), "BRAKE", small);

        if (finished)
        {
            GUI.Label(new Rect(0, h / 2f - 60, w, 60), "FINISH!  " + time.ToString("0.0") + " s", center);
            GUI.Label(new Rect(0, h / 2f, w, 50), "Tap to ride again", small);
        }
    }
}
