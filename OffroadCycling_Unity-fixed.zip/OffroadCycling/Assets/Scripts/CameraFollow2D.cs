using UnityEngine;

namespace OffroadCycling
{
    [RequireComponent(typeof(Camera))]
    public class CameraFollow2D : MonoBehaviour
    {
        public Rigidbody2D target;
        public Vector2 offset = new Vector2(2f, 1.3f);
        public float smoothTime = 0.18f;
        public float lookAhead = 0.35f;
        public float minSize = 5f;
        public float maxSize = 6.8f;
        public float speedForMaxZoom = 14f;

        Camera cam;
        Vector3 vel;
        float zoomMul = 1f;
        static readonly float[] zoomSteps = { 1f, 1.35f, 0.8f };
        int zoomIndex;

        void Awake() { cam = GetComponent<Camera>(); }

        public void CycleZoom()
        {
            zoomIndex = (zoomIndex + 1) % zoomSteps.Length;
        }

        void LateUpdate()
        {
            if (target == null) return;
            Vector2 v = PhysicsCompat.GetVelocity(target);
            Vector2 ahead = new Vector2(Mathf.Clamp(v.x * lookAhead, -3f, 5f), Mathf.Clamp(v.y * 0.15f, -2f, 2f));
            Vector3 desired = (Vector3)(target.position + offset + ahead);
            desired.z = transform.position.z;
            transform.position = Vector3.SmoothDamp(transform.position, desired, ref vel, smoothTime);

            zoomMul = Mathf.Lerp(zoomMul, zoomSteps[zoomIndex], 5f * Time.unscaledDeltaTime);
            float want = Mathf.Lerp(minSize, maxSize, Mathf.Clamp01(v.magnitude / speedForMaxZoom)) * zoomMul;
            cam.orthographicSize = Mathf.Lerp(cam.orthographicSize, want, 2f * Time.unscaledDeltaTime);
        }
    }
}
