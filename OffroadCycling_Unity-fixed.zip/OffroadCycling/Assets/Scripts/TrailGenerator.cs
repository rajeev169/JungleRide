using UnityEngine;

namespace OffroadCycling
{
    /// <summary>
    /// Builds the whole off-road course at runtime: a rideable dirt trail (mesh + EdgeCollider2D),
    /// the dark soil under it, and a grassy hillside behind it. Terrain is a deterministic function
    /// of x and a seed, so props / respawns can ask for Height(x), Normal(x), etc.
    /// </summary>
    [DefaultExecutionOrder(-100)]
    public class TrailGenerator : MonoBehaviour
    {
        [Header("Course")]
        public float length = 700f;
        public float sampleStep = 0.4f;
        public int seed = 1234;
        [Tooltip("Flat, easy section at the start.")] public float startFlat = 16f;
        [Tooltip("Net downhill: units dropped per unit travelled.")] public float descent = 0.04f;
        public float rollAmplitude = 3.2f;
        public float rollFrequency = 0.03f;
        public float whoopAmplitude = 0.3f;
        public float whoopLength = 2.8f;
        public int jumpCount = 9;
        public float jumpHeight = 1.3f;
        public float jumpRamp = 3.4f;

        [Header("Look (assigned by the scene builder)")]
        public Texture2D trailTexture;
        public Texture2D soilTexture;
        public Texture2D grassTexture;
        public float trailThickness = 0.6f;
        public float hillRise = 2.6f;
        public float trailTile = 4f;
        public float grassTile = 5f;
        public float soilTile = 4f;

        public const float PadStart = 10f;
        public const float PadEnd = 25f;
        public float FinishX { get { return length - 12f; } }

        float[] jumpX;
        bool initialised;

        void Awake() { Generate(); }

        void Init()
        {
            if (initialised) return;
            initialised = true;
            var rnd = new System.Random(seed);
            jumpX = new float[Mathf.Max(0, jumpCount)];
            float span = (length - 100f) / Mathf.Max(1, jumpCount);
            for (int i = 0; i < jumpX.Length; i++)
                jumpX[i] = 50f + span * i + (float)(rnd.NextDouble() * 2.0 - 1.0) * span * 0.25f;
        }

        // ------------------------------------------------------------------ terrain functions
        public float Height(float x)
        {
            Init();
            float xs = Mathf.Max(x, 0f);
            float blend = Mathf.SmoothStep(0f, 1f, xs / Mathf.Max(1f, startFlat));
            float h = -descent * xs;

            float rolling = (Mathf.PerlinNoise(xs * rollFrequency, seed * 0.37f) - 0.5f) * 2f * rollAmplitude;
            rolling += (Mathf.PerlinNoise(xs * rollFrequency * 3.1f, seed * 0.91f + 7.7f) - 0.5f) * 1.1f;

            float whoopMask = Mathf.Clamp01((Mathf.PerlinNoise(xs * 0.02f, seed * 0.5f) - 0.45f) * 4f);
            float whoops = Mathf.Sin(xs * 2f * Mathf.PI / whoopLength) * whoopAmplitude * whoopMask;

            float jumps = 0f;
            for (int i = 0; i < jumpX.Length; i++) jumps += JumpProfile(xs - jumpX[i]);

            return h + blend * (rolling + whoops + jumps);
        }

        float JumpProfile(float dx)
        {
            if (dx < -jumpRamp || dx > 1.6f) return 0f;
            if (dx <= 0f)
            {
                float t = (dx + jumpRamp) / jumpRamp;
                return jumpHeight * t * t;
            }
            return jumpHeight * (1f - Mathf.SmoothStep(0f, 1f, dx / 1.6f));
        }

        public float HillTop(float x)
        {
            float xs = Mathf.Max(x, -PadStart);
            float n = Mathf.PerlinNoise(xs * 0.045f + seed * 0.13f, 3.3f);
            float n2 = Mathf.PerlinNoise(xs * 0.15f + seed * 0.31f, 9.1f);
            return Height(x) + hillRise + n * 2.2f + n2 * 0.6f;
        }

        public float SlopeAngle(float x)
        {
            float dy = Height(x + 0.3f) - Height(x - 0.3f);
            return Mathf.Atan2(dy, 0.6f) * Mathf.Rad2Deg;
        }

        // ------------------------------------------------------------------ mesh building
        [ContextMenu("Generate")]
        public void Generate()
        {
            initialised = false;
            Init();

            for (int i = transform.childCount - 1; i >= 0; i--)
            {
                if (Application.isPlaying) Destroy(transform.GetChild(i).gameObject);
                else DestroyImmediate(transform.GetChild(i).gameObject);
            }

            float x0 = -PadStart;
            float x1 = length + PadEnd;
            int n = Mathf.CeilToInt((x1 - x0) / sampleStep) + 1;
            var xs = new float[n];
            for (int i = 0; i < n; i++) xs[i] = x0 + i * sampleStep;

            // ---- collider: surface plus walls at both ends
            var edge = GetComponent<EdgeCollider2D>();
            if (edge == null) edge = gameObject.AddComponent<EdgeCollider2D>();
            var pts = new Vector2[n + 2];
            pts[0] = new Vector2(x0, Height(x0) + 14f);
            for (int i = 0; i < n; i++) pts[i + 1] = new Vector2(xs[i], Height(xs[i]));
            pts[n + 1] = new Vector2(x1, Height(x1) + 14f);
            edge.points = pts;
            var mat = new PhysicsMaterial2D("Ground") { friction = 1f, bounciness = 0f };
            edge.sharedMaterial = mat;

            float minY = float.MaxValue;
            for (int i = 0; i < n; i++) minY = Mathf.Min(minY, Height(xs[i]));
            float soilBottom = minY - 30f;

            // back grass hill (behind everything), trail soil, trail dirt band
            BuildBand("BackHill", xs, x => HillTop(x), x => Height(x) - trailThickness - 0.5f, grassTexture, grassTile,
                      new Color(0.92f, 0.98f, 0.92f), new Color(0.55f, 0.75f, 0.55f), -60);
            BuildBand("Soil", xs, x => Height(x) - trailThickness + 0.03f, x => soilBottom, soilTexture, soilTile,
                      new Color(0.85f, 0.85f, 0.85f), new Color(0.45f, 0.45f, 0.45f), -20);
            BuildBand("TrailDirt", xs, x => Height(x), x => Height(x) - trailThickness, trailTexture, trailTile,
                      Color.white, new Color(0.88f, 0.8f, 0.72f), -10);
        }

        void BuildBand(string objName, float[] xs, System.Func<float, float> top, System.Func<float, float> bottom,
                       Texture2D tex, float tile, Color topCol, Color botCol, int order)
        {
            var go = new GameObject(objName);
            go.transform.SetParent(transform, false);
            var mf = go.AddComponent<MeshFilter>();
            var mr = go.AddComponent<MeshRenderer>();

            int n = xs.Length;
            var v = new Vector3[n * 2];
            var uv = new Vector2[n * 2];
            var col = new Color[n * 2];
            var tri = new int[(n - 1) * 6];

            for (int i = 0; i < n; i++)
            {
                float t = top(xs[i]);
                float b = bottom(xs[i]);
                v[2 * i] = new Vector3(xs[i], t, 0f);
                v[2 * i + 1] = new Vector3(xs[i], b, 0f);
                uv[2 * i] = new Vector2(xs[i] / tile, t / tile);
                uv[2 * i + 1] = new Vector2(xs[i] / tile, b / tile);
                col[2 * i] = topCol;
                col[2 * i + 1] = botCol;
            }
            int k = 0;
            for (int i = 0; i < n - 1; i++)
            {
                int a = 2 * i, b = 2 * i + 1, c = 2 * i + 2, d = 2 * i + 3;
                tri[k++] = a; tri[k++] = c; tri[k++] = b;
                tri[k++] = c; tri[k++] = d; tri[k++] = b;
            }

            var mesh = new Mesh { name = objName };
            mesh.vertices = v;
            mesh.uv = uv;
            mesh.colors = col;
            mesh.triangles = tri;
            mesh.RecalculateBounds();
            mf.sharedMesh = mesh;

            if (tex != null) tex.wrapMode = TextureWrapMode.Repeat;
            var shader = Shader.Find("Sprites/Default");
            var m = new Material(shader);
            if (tex != null) m.mainTexture = tex;
            mr.sharedMaterial = m;
            mr.sortingOrder = order;
        }
    }
}
