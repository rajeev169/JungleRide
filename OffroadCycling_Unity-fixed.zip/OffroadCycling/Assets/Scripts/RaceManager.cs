using System.Collections;
using UnityEngine;

namespace OffroadCycling
{
    /// <summary>Spawn, timer, checkpoints, respawn after crashes/flips, finish line, pause.</summary>
    public class RaceManager : MonoBehaviour
    {
        public TrailGenerator trail;
        public BikeController bike;
        public HudController hud;
        public CameraFollow2D cameraRig;

        public float startX = 2f;
        public float checkpointSpacing = 100f;
        public float crashRespawnDelay = 1.2f;
        public float flippedRespawnSeconds = 2.5f;

        float lastCheckpointX;
        float raceTime;
        bool finished;
        bool paused;
        float flippedTimer;
        Coroutine respawnRoutine;
        GameObject finishGate;

        void Awake() { Time.fixedDeltaTime = 1f / 100f; }

        void Start()
        {
            bike.Crashed += OnCrashed;
            hud.PauseClicked += TogglePause;
            hud.RestartClicked += Restart;
            hud.RespawnClicked += RespawnNow;
            hud.CameraClicked += delegate { if (cameraRig != null) cameraRig.CycleZoom(); };
            BuildFinishGate();
            Restart();
        }

        void Restart()
        {
            if (respawnRoutine != null) StopCoroutine(respawnRoutine);
            Time.timeScale = 1f;
            paused = false;
            finished = false;
            raceTime = 0f;
            lastCheckpointX = startX;
            bike.Controllable = true;
            hud.SetPaused(false);
            hud.HideMessage();
            RespawnNow();
            hud.Flash("GO!", 1.2f);
        }

        void RespawnNow()
        {
            if (respawnRoutine != null) { StopCoroutine(respawnRoutine); respawnRoutine = null; }
            float x = lastCheckpointX;
            bike.Teleport(new Vector2(x, trail.Height(x) + 0.9f), trail.SlopeAngle(x));
            flippedTimer = 0f;
        }

        void OnCrashed()
        {
            if (finished) return;
            hud.Flash("Wipeout!", crashRespawnDelay);
            respawnRoutine = StartCoroutine(RespawnAfter(crashRespawnDelay));
        }

        IEnumerator RespawnAfter(float s)
        {
            yield return new WaitForSeconds(s);
            respawnRoutine = null;
            RespawnNow();
        }

        void Update()
        {
            if (InputShim.Down(Btn.Pause)) TogglePause();
            if (InputShim.Down(Btn.Camera) && cameraRig != null) cameraRig.CycleZoom();
            if (InputShim.Down(Btn.Respawn) && !paused) RespawnNow();
            if (InputShim.Down(Btn.Restart) && (finished || paused)) Restart();

            float x = bike.Position.x;
            float kmh = bike.SpeedMS * 3.6f;
            hud.SetSpeed(kmh);
            hud.SetDistance(Mathf.Max(0f, x - startX), trail.FinishX - startX);
            hud.SetTime(raceTime);

            if (paused || finished) return;
            raceTime += Time.deltaTime;

            // checkpoints
            float cp = Mathf.Floor(x / checkpointSpacing) * checkpointSpacing;
            if (cp > lastCheckpointX + 1f)
            {
                lastCheckpointX = cp;
                hud.Flash("Checkpoint!", 1.5f);
            }

            // stuck upside down / fell out of the world
            if (bike.body.transform.up.y < -0.2f && bike.SpeedMS < 1.5f) flippedTimer += Time.deltaTime; else flippedTimer = 0f;
            if (flippedTimer > flippedRespawnSeconds || bike.Position.y < trail.Height(x) - 15f) RespawnNow();

            if (x > trail.FinishX)
            {
                finished = true;
                bike.Controllable = false;
                hud.ShowMessage("FINISH!\n" + HudController.FormatTime(raceTime) + "\nPress Enter or tap restart");
            }
        }

        void TogglePause()
        {
            if (finished) return;
            paused = !paused;
            Time.timeScale = paused ? 0f : 1f;
            hud.SetPaused(paused);
        }

        void BuildFinishGate()
        {
            var tex = new Texture2D(8, 8, TextureFormat.RGBA32, false) { filterMode = FilterMode.Point };
            for (int y = 0; y < 8; y++)
                for (int x = 0; x < 8; x++)
                    tex.SetPixel(x, y, ((x + y) % 2 == 0) ? Color.white : new Color(0.1f, 0.1f, 0.1f));
            tex.Apply();
            var checker = Sprite.Create(tex, new Rect(0, 0, 8, 8), new Vector2(0f, 0f), 8f);
            var white = Texture2D.whiteTexture;
            var pole = Sprite.Create(white, new Rect(0, 0, white.width, white.height), new Vector2(0.5f, 0f), white.width);

            float fx = trail.FinishX;
            finishGate = new GameObject("FinishGate");
            finishGate.transform.position = new Vector3(fx, trail.Height(fx), 0f);

            var p = new GameObject("Pole").AddComponent<SpriteRenderer>();
            p.transform.SetParent(finishGate.transform, false);
            p.sprite = pole; p.color = new Color(0.95f, 0.95f, 0.95f); p.sortingOrder = 3;
            p.transform.localScale = new Vector3(0.14f, 4.8f, 1f);

            var f = new GameObject("Flag").AddComponent<SpriteRenderer>();
            f.transform.SetParent(finishGate.transform, false);
            f.sprite = checker; f.sortingOrder = 4;
            f.transform.localPosition = new Vector3(0.07f, 3.4f, 0f);
            f.transform.localScale = new Vector3(1.8f / 1f, 1.3f / 1f, 1f);
        }
    }
}
