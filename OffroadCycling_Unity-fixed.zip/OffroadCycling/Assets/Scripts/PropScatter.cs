using UnityEngine;

namespace OffroadCycling
{
    /// <summary>Scatters palms, foliage and rocks along the generated trail (deterministic via seed).</summary>
    public class PropScatter : MonoBehaviour
    {
        public TrailGenerator trail;
        public Sprite[] palms;
        public Sprite[] plants;     // fern, grass tuft, bush
        public Sprite[] rocks;
        public int seed = 7;

        [Header("Density")]
        public float palmSpacing = 9f;
        public float plantSpacing = 1.6f;
        public float rockSpacing = 26f;
        public float firstRockX = 30f;

        System.Random rnd;

        void Start()
        {
            if (trail == null) return;
            rnd = new System.Random(seed);
            var palmRoot = Parent("Palms");
            var plantRoot = Parent("Foliage");
            var rockRoot = Parent("Rocks");

            float end = trail.length + 15f;

            // palms along the top of the back hill
            if (palms != null && palms.Length > 0)
            {
                for (float x = -6f; x < end; x += palmSpacing * R(0.6f, 1.5f))
                {
                    var s = palms[rnd.Next(palms.Length)];
                    float sc = R(0.8f, 1.35f);
                    var sr = Make(s, new Vector3(x, trail.HillTop(x) - 0.25f, 0f), sc, rnd.Next(2) == 0,
                                  -55 + rnd.Next(3), new Color(0.86f, 0.94f, 0.9f), palmRoot);
                    sr.transform.rotation = Quaternion.Euler(0, 0, R(-3f, 3f));
                }
            }

            // foliage on the grass slope between trail and hilltop
            if (plants != null && plants.Length > 0)
            {
                for (float x = -6f; x < end; x += plantSpacing * R(0.6f, 1.6f))
                {
                    var s = plants[rnd.Next(plants.Length)];
                    float low = trail.Height(x) + 0.35f;
                    float high = trail.HillTop(x) - 0.15f;
                    float y = Mathf.Lerp(low, high, (float)rnd.NextDouble());
                    float depth = Mathf.InverseLerp(low, high, y);       // higher up = further away
                    float sc = Mathf.Lerp(0.95f, 0.55f, depth) * R(0.8f, 1.2f);
                    float shade = Mathf.Lerp(1f, 0.8f, depth);
                    Make(s, new Vector3(x, y, 0f), sc, rnd.Next(2) == 0, -50 + Mathf.RoundToInt((1f - depth) * 10f),
                         new Color(shade, shade, shade), plantRoot);
                }
            }

            // rocks: obstacles on the trail + decoration on the hill
            if (rocks != null && rocks.Length > 0)
            {
                for (float x = firstRockX; x < trail.FinishX - 10f; x += rockSpacing * R(0.7f, 1.4f))
                {
                    var s = rocks[rnd.Next(rocks.Length)];
                    float sc = R(0.4f, 0.75f);
                    Vector2 size = s.bounds.size;
                    float y = trail.Height(x) + size.y * sc * 0.32f;
                    var sr = Make(s, new Vector3(x, y, 0f), sc, rnd.Next(2) == 0, 5, Color.white, rockRoot);
                    sr.transform.rotation = Quaternion.Euler(0, 0, trail.SlopeAngle(x) * 0.6f);
                    var cap = sr.gameObject.AddComponent<CapsuleCollider2D>();
                    cap.direction = CapsuleDirection2D.Horizontal;
                    cap.size = new Vector2(size.x * 0.82f, size.y * 0.72f);
                    cap.offset = new Vector2(0f, size.y * -0.02f);
                }
                for (float x = 8f; x < end; x += 14f * R(0.6f, 1.6f))
                {
                    var s = rocks[rnd.Next(rocks.Length)];
                    float y = Mathf.Lerp(trail.Height(x) + 0.8f, trail.HillTop(x) - 0.4f, (float)rnd.NextDouble());
                    Make(s, new Vector3(x, y, 0f), R(0.55f, 1.1f), rnd.Next(2) == 0, -45, new Color(0.85f, 0.88f, 0.85f), rockRoot);
                }
            }
        }

        float R(float a, float b) { return a + (float)rnd.NextDouble() * (b - a); }

        Transform Parent(string n)
        {
            var go = new GameObject(n);
            go.transform.SetParent(transform, false);
            return go.transform;
        }

        static SpriteRenderer Make(Sprite s, Vector3 pos, float scale, bool flip, int order, Color tint, Transform parent)
        {
            var go = new GameObject(s.name);
            go.transform.SetParent(parent, false);
            go.transform.position = pos;
            go.transform.localScale = Vector3.one * scale;
            var sr = go.AddComponent<SpriteRenderer>();
            sr.sprite = s;
            sr.flipX = flip;
            sr.sortingOrder = order;
            sr.color = tint;
            return sr;
        }
    }
}
