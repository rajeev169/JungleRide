using UnityEngine;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

namespace OffroadCycling
{
    public enum Btn { Respawn, Pause, Restart, Camera }

    /// <summary>Works with the old Input Manager, the new Input System, or both. Also receives touch-joystick input.</summary>
    public static class InputShim
    {
        public static Vector2 TouchAxis;

        public static float Throttle()
        {
            float v = 0f;
#if ENABLE_INPUT_SYSTEM
            var k = Keyboard.current;
            if (k != null)
            {
                if (k.dKey.isPressed || k.rightArrowKey.isPressed) v += 1f;
                if (k.aKey.isPressed || k.leftArrowKey.isPressed) v -= 1f;
            }
#endif
#if ENABLE_LEGACY_INPUT_MANAGER
            v += Input.GetAxisRaw("Horizontal");
#endif
            return Mathf.Clamp(v + TouchAxis.x, -1f, 1f);
        }

        /// <summary>+1 = nose up (wheelie), -1 = nose down.</summary>
        public static float Lean()
        {
            float v = 0f;
#if ENABLE_INPUT_SYSTEM
            var k = Keyboard.current;
            if (k != null)
            {
                if (k.wKey.isPressed || k.upArrowKey.isPressed) v += 1f;
                if (k.sKey.isPressed || k.downArrowKey.isPressed) v -= 1f;
            }
#endif
#if ENABLE_LEGACY_INPUT_MANAGER
            v += Input.GetAxisRaw("Vertical");
#endif
            return Mathf.Clamp(v + TouchAxis.y, -1f, 1f);
        }

        public static bool Down(Btn b)
        {
#if ENABLE_INPUT_SYSTEM
            var k = Keyboard.current;
            if (k != null)
            {
                switch (b)
                {
                    case Btn.Respawn: if (k.rKey.wasPressedThisFrame) return true; break;
                    case Btn.Pause: if (k.escapeKey.wasPressedThisFrame || k.pKey.wasPressedThisFrame) return true; break;
                    case Btn.Restart: if (k.enterKey.wasPressedThisFrame) return true; break;
                    case Btn.Camera: if (k.cKey.wasPressedThisFrame) return true; break;
                }
            }
#endif
#if ENABLE_LEGACY_INPUT_MANAGER
            switch (b)
            {
                case Btn.Respawn: return Input.GetKeyDown(KeyCode.R);
                case Btn.Pause: return Input.GetKeyDown(KeyCode.Escape) || Input.GetKeyDown(KeyCode.P);
                case Btn.Restart: return Input.GetKeyDown(KeyCode.Return);
                case Btn.Camera: return Input.GetKeyDown(KeyCode.C);
            }
#endif
            return false;
        }
    }

    /// <summary>Rigidbody2D velocity API changed names in Unity 6.</summary>
    public static class PhysicsCompat
    {
        public static Vector2 GetVelocity(Rigidbody2D rb)
        {
#if UNITY_6000_0_OR_NEWER
            return rb.linearVelocity;
#else
            return rb.velocity;
#endif
        }

        public static void SetVelocity(Rigidbody2D rb, Vector2 v)
        {
#if UNITY_6000_0_OR_NEWER
            rb.linearVelocity = v;
#else
            rb.velocity = v;
#endif
        }
    }
}
