using UnityEngine;

namespace OffroadCycling
{
    /// <summary>
    /// Physics bike: a body and two wheels (separate Rigidbody2Ds) joined by WheelJoint2D suspension.
    /// Throttle drives the rear wheel; the player leans the bike with the lean axis.
    /// All numbers are exposed so you can tune the feel.
    /// </summary>
    public class BikeController : MonoBehaviour
    {
        [Header("Parts")]
        public Rigidbody2D body;
        public Rigidbody2D rearWheel;
        public Rigidbody2D frontWheel;
        public WheelJoint2D rearJoint;
        public WheelJoint2D frontJoint;
        public CircleCollider2D rearCollider;
        public CircleCollider2D frontCollider;

        [Header("Drive")]
        public float wheelRadius = 0.4f;
        public float maxSpeed = 13f;
        public float motorTorque = 28f;
        public float brakeTorque = 45f;
        public float reverseSpeed = 2.5f;

        [Header("Handling")]
        public float leanTorque = 9f;
        [Tooltip("Lean authority multiplier while both wheels are off the ground.")] public float airLeanBoost = 1.6f;
        [Tooltip("Resists spinning when you aren't leaning.")] public float pitchDamping = 0.02f;
        public float gravityScale = 1.6f;
        public float bodyMass = 2.5f;
        public float wheelMass = 0.6f;
        public float bodyInertia = 1.1f;
        public float tireFriction = 1.3f;

        public bool Controllable = true;
        public bool IsCrashed { get; private set; }
        public bool Grounded { get; private set; }
        public event System.Action Crashed;

        Vector2 rearLocal, frontLocal;
        float ignoreCrashUntil;

        public float SpeedMS { get { return PhysicsCompat.GetVelocity(body).magnitude; } }
        public float ForwardSpeed { get { return Vector2.Dot(PhysicsCompat.GetVelocity(body), body.transform.right); } }
        public Vector2 Position { get { return body.position; } }

        void Awake()
        {
            body.mass = bodyMass;
            body.inertia = bodyInertia;
            body.centerOfMass = new Vector2(0f, 0.1f);
            body.gravityScale = gravityScale;
            foreach (var w in new[] { rearWheel, frontWheel }) { w.mass = wheelMass; w.gravityScale = gravityScale; }

            var mat = new PhysicsMaterial2D("Tire") { friction = tireFriction, bounciness = 0.02f };
            rearCollider.sharedMaterial = mat;
            frontCollider.sharedMaterial = mat;

            rearLocal = rearJoint.anchor;
            frontLocal = frontJoint.anchor;
        }

        void FixedUpdate()
        {
            Grounded = rearCollider.IsTouchingLayers() || frontCollider.IsTouchingLayers();
            bool bothAir = !rearCollider.IsTouchingLayers() && !frontCollider.IsTouchingLayers();

            float throttle = (Controllable && !IsCrashed) ? InputShim.Throttle() : 0f;
            float lean = (Controllable && !IsCrashed) ? InputShim.Lean() : 0f;

            float fwd = ForwardSpeed;
            float maxDeg = maxSpeed / wheelRadius * Mathf.Rad2Deg;

            var rm = rearJoint.motor;
            var fm = frontJoint.motor;
            if (IsCrashed)
            {
                rearJoint.useMotor = false;
                frontJoint.useMotor = false;
            }
            else if (throttle > 0.05f)
            {
                rm.motorSpeed = -maxDeg * throttle;       // negative = clockwise = rolling right
                rm.maxMotorTorque = motorTorque;
                rearJoint.motor = rm;
                rearJoint.useMotor = true;
                frontJoint.useMotor = false;
            }
            else if (throttle < -0.05f)
            {
                if (fwd > 1.2f)                           // brake
                {
                    rm.motorSpeed = 0f; rm.maxMotorTorque = brakeTorque; rearJoint.motor = rm; rearJoint.useMotor = true;
                    fm.motorSpeed = 0f; fm.maxMotorTorque = brakeTorque * 0.8f; frontJoint.motor = fm; frontJoint.useMotor = true;
                }
                else                                      // slow reverse
                {
                    rm.motorSpeed = reverseSpeed / wheelRadius * Mathf.Rad2Deg * -throttle;
                    rm.maxMotorTorque = motorTorque;
                    rearJoint.motor = rm; rearJoint.useMotor = true;
                    frontJoint.useMotor = false;
                }
            }
            else
            {
                rearJoint.useMotor = false;               // coast
                frontJoint.useMotor = false;
            }

            if (!IsCrashed)
            {
                float t = lean * leanTorque * (bothAir ? airLeanBoost : 1f);
                body.AddTorque(t);
                if (Mathf.Abs(lean) < 0.05f) body.AddTorque(-body.angularVelocity * pitchDamping);
            }
        }

        /// <summary>Called by BodyCrashSensor when the rider's head or hips hit the world.</summary>
        public void NotifyCrash()
        {
            if (IsCrashed || Time.time < ignoreCrashUntil) return;
            IsCrashed = true;
            if (Crashed != null) Crashed();
        }

        public void Teleport(Vector2 pos, float angleDeg)
        {
            var rot = Quaternion.Euler(0f, 0f, angleDeg);
            Place(body, pos, angleDeg);
            Place(rearWheel, pos + (Vector2)(rot * rearLocal), angleDeg);
            Place(frontWheel, pos + (Vector2)(rot * frontLocal), angleDeg);
            IsCrashed = false;
            ignoreCrashUntil = Time.time + 0.6f;
        }

        static void Place(Rigidbody2D rb, Vector2 p, float angle)
        {
            rb.position = p;
            rb.rotation = angle;
            rb.transform.SetPositionAndRotation(new Vector3(p.x, p.y, 0f), Quaternion.Euler(0f, 0f, angle));
            PhysicsCompat.SetVelocity(rb, Vector2.zero);
            rb.angularVelocity = 0f;
        }
    }
}
