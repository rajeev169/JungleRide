using UnityEngine;

namespace OffroadCycling
{
    /// <summary>Scrolls a background layer relative to the camera. If tileWidth > 0 the layer wraps forever.</summary>
    public class ParallaxLayer : MonoBehaviour
    {
        public Transform cam;
        [Range(0f, 1f)] public float factorX = 0.5f;
        [Range(0f, 1f)] public float factorY = 1f;
        public float tileWidth = 0f;

        Vector3 startPos, camStart;

        void Start()
        {
            if (cam == null && Camera.main != null) cam = Camera.main.transform;
            startPos = transform.position;
            camStart = cam.position;
        }

        void LateUpdate()
        {
            if (cam == null) return;
            Vector3 d = cam.position - camStart;
            float x = startPos.x + d.x * factorX;
            float y = startPos.y + d.y * factorY;
            if (tileWidth > 0.01f)
                x += Mathf.Round((cam.position.x - x) / tileWidth) * tileWidth;
            transform.position = new Vector3(x, y, startPos.z);
        }
    }
}
