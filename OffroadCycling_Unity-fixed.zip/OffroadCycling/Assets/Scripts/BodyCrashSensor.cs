using UnityEngine;

namespace OffroadCycling
{
    /// <summary>Sits on the Body object (head + hip colliders). Any contact = crash.</summary>
    public class BodyCrashSensor : MonoBehaviour
    {
        public BikeController bike;
        void OnCollisionEnter2D(Collision2D c) { if (bike != null) bike.NotifyCrash(); }
    }
}
