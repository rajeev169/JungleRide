using UnityEngine;
using UnityEngine.EventSystems;

namespace OffroadCycling
{
    /// <summary>On-screen stick for touch devices: horizontal = gas/brake, vertical = lean.</summary>
    public class VirtualJoystick : MonoBehaviour, IPointerDownHandler, IDragHandler, IPointerUpHandler
    {
        public RectTransform ring;
        public RectTransform knob;
        public bool onlyOnMobile = true;
        public float deadZone = 0.12f;

        void Awake()
        {
            if (onlyOnMobile && !Application.isMobilePlatform) gameObject.SetActive(false);
        }

        public void OnPointerDown(PointerEventData e) { Handle(e); }
        public void OnDrag(PointerEventData e) { Handle(e); }

        public void OnPointerUp(PointerEventData e)
        {
            InputShim.TouchAxis = Vector2.zero;
            if (knob) knob.anchoredPosition = Vector2.zero;
        }

        void Handle(PointerEventData e)
        {
            Vector2 local;
            if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(ring, e.position, e.pressEventCamera, out local)) return;
            float radius = ring.rect.width * 0.5f;
            Vector2 v = Vector2.ClampMagnitude(local / radius, 1f);
            if (knob) knob.anchoredPosition = v * radius * 0.7f;
            if (v.magnitude < deadZone) v = Vector2.zero;
            InputShim.TouchAxis = v;
        }

        void OnDisable() { InputShim.TouchAxis = Vector2.zero; }
    }
}
