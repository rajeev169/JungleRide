using System;
using UnityEngine;
using UnityEngine.UI;

namespace OffroadCycling
{
    public class HudController : MonoBehaviour
    {
        [Header("Readouts")]
        public Text speedText;
        public Text timeText;
        public Text distanceText;
        public Text messageText;

        [Header("Speed gauge")]
        public Image gaugeFill;          // radial-filled lime arc
        public RectTransform needle;
        public float gaugeMaxKmh = 60f;

        [Header("Buttons")]
        public Button pauseButton;
        public Button cameraButton;
        public Button restartButton;
        public Button respawnButton;

        public GameObject pausePanel;

        public event Action PauseClicked, CameraClicked, RestartClicked, RespawnClicked;

        float messageHideAt = -1f;

        void Awake()
        {
            if (pauseButton) pauseButton.onClick.AddListener(delegate { if (PauseClicked != null) PauseClicked(); });
            if (cameraButton) cameraButton.onClick.AddListener(delegate { if (CameraClicked != null) CameraClicked(); });
            if (restartButton) restartButton.onClick.AddListener(delegate { if (RestartClicked != null) RestartClicked(); });
            if (respawnButton) respawnButton.onClick.AddListener(delegate { if (RespawnClicked != null) RespawnClicked(); });
        }

        void Update()
        {
            if (messageHideAt > 0f && Time.unscaledTime > messageHideAt) HideMessage();
        }

        public void SetSpeed(float kmh)
        {
            float t = Mathf.Clamp01(kmh / gaugeMaxKmh);
            // the arc spans 225 degrees, starting 45 degrees clockwise from "bottom" -> 0.125 .. 0.75 of a full circle
            if (gaugeFill) gaugeFill.fillAmount = 0.125f + 0.625f * t;
            if (needle) needle.localEulerAngles = new Vector3(0f, 0f, -(225f + 225f * t));
            if (speedText) speedText.text = Mathf.RoundToInt(kmh) + " km/h";
        }

        public void SetTime(float seconds) { if (timeText) timeText.text = FormatTime(seconds); }

        public void SetDistance(float metres, float total)
        {
            if (distanceText) distanceText.text = Mathf.RoundToInt(metres) + " / " + Mathf.RoundToInt(total) + " m";
        }

        public void SetPaused(bool p)
        {
            if (pausePanel) pausePanel.SetActive(p);
        }

        public void Flash(string msg, float seconds)
        {
            ShowMessage(msg);
            messageHideAt = Time.unscaledTime + seconds;
        }

        public void ShowMessage(string msg)
        {
            if (!messageText) return;
            messageText.text = msg;
            messageText.gameObject.SetActive(true);
            messageHideAt = -1f;
        }

        public void HideMessage()
        {
            if (messageText) messageText.gameObject.SetActive(false);
            messageHideAt = -1f;
        }

        public static string FormatTime(float s)
        {
            int m = (int)(s / 60f);
            float sec = s - m * 60f;
            return m.ToString("00") + ":" + sec.ToString("00.0");
        }
    }
}
