using UnityEditor;
using UnityEngine;

namespace OffroadCycling.EditorTools
{
    /// <summary>
    /// Applies sensible import settings (sprite type, pixels-per-unit, pivot, tiling) to everything in
    /// Assets/Art the first time it is imported, so the scene builder works with zero manual setup.
    /// </summary>
    public class SpriteImportPostprocessor : AssetPostprocessor
    {
        void OnPreprocessTexture()
        {
            string p = assetPath.Replace('\\', '/');
            if (!p.StartsWith("Assets/Art/")) return;
            if (!assetImporter.importSettingsMissing) return;   // only on first import; later edits are yours
            var imp = (TextureImporter)assetImporter;
            string file = System.IO.Path.GetFileNameWithoutExtension(p);

            if (p.Contains("/Textures/"))
            {
                imp.textureType = file.EndsWith("_normal") ? TextureImporterType.NormalMap : TextureImporterType.Default;
                imp.wrapMode = TextureWrapMode.Repeat;
                imp.filterMode = FilterMode.Bilinear;
                imp.mipmapEnabled = true;
                return;
            }

            imp.textureType = TextureImporterType.Sprite;
            imp.spriteImportMode = SpriteImportMode.Single;
            imp.mipmapEnabled = false;
            imp.alphaIsTransparency = true;
            imp.filterMode = FilterMode.Bilinear;
            imp.maxTextureSize = 4096;

            float ppu = 100f;
            SpriteAlignment align = SpriteAlignment.Center;
            if (file == "bike_body") ppu = 256f;
            else if (file == "wheel") ppu = 320f;
            else if (file.StartsWith("palm_")) { ppu = 150f; align = SpriteAlignment.BottomCenter; }
            else if (file == "fern" || file == "grass_tuft" || file == "bush") { ppu = 250f; align = SpriteAlignment.BottomCenter; }
            else if (file.StartsWith("rock_")) ppu = 400f;
            else if (file == "sky_tile") ppu = 38f;
            else if (file.StartsWith("hills_")) { ppu = 68f; align = SpriteAlignment.BottomCenter; }

            var s = new TextureImporterSettings();
            imp.ReadTextureSettings(s);
            s.spritePixelsPerUnit = ppu;
            s.spriteAlignment = (int)align;
            s.spriteMeshType = SpriteMeshType.FullRect;
            s.spriteExtrude = 0;
            imp.SetTextureSettings(s);
        }
    }
}
