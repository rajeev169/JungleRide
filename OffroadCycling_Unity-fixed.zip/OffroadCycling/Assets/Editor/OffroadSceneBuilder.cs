using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem.UI;
#endif

namespace OffroadCycling.EditorTools
{
    /// <summary>Menu: Offroad Cycling > Build Demo Scene. Creates and saves a fully wired, playable scene.</summary>
    public static class OffroadSceneBuilder
    {
        const string Art = "Assets/Art/";
        static Font font;

        [MenuItem("Offroad Cycling/Build Demo Scene")]
        public static void Build()
        {
            AssetDatabase.Refresh();
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

            // sprites
            var bodySpr = Spr("Bike/bike_body.png");
            var wheelSpr = Spr("Bike/wheel.png");
            var skySpr = Spr("Environment/sky_tile.png");
            var hillsFar = Spr("Environment/hills_far.png");
            var hillsNear = Spr("Environment/hills_near.png");
            if (bodySpr == null || wheelSpr == null || skySpr == null)
            {
                Debug.LogError("Art sprites are not imported yet. Wait for the import to finish, then run the menu item again.");
                return;
            }

            // ---------------------------------------------------------------- camera
            Vector3 camStart = new Vector3(4f, 2.2f, -10f);
            var camGO = new GameObject("Main Camera");
            camGO.tag = "MainCamera";
            camGO.transform.position = camStart;
            var cam = camGO.AddComponent<Camera>();
            cam.orthographic = true;
            cam.orthographicSize = 5.5f;
            cam.clearFlags = CameraClearFlags.SolidColor;
            cam.backgroundColor = new Color(0.35f, 0.65f, 0.95f);
            camGO.AddComponent<AudioListener>();
            var follow = camGO.AddComponent<CameraFollow2D>();

            // ---------------------------------------------------------------- parallax backdrop
            var bg = new GameObject("Backdrop").transform;
            Layer(bg, "Sky", skySpr, -100, 0.97f, 1f, new Vector3(camStart.x, camStart.y + 1f, 5f), camGO.transform);
            if (hillsFar) Layer(bg, "HillsFar", hillsFar, -90, 0.9f, 1f, new Vector3(camStart.x, camStart.y + 3.6f - 7.8f, 4f), camGO.transform);
            if (hillsNear) Layer(bg, "HillsNear", hillsNear, -80, 0.8f, 1f, new Vector3(camStart.x, camStart.y + 2.7f - 8.7f, 3f), camGO.transform);

            // ---------------------------------------------------------------- trail + props
            var trailGO = new GameObject("Trail");
            var trail = trailGO.AddComponent<TrailGenerator>();
            trail.trailTexture = Tex("Textures/trail_dirt.png");
            trail.soilTexture = Tex("Textures/soil_dark.png");
            trail.grassTexture = Tex("Textures/hill_grass.png");

            var propsGO = new GameObject("Props");
            var props = propsGO.AddComponent<PropScatter>();
            props.trail = trail;
            props.palms = new[] { Spr("Vegetation/palm_a.png"), Spr("Vegetation/palm_b.png"), Spr("Vegetation/palm_c.png") };
            props.plants = new[] { Spr("Vegetation/fern.png"), Spr("Vegetation/grass_tuft.png"), Spr("Vegetation/bush.png") };
            props.rocks = new[] { Spr("Props/rock_a.png"), Spr("Props/rock_b.png"), Spr("Props/rock_c.png") };

            // ---------------------------------------------------------------- bike
            Vector2 rearLocal = new Vector2(-0.57f, -0.383f);
            Vector2 frontLocal = new Vector2(0.57f, -0.383f);
            Vector3 start = new Vector3(2f, 0.9f, 0f);

            var bikeGO = new GameObject("Bike");
            var bike = bikeGO.AddComponent<BikeController>();

            var bodyGO = new GameObject("Body");
            bodyGO.transform.SetParent(bikeGO.transform, false);
            bodyGO.transform.position = start;
            var bodySR = bodyGO.AddComponent<SpriteRenderer>();
            bodySR.sprite = bodySpr;
            bodySR.sortingOrder = 10;
            var bodyRB = bodyGO.AddComponent<Rigidbody2D>();
            bodyRB.interpolation = RigidbodyInterpolation2D.Interpolate;
            bodyRB.collisionDetectionMode = CollisionDetectionMode2D.Continuous;
            var head = bodyGO.AddComponent<CircleCollider2D>();
            head.radius = 0.12f;
            head.offset = new Vector2(0.29f, 0.43f);
            var hip = bodyGO.AddComponent<BoxCollider2D>();
            hip.size = new Vector2(0.3f, 0.22f);
            hip.offset = new Vector2(-0.19f, 0.07f);
            var sensor = bodyGO.AddComponent<BodyCrashSensor>();
            sensor.bike = bike;

            Rigidbody2D rearRB, frontRB;
            CircleCollider2D rearCol, frontCol;
            MakeWheel("RearWheel", wheelSpr, start + (Vector3)rearLocal, bikeGO.transform, out rearRB, out rearCol);
            MakeWheel("FrontWheel", wheelSpr, start + (Vector3)frontLocal, bikeGO.transform, out frontRB, out frontCol);

            bike.body = bodyRB;
            bike.rearWheel = rearRB;
            bike.frontWheel = frontRB;
            bike.rearCollider = rearCol;
            bike.frontCollider = frontCol;
            bike.rearJoint = MakeJoint(bodyGO, rearRB, rearLocal);
            bike.frontJoint = MakeJoint(bodyGO, frontRB, frontLocal);
            follow.target = bodyRB;

            // ---------------------------------------------------------------- HUD
            var hud = BuildHud();

            // ---------------------------------------------------------------- manager
            var mgrGO = new GameObject("RaceManager");
            var mgr = mgrGO.AddComponent<RaceManager>();
            mgr.trail = trail;
            mgr.bike = bike;
            mgr.hud = hud;
            mgr.cameraRig = follow;

            // ---------------------------------------------------------------- save
            string path = "Assets/Scenes/OffroadTrail.unity";
            EditorSceneManager.SaveScene(scene, path);
            EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(path, true) };
            Debug.Log("Offroad Cycling: scene saved to " + path + ". Press Play!  (A/D gas+brake, W/S lean, R respawn, C camera, Esc pause)");
        }

        // ====================================================================== helpers
        static Sprite Spr(string rel)
        {
            var s = AssetDatabase.LoadAssetAtPath<Sprite>(Art + rel);
            if (s == null) Debug.LogWarning("Missing sprite: " + Art + rel);
            return s;
        }

        static Texture2D Tex(string rel)
        {
            var t = AssetDatabase.LoadAssetAtPath<Texture2D>(Art + rel);
            if (t == null) Debug.LogWarning("Missing texture: " + Art + rel);
            return t;
        }

        static void Layer(Transform parent, string name, Sprite s, int order, float fx, float fy, Vector3 pos, Transform cam)
        {
            var go = new GameObject(name);
            go.transform.SetParent(parent, false);
            go.transform.position = pos;
            var sr = go.AddComponent<SpriteRenderer>();
            sr.sprite = s;
            sr.sortingOrder = order;
            sr.drawMode = SpriteDrawMode.Tiled;
            float tw = s.bounds.size.x;
            sr.size = new Vector2(tw * 3f, s.bounds.size.y);
            var p = go.AddComponent<ParallaxLayer>();
            p.cam = cam;
            p.factorX = fx;
            p.factorY = fy;
            p.tileWidth = tw;
        }

        static void MakeWheel(string name, Sprite s, Vector3 pos, Transform parent, out Rigidbody2D rb, out CircleCollider2D col)
        {
            var go = new GameObject(name);
            go.transform.SetParent(parent, false);
            go.transform.position = pos;
            var sr = go.AddComponent<SpriteRenderer>();
            sr.sprite = s;
            sr.sortingOrder = 9;
            rb = go.AddComponent<Rigidbody2D>();
            rb.interpolation = RigidbodyInterpolation2D.Interpolate;
            rb.collisionDetectionMode = CollisionDetectionMode2D.Continuous;
            col = go.AddComponent<CircleCollider2D>();
            col.radius = 0.4f;
        }

        static WheelJoint2D MakeJoint(GameObject bodyGO, Rigidbody2D wheel, Vector2 anchor)
        {
            var j = bodyGO.AddComponent<WheelJoint2D>();
            j.connectedBody = wheel;
            j.autoConfigureConnectedAnchor = false;
            j.anchor = anchor;
            j.connectedAnchor = Vector2.zero;
            j.enableCollision = false;
            j.suspension = new JointSuspension2D { dampingRatio = 0.75f, frequency = 5.5f, angle = 90f };
            j.useMotor = false;
            return j;
        }

        // ====================================================================== UI
        static RectTransform MakeRect(string name, Transform parent, Vector2 aMin, Vector2 aMax, Vector2 pivot, Vector2 pos, Vector2 size)
        {
            var go = new GameObject(name, typeof(RectTransform));
            go.transform.SetParent(parent, false);
            var rt = (RectTransform)go.transform;
            rt.anchorMin = aMin;
            rt.anchorMax = aMax;
            rt.pivot = pivot;
            rt.anchoredPosition = pos;
            rt.sizeDelta = size;
            return rt;
        }

        static Image Img(RectTransform rt, Sprite s, bool raycast)
        {
            var im = rt.gameObject.AddComponent<Image>();
            im.sprite = s;
            im.preserveAspect = true;
            im.raycastTarget = raycast;
            return im;
        }

        static Text Txt(string name, Transform parent, Vector2 anchor, Vector2 pivot, Vector2 pos, Vector2 size, int fontSize, TextAnchor align)
        {
            var rt = MakeRect(name, parent, anchor, anchor, pivot, pos, size);
            var t = rt.gameObject.AddComponent<Text>();
            t.font = font;
            t.fontSize = fontSize;
            t.fontStyle = FontStyle.Bold;
            t.alignment = align;
            t.color = Color.white;
            t.raycastTarget = false;
            t.horizontalOverflow = HorizontalWrapMode.Overflow;
            t.verticalOverflow = VerticalWrapMode.Overflow;
            var o = rt.gameObject.AddComponent<Outline>();
            o.effectColor = new Color(0f, 0f, 0f, 0.8f);
            o.effectDistance = new Vector2(2f, -2f);
            return t;
        }

        static Button MakeButton(RectTransform rt, Sprite s)
        {
            Img(rt, s, true);
            var b = rt.gameObject.AddComponent<Button>();
            b.targetGraphic = rt.GetComponent<Image>();
            return b;
        }

        static HudController BuildHud()
        {
#if UNITY_2022_2_OR_NEWER
            font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
#else
            font = Resources.GetBuiltinResource<Font>("Arial.ttf");
#endif
            // event system (module depends on which input backend the project uses)
            var es = new GameObject("EventSystem", typeof(EventSystem));
#if ENABLE_INPUT_SYSTEM
            es.AddComponent<InputSystemUIInputModule>();
#else
            es.AddComponent<StandaloneInputModule>();
#endif

            var canvasGO = new GameObject("HUD", typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
            var canvas = canvasGO.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            var scaler = canvasGO.GetComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920f, 1080f);
            scaler.matchWidthOrHeight = 0.5f;
            var hud = canvasGO.AddComponent<HudController>();
            var root = canvasGO.transform;

            Vector2 TL = new Vector2(0f, 1f), TR = new Vector2(1f, 1f), BL = new Vector2(0f, 0f), BR = new Vector2(1f, 0f), C = new Vector2(0.5f, 0.5f), BC = new Vector2(0.5f, 0f);

            // top-left readouts
            hud.timeText = Txt("Time", root, TL, TL, new Vector2(40f, -30f), new Vector2(500f, 70f), 56, TextAnchor.UpperLeft);
            hud.distanceText = Txt("Distance", root, TL, TL, new Vector2(40f, -100f), new Vector2(500f, 50f), 36, TextAnchor.UpperLeft);

            // top-right buttons
            hud.restartButton = MakeButton(MakeRect("RestartButton", root, TR, TR, TR, new Vector2(-30f, -30f), new Vector2(90f, 90f)), Spr("UI/icon_restart.png"));
            hud.cameraButton = MakeButton(MakeRect("CameraButton", root, TR, TR, TR, new Vector2(-140f, -30f), new Vector2(100f, 90f)), Spr("UI/icon_camera.png"));
            hud.pauseButton = MakeButton(MakeRect("PauseButton", root, TR, TR, TR, new Vector2(-260f, -30f), new Vector2(100f, 90f)), Spr("UI/icon_menu.png"));

            // speed gauge (bottom-right)
            var gaugeRoot = MakeRect("Gauge", root, BR, BR, new Vector2(0.5f, 0.5f), new Vector2(-230f, 230f), new Vector2(380f, 380f));
            var trackRT = MakeRect("Track", gaugeRoot, C, C, C, Vector2.zero, new Vector2(380f, 380f));
            Img(trackRT, Spr("UI/gauge_track.png"), false);
            var fillRT = MakeRect("Fill", gaugeRoot, C, C, C, Vector2.zero, new Vector2(380f, 380f));
            var fill = Img(fillRT, Spr("UI/gauge_fill.png"), false);
            fill.type = Image.Type.Filled;
            fill.fillMethod = Image.FillMethod.Radial360;
            fill.fillOrigin = (int)Image.Origin360.Bottom;
            fill.fillClockwise = true;
            fill.fillAmount = 0.125f;
            var needleRT = MakeRect("Needle", gaugeRoot, C, C, C, Vector2.zero, new Vector2(330f, 330f));
            Img(needleRT, Spr("UI/gauge_needle.png"), false);
            hud.gaugeFill = fill;
            hud.needle = needleRT;
            hud.speedText = Txt("Speed", gaugeRoot, C, C, new Vector2(0f, -85f), new Vector2(300f, 60f), 44, TextAnchor.MiddleCenter);

            // respawn button (R tile)
            hud.respawnButton = MakeButton(MakeRect("RespawnButton", root, BR, BR, new Vector2(0.5f, 0.5f), new Vector2(-520f, 110f), new Vector2(130f, 130f)), Spr("UI/button_respawn.png"));

            // touch joystick (bottom-left, mobile only)
            var ringRT = MakeRect("Joystick", root, BL, BL, new Vector2(0.5f, 0.5f), new Vector2(230f, 230f), new Vector2(320f, 320f));
            Img(ringRT, Spr("UI/joystick_ring.png"), true);
            var knobRT = MakeRect("Knob", ringRT, C, C, C, Vector2.zero, new Vector2(120f, 120f));
            Img(knobRT, Spr("UI/joystick_knob.png"), false);
            var joy = ringRT.gameObject.AddComponent<VirtualJoystick>();
            joy.ring = ringRT;
            joy.knob = knobRT;

            // controls hint
            var hint = Txt("Hint", root, BC, BC, new Vector2(0f, 20f), new Vector2(1200f, 40f), 26, TextAnchor.MiddleCenter);
            hint.text = "A / D  gas & brake      W / S  lean      R  respawn      C  camera      Esc  pause";
            hint.color = new Color(1f, 1f, 1f, 0.85f);

            // centre message
            hud.messageText = Txt("Message", root, C, C, new Vector2(0f, 120f), new Vector2(1400f, 400f), 90, TextAnchor.MiddleCenter);
            hud.messageText.gameObject.SetActive(false);

            // pause panel (uses the supplied key-art as its backdrop)
            var panelRT = MakeRect("PausePanel", root, Vector2.zero, Vector2.one, C, Vector2.zero, Vector2.zero);
            var panelImg = Img(panelRT, Spr("Environment/trail_reference_splash.png"), false);
            panelImg.preserveAspect = false;
            panelImg.color = new Color(0.45f, 0.45f, 0.45f, 1f);
            var pt = Txt("PausedText", panelRT, C, C, Vector2.zero, new Vector2(1400f, 300f), 96, TextAnchor.MiddleCenter);
            pt.text = "PAUSED\n<size=36>Esc to resume  -  Enter to restart</size>";
            pt.supportRichText = true;
            panelRT.gameObject.SetActive(false);
            hud.pausePanel = panelRT.gameObject;

            return hud;
        }
    }
}
