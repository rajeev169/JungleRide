# Offroad Cycling – Unity 2D starter

A side-scrolling downhill/offroad bike game built from your art. Terrain is procedural, the bike is a
physics ride (two wheels + suspension), with parallax sky/hills, palms, foliage, rock obstacles, a speed
gauge HUD, checkpoints, respawn and a finish line.

## Setup (2 minutes)
1. Create a new Unity project from the **2D** template (2021.3 LTS or newer; Unity 6 works too).
2. Copy this project's `Assets/` folder into your project's `Assets/` (merge).
3. Wait for the import to finish, then use the menu **Offroad Cycling > Build Demo Scene**.
4. Press **Play**.

Works with the old Input Manager, the new Input System, or both. If you see a text/font error in the HUD,
make sure the project uses the built-in `LegacyRuntime.ttf` (Unity 2022.2+) or `Arial.ttf` (older).

## Controls
| Key | Action |
|---|---|
| D / Right | gas |
| A / Left | brake (then slow reverse) |
| W / Up | lean back (wheelie / pitch up in the air) |
| S / Down | lean forward |
| R | respawn at last checkpoint |
| C | cycle camera zoom |
| Esc / P | pause (Enter restarts) |

On phones/tablets the on-screen joystick appears: left/right = gas/brake, up/down = lean.

## How your assets are used
| Your file | Used as |
|---|---|
| `tropical_island_sky_background.png` | seamless scrolling sky (mirrored to tile) |
| `terrain_material_texture_sheet.png` | trail dirt, grass hillside and dark soil tiles (+ normal maps, optional) |
| `coconut_palm_trees_collection.png` | 3 cut-out palms along the ridge |
| `tropical_plants_collection.png` | fern / grass tuft / bush cut-outs on the hillside |
| `mossy_rocks_collection.png` | 3 rocks: obstacles on the trail + decoration |
| `bike_game_hud_controls_sheet.png` | joystick, menu/camera/restart icons, R respawn button |
| `tropical_mountain_bike_trail.png` | pause-screen key art |

Generated for you (not in your sheets): the bike + rider sprites (drawn to match your green/black/gold
palette), the speedometer arc + needle (so they can fill radially), the far/near hill silhouettes,
and the checkered finish flag.

## Tuning
* **Course**: select `Trail` > `TrailGenerator` – length, seed, descent, roll amplitude, jump count/height.
* **Feel**: select `Bike` > `BikeController` – motor torque, max speed, lean torque, gravity scale, suspension is on the two `WheelJoint2D`s on `Body`.
* **Density**: `Props` > `PropScatter` – palm/plant/rock spacing.
* **Camera**: `Main Camera` > `CameraFollow2D`.
* If the lime gauge arc fills the wrong way, flip `Fill Clockwise` on `HUD/Gauge/Fill`.

## Notes
* Sprite import settings (pixels-per-unit, pivots, tiling) are applied automatically on first import by `Editor/SpriteImportPostprocessor.cs`.
* The assets are flat 2D art, so this is a 2D side-view game. A 3D version would need meshes, which weren't in the pack.
