using UnityEngine;

/// <summary>
/// Real 3D brake lever and pedal, rendered by two small cameras into textures that the UI shows
/// as icons (no button background). The lever squeezes while BRAKE is held; the pedal crank turns
/// while PEDAL is held, faster when the bike is faster, and slows to a stop when you let go.
/// </summary>
public class ControlIcons : MonoBehaviour
{
    const int IconLayer = 31;                     // only the icon cameras see this layer
    static readonly Vector3 RigOrigin = new Vector3(0f, -500f, 0f);

    public RenderTexture BrakeTexture { get; private set; }
    public RenderTexture PedalTexture { get; private set; }

    BikeInput input;
    BikeController bike;
    Transform lever, crank, pedal;
    float leverAmount, crankAngle = 20f, crankSpeed;

    Material chrome, rubber, anodised, black;

    public static ControlIcons Create(BikeInput input)
    {
        var go = new GameObject("ControlIcons");
        var c = go.AddComponent<ControlIcons>();
        c.input = input;
        c.Build();
        return c;
    }

    public void SetBike(BikeController b) => bike = b;

    Material Mat(Color col, Color spec, float shininess, float rim)
    {
        var shader = Shader.Find("JungleRider/Metal");
        if (shader == null) shader = Shader.Find("Standard");
        var m = new Material(shader);
        m.SetColor("_Color", col);
        m.SetColor("_SpecColor", spec);
        m.SetFloat("_Shininess", shininess);
        m.SetFloat("_Rim", rim);
        return m;
    }

    void Build()
    {
        chrome = Mat(new Color(0.82f, 0.84f, 0.87f), new Color(1f, 1f, 1f), 0.35f, 0.45f);
        rubber = Mat(new Color(0.07f, 0.07f, 0.07f), new Color(0.15f, 0.15f, 0.15f), 0.08f, 0.15f);
        anodised = Mat(new Color(0.16f, 0.16f, 0.18f), new Color(0.6f, 0.6f, 0.65f), 0.4f, 0.25f);
        black = Mat(new Color(0.1f, 0.1f, 0.1f), new Color(0.4f, 0.4f, 0.4f), 0.3f, 0.2f);

        BrakeTexture = MakeTexture(352, 336);
        PedalTexture = MakeTexture(352, 432);

        BuildBrake(new GameObject("BrakeRig").transform);
        BuildPedal(new GameObject("PedalRig").transform);

        // lights that only touch the icons
        AddLight(new Vector3(40f, -30f, 0f), 1.25f, Color.white);
        AddLight(new Vector3(-20f, 140f, 0f), 0.55f, new Color(0.62f, 0.77f, 1f));
        AddLight(new Vector3(-50f, 20f, 0f), 0.4f, Color.white);
    }

    RenderTexture MakeTexture(int w, int h)
    {
        var rt = new RenderTexture(w, h, 16, RenderTextureFormat.ARGB32) { antiAliasing = 4, name = "IconRT" };
        rt.Create();
        return rt;
    }

    void AddLight(Vector3 euler, float intensity, Color color)
    {
        var l = new GameObject("IconLight").AddComponent<Light>();
        l.transform.SetParent(transform, false);
        l.type = LightType.Directional;
        l.transform.rotation = Quaternion.Euler(euler);
        l.intensity = intensity;
        l.color = color;
        l.cullingMask = 1 << IconLayer;
        l.shadows = LightShadows.None;
    }

    Camera AddCamera(Transform rig, RenderTexture rt, Vector3 localPos, Vector3 lookAt)
    {
        var cam = new GameObject("IconCamera").AddComponent<Camera>();
        cam.transform.SetParent(rig, false);
        cam.transform.localPosition = localPos;
        cam.transform.LookAt(rig.TransformPoint(lookAt));
        cam.clearFlags = CameraClearFlags.SolidColor;
        cam.backgroundColor = new Color(0f, 0f, 0f, 0f);
        cam.cullingMask = 1 << IconLayer;
        cam.fieldOfView = 32f;
        cam.nearClipPlane = 0.1f;
        cam.farClipPlane = 30f;
        cam.targetTexture = rt;
        cam.depth = -10;
        cam.allowHDR = false;
        cam.allowMSAA = true;
        return cam;
    }

    // ---------- shape helpers (Unity primitives, smooth and shiny) ----------
    Transform Prim(PrimitiveType type, Transform parent, Material mat)
    {
        var go = GameObject.CreatePrimitive(type);
        var col = go.GetComponent<Collider>();
        if (col) Destroy(col);
        go.layer = IconLayer;
        go.transform.SetParent(parent, false);
        var r = go.GetComponent<MeshRenderer>();
        r.sharedMaterial = mat;
        r.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
        r.receiveShadows = false;
        return go.transform;
    }

    /// <summary>Round bar from a to b (local space).</summary>
    Transform Bar(Transform parent, Vector3 a, Vector3 b, float radius, Material mat)
    {
        var t = Prim(PrimitiveType.Cylinder, parent, mat);
        Vector3 d = b - a;
        t.localPosition = (a + b) * 0.5f;
        t.localRotation = Quaternion.FromToRotation(Vector3.up, d.normalized);
        t.localScale = new Vector3(radius * 2f, d.magnitude * 0.5f, radius * 2f);
        return t;
    }

    void Ball(Transform parent, Vector3 p, float radius, Material mat)
    {
        var t = Prim(PrimitiveType.Sphere, parent, mat);
        t.localPosition = p;
        t.localScale = Vector3.one * radius * 2f;
    }

    void Block(Transform parent, Vector3 p, Vector3 size, Material mat)
    {
        var t = Prim(PrimitiveType.Cube, parent, mat);
        t.localPosition = p;
        t.localScale = size;
    }

    void Tube(Transform parent, Vector3[] pts, float radius, Material mat)
    {
        for (int i = 0; i < pts.Length - 1; i++)
        {
            Bar(parent, pts[i], pts[i + 1], radius, mat);
            if (i > 0) Ball(parent, pts[i], radius, mat);
        }
    }

    static Vector3[] Smooth(Vector3[] ctrl, int steps)
    {
        // Catmull-Rom through the control points
        var list = new System.Collections.Generic.List<Vector3>();
        for (int i = 0; i < ctrl.Length - 1; i++)
        {
            Vector3 p0 = ctrl[Mathf.Max(0, i - 1)], p1 = ctrl[i], p2 = ctrl[i + 1], p3 = ctrl[Mathf.Min(ctrl.Length - 1, i + 2)];
            for (int s = 0; s < steps; s++)
            {
                float t = s / (float)steps, t2 = t * t, t3 = t2 * t;
                list.Add(0.5f * (2f * p1 + (-p0 + p2) * t + (2f * p0 - 5f * p1 + 4f * p2 - p3) * t2 + (-p0 + 3f * p1 - 3f * p2 + p3) * t3));
            }
        }
        list.Add(ctrl[ctrl.Length - 1]);
        return list.ToArray();
    }

    // ---------- brake lever on a handlebar ----------
    void BuildBrake(Transform rig)
    {
        rig.SetParent(transform, false);
        rig.position = RigOrigin + new Vector3(-50f, 0f, 0f);
        AddCamera(rig, BrakeTexture, new Vector3(-0.3f, 1.0f, -4.4f), new Vector3(-0.45f, -0.12f, 0f));

        var g = new GameObject("Handlebar").transform;
        g.SetParent(rig, false);
        g.gameObject.layer = IconLayer;
        g.localRotation = Quaternion.Euler(-14f, 0f, 0f);

        Bar(g, new Vector3(-1.65f, 0, 0), new Vector3(0.65f, 0, 0), 0.11f, anodised);         // bar
        Bar(g, new Vector3(-1.62f, 0, 0), new Vector3(-0.28f, 0, 0), 0.19f, rubber);          // grip
        for (int i = 0; i < 9; i++)                                                            // grip ridges
        {
            float x = -1.55f + i * 0.15f;
            Bar(g, new Vector3(x - 0.022f, 0, 0), new Vector3(x + 0.022f, 0, 0), 0.205f, rubber);
        }
        Bar(g, new Vector3(-1.66f, 0, 0), new Vector3(-1.6f, 0, 0), 0.2f, anodised);          // end cap
        Block(g, Vector3.zero, new Vector3(0.32f, 0.5f, 0.5f), chrome);                        // clamp
        Bar(g, new Vector3(0.17f, 0.12f, -0.12f), new Vector3(0.59f, 0.12f, -0.12f), 0.15f, black); // reservoir
        Tube(g, Smooth(new[] { new Vector3(0.4f, 0.2f, -0.1f), new Vector3(0.65f, 0.55f, 0f), new Vector3(0.8f, 0.85f, 0.3f) }, 6), 0.045f, rubber); // cable

        lever = new GameObject("Lever").transform;
        // (all primitives are put on the icon layer when created)
        lever.SetParent(g, false);
        lever.localPosition = new Vector3(0.05f, -0.12f, -0.28f);
        var blade = new GameObject("Blade").transform;
        blade.SetParent(lever, false);
        blade.localScale = new Vector3(1f, 0.78f, 1f);
        Tube(blade, Smooth(new[] { Vector3.zero, new Vector3(-0.35f, -0.1f, -0.12f), new Vector3(-0.9f, -0.2f, -0.24f), new Vector3(-1.55f, -0.22f, -0.3f) }, 6), 0.09f, chrome);
        Ball(lever, new Vector3(-1.58f, -0.17f, -0.3f), 0.12f, chrome);                         // round tip
        Bar(lever, new Vector3(0, -0.1f, 0), new Vector3(0, 0.12f, 0), 0.06f, black);         // pivot bolt
    }

    // ---------- flat pedal on a crank arm ----------
    void BuildPedal(Transform rig)
    {
        rig.SetParent(transform, false);
        rig.position = RigOrigin + new Vector3(50f, 0f, 0f);
        AddCamera(rig, PedalTexture, new Vector3(2.6f, 0.4f, -6.6f), new Vector3(0.15f, -0.95f, -0.4f));

        crank = new GameObject("Crank").transform;
        crank.SetParent(rig, false);
        Block(crank, new Vector3(0, -0.8f, 0), new Vector3(0.28f, 1.75f, 0.2f), anodised);    // arm
        Bar(crank, new Vector3(0, 0, 0.12f), new Vector3(0, 0, -0.12f), 0.2f, chrome);        // spindle bolt

        pedal = new GameObject("Pedal").transform;
        pedal.SetParent(crank, false);
        pedal.localPosition = new Vector3(0, -1.6f, -0.62f);
        Bar(pedal, new Vector3(0, 0, 0.62f), new Vector3(0, 0, -0.52f), 0.075f, chrome);     // axle
        const float W = 1.1f, D = 1.0f, Tk = 0.14f, B = 0.13f;
        Block(pedal, new Vector3(0, 0, D / 2 - B / 2), new Vector3(W, Tk, B), black);
        Block(pedal, new Vector3(0, 0, -D / 2 + B / 2), new Vector3(W, Tk, B), black);
        Block(pedal, new Vector3(W / 2 - B / 2, 0, 0), new Vector3(B, Tk, D), black);
        Block(pedal, new Vector3(-W / 2 + B / 2, 0, 0), new Vector3(B, Tk, D), black);
        for (int i = 0; i < 6; i++)                                                            // grip pins
            foreach (float z in new[] { D / 2 - B / 2, -D / 2 + B / 2 })
                foreach (float y in new[] { Tk / 2 + 0.05f, -Tk / 2 - 0.05f })
                    Bar(pedal, new Vector3(-W / 2 + 0.1f + i * (W - 0.2f) / 5f, y - 0.06f, z), new Vector3(-W / 2 + 0.1f + i * (W - 0.2f) / 5f, y + 0.06f, z), 0.03f, chrome);

        SetLayer(rig);
    }

    static void SetLayer(Transform t)
    {
        t.gameObject.layer = IconLayer;
        foreach (Transform c in t) SetLayer(c);
    }

    void Update()
    {
        float dt = Time.unscaledDeltaTime;
        bool paused = Time.timeScale == 0f;

        // brake lever squeeze
        float brake = input && !paused ? input.Brake : 0f;
        leverAmount = Mathf.MoveTowards(leverAmount, brake, dt * 7f);
        if (lever) lever.localRotation = Quaternion.Euler(0f, 18f * leverAmount, 0f);

        // pedal crank: turns with the bike's speed while pedalling, coasts to a stop otherwise
        if (!paused)
        {
            float speed = bike ? Mathf.Abs(bike.ForwardSpeed) : 0f;
            bool pedalling = input && input.Throttle > 0f;
            float target = pedalling ? (2.2f + speed * 0.45f) : 0f;       // radians per second
            crankSpeed = Mathf.Lerp(crankSpeed, target, dt * (pedalling ? 3f : 1.4f));
            crankAngle -= crankSpeed * Mathf.Rad2Deg * dt;
        }
        if (crank) crank.localRotation = Quaternion.Euler(0f, 0f, crankAngle);
        if (pedal) pedal.localRotation = Quaternion.Euler(0f, 0f, -crankAngle);
    }

    /// <summary>The main camera must not see the icon layer.</summary>
    public static int HideFromMainCamera(int mask) => mask & ~(1 << IconLayer);
}
