# Downhill Rush – Unity prototype (based on your reference video)

A mobile-style downhill mountain-bike game: tropical island dirt trail, kickers/tabletops, rear chase
camera, green km/h gauge, two on-screen joysticks (L/R), "R" counter, dust on braking/landing.
Everything (terrain, trees, ocean, rider, bike, HUD) is generated from code – no assets or scene setup.

## Run it
1. Unity 2021.3 LTS or newer (tested layout for Unity 6 too). Create a new **3D** project (Built-in or URP).
2. Copy the `Assets/Scripts` folder into your project's `Assets/`.
3. Open any scene (even the empty default one) and press **Play**. `GameBootstrap` starts everything.
4. If keys do nothing: Edit > Project Settings > Player > Active Input Handling = *Both* (or either one; both are supported).

## Controls
| Action | Keyboard | Touch |
|---|---|---|
| Steer | A/D or arrows | drag left stick (left half) |
| Pedal | W / Up | drag right stick up |
| Brake | S / Down | drag right stick down |
| Jump | Space | quick tap on right half |
| Lean in air | W/S | right stick up/down |
| Reset / camera | R / C | top-right buttons |

## Build for Android/iOS
File > Build Settings > Android (or iOS) > Switch Platform > Build. Orientation is forced to landscape in code.

## Tweaking (all numbers are constants at the top of each file)
- `TrackBuilder`: `Length`, `Slope` (steeper = faster), `Jumps[]` positions, `CenterX()` for the curves.
- `BikeController`: `MaxSpeed`, turn rate, jump impulse (5.2), drag (0.0035).
- `FollowCam`: `Dist[]` / `Height[]` camera presets.
