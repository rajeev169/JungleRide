using System.Collections.Generic;
using UnityEngine;
#if !ENABLE_LEGACY_INPUT_MANAGER && ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

/// <summary>
/// One input layer for keyboard + two virtual touch joysticks (like the reference video).
///   Left stick  : steer (drag left/right)
///   Right stick : drag up = pedal / lean back in air, drag down = brake, quick tap = jump
/// Keyboard      : A/D or arrows steer, W/Up pedal, S/Down brake, Space jump, R reset, C camera.
/// Works with the old Input Manager and the new Input System package.
/// </summary>
public static class GameInput
{
    public class Stick
    {
        public bool active; public int id; public Vector2 origin, pos; public float t0;
        public Vector2 Delta
        {
            get
            {
                if (!active) return Vector2.zero;
                float radius = 70f * Screen.height / 720f;
                return Vector2.ClampMagnitude((pos - origin) / radius, 1f);
            }
        }
    }

    public static readonly Stick Left = new Stick();
    public static readonly Stick Right = new Stick();

    public static float steer, pitch;
    public static bool pedal, brake, jump, reset, camera;

    struct TouchInfo { public int id; public Vector2 pos; public bool began, ended; }
    static readonly List<TouchInfo> touches = new List<TouchInfo>();

    enum Ky { Left, Right, Up, Down, Space, R, C }

    public static void Poll()
    {
        jump = reset = camera = false;
        float ks = (Held(Ky.Right) ? 1f : 0f) - (Held(Ky.Left) ? 1f : 0f);
        bool up = Held(Ky.Up), down = Held(Ky.Down);
        if (Pressed(Ky.Space)) jump = true;
        if (Pressed(Ky.R)) reset = true;
        if (Pressed(Ky.C)) camera = true;

        GatherTouches();
        bool leftSeen = false, rightSeen = false;
        float sc = Screen.height / 720f;
        foreach (var t in touches)
        {
            Stick s = null;
            if (Left.active && Left.id == t.id) s = Left;
            else if (Right.active && Right.id == t.id) s = Right;

            if (s == null)
            {
                bool inUi = t.pos.x > Screen.width - 230f * sc && t.pos.y > Screen.height - 230f * sc; // top-right buttons
                if (!t.began || inUi) continue;
                s = t.pos.x < Screen.width * 0.5f ? Left : Right;
                if (s.active) continue;
                s.active = true; s.id = t.id; s.origin = t.pos; s.t0 = Time.unscaledTime;
            }
            s.pos = t.pos;
            if (s == Left) leftSeen = true; else rightSeen = true;
            if (t.ended)
            {
                if (s == Right && Time.unscaledTime - s.t0 < 0.25f && (s.pos - s.origin).magnitude < 20f * sc) jump = true;
                s.active = false;
            }
        }
        if (!leftSeen) Left.active = false;
        if (!rightSeen) Right.active = false;

        steer = Mathf.Abs(ks) > 0.01f ? ks : Left.Delta.x;
        float ry = Right.Delta.y;
        pitch = (up ? 1f : 0f) - (down ? 1f : 0f) + ry;
        pedal = up || ry > 0.45f;
        brake = down || ry < -0.45f;
    }

#if ENABLE_LEGACY_INPUT_MANAGER
    static bool Held(Ky k)
    {
        switch (k)
        {
            case Ky.Left: return Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow);
            case Ky.Right: return Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow);
            case Ky.Up: return Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow);
            case Ky.Down: return Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.DownArrow);
            case Ky.Space: return Input.GetKey(KeyCode.Space);
            case Ky.R: return Input.GetKey(KeyCode.R);
            default: return Input.GetKey(KeyCode.C);
        }
    }
    static bool Pressed(Ky k)
    {
        switch (k)
        {
            case Ky.Space: return Input.GetKeyDown(KeyCode.Space);
            case Ky.R: return Input.GetKeyDown(KeyCode.R);
            case Ky.C: return Input.GetKeyDown(KeyCode.C);
            default: return false;
        }
    }
    static void GatherTouches()
    {
        touches.Clear();
        for (int i = 0; i < Input.touchCount; i++)
        {
            var t = Input.GetTouch(i);
            touches.Add(new TouchInfo
            {
                id = t.fingerId, pos = t.position,
                began = t.phase == UnityEngine.TouchPhase.Began,
                ended = t.phase == UnityEngine.TouchPhase.Ended || t.phase == UnityEngine.TouchPhase.Canceled
            });
        }
    }
#elif ENABLE_INPUT_SYSTEM
    static bool Held(Ky k)
    {
        var kb = Keyboard.current; if (kb == null) return false;
        switch (k)
        {
            case Ky.Left: return kb.aKey.isPressed || kb.leftArrowKey.isPressed;
            case Ky.Right: return kb.dKey.isPressed || kb.rightArrowKey.isPressed;
            case Ky.Up: return kb.wKey.isPressed || kb.upArrowKey.isPressed;
            case Ky.Down: return kb.sKey.isPressed || kb.downArrowKey.isPressed;
            case Ky.Space: return kb.spaceKey.isPressed;
            case Ky.R: return kb.rKey.isPressed;
            default: return kb.cKey.isPressed;
        }
    }
    static bool Pressed(Ky k)
    {
        var kb = Keyboard.current; if (kb == null) return false;
        switch (k)
        {
            case Ky.Space: return kb.spaceKey.wasPressedThisFrame;
            case Ky.R: return kb.rKey.wasPressedThisFrame;
            case Ky.C: return kb.cKey.wasPressedThisFrame;
            default: return false;
        }
    }
    static void GatherTouches()
    {
        touches.Clear();
        var ts = Touchscreen.current; if (ts == null) return;
        foreach (var t in ts.touches)
        {
            var ph = t.phase.ReadValue();
            if (ph == UnityEngine.InputSystem.TouchPhase.None) continue;
            touches.Add(new TouchInfo
            {
                id = t.touchId.ReadValue(), pos = t.position.ReadValue(),
                began = ph == UnityEngine.InputSystem.TouchPhase.Began,
                ended = ph == UnityEngine.InputSystem.TouchPhase.Ended || ph == UnityEngine.InputSystem.TouchPhase.Canceled
            });
        }
    }
#else
    static bool Held(Ky k) { return false; }
    static bool Pressed(Ky k) { return false; }
    static void GatherTouches() { touches.Clear(); }
#endif
}
