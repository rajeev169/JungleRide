using UnityEngine;

/// <summary>
/// Entry point. Runs automatically when you press Play in ANY scene (even an empty one), and in builds.
/// It reuses the scene's Main Camera / Directional Light if present, otherwise creates them.
/// </summary>
public static class GameBootstrap
{
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    static void Init()
    {
        if (Object.FindObjectOfType<BikeController>() != null) return; // already running

        Application.targetFrameRate = 60;
        QualitySettings.shadowDistance = 90f;
        Screen.sleepTimeout = SleepTimeout.NeverSleep;
        Screen.orientation = ScreenOrientation.LandscapeLeft;
        Screen.fullScreen = true;

        // --- Atmosphere: bright tropical daylight with distance haze ---
        Color sky = new Color(0.50f, 0.74f, 0.95f);
        RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Flat;
        RenderSettings.ambientLight = new Color(0.62f, 0.68f, 0.75f);
        RenderSettings.fog = true;
        RenderSettings.fogMode = FogMode.Linear;
        RenderSettings.fogColor = new Color(0.72f, 0.86f, 0.95f);
        RenderSettings.fogStartDistance = 90f;
        RenderSettings.fogEndDistance = 380f;

        // --- Sun (long shadows like the reference) ---
        Light sun = null;
        foreach (var l in Object.FindObjectsOfType<Light>()) if (l.type == LightType.Directional) { sun = l; break; }
        if (sun == null) sun = new GameObject("Sun").AddComponent<Light>();
        sun.type = LightType.Directional;
        sun.transform.rotation = Quaternion.Euler(38f, -35f, 0f);
        sun.color = new Color(1f, 0.96f, 0.86f);
        sun.intensity = 1.25f;
        sun.shadows = LightShadows.Soft;

        // --- Camera ---
        Camera cam = Camera.main;
        if (cam == null)
        {
            var cgo = new GameObject("Main Camera") { tag = "MainCamera" };
            cam = cgo.AddComponent<Camera>();
            cgo.AddComponent<AudioListener>();
        }
        cam.clearFlags = CameraClearFlags.SolidColor;
        cam.backgroundColor = sky;
        cam.nearClipPlane = 0.2f;
        cam.farClipPlane = 600f;

        // --- World ---
        TrackBuilder.Build();
        var bike = BikeController.Create();

        var follow = cam.GetComponent<FollowCam>();
        if (follow == null) follow = cam.gameObject.AddComponent<FollowCam>();
        follow.bike = bike;
        follow.Snap();

        var hud = new GameObject("HUD").AddComponent<Hud>();
        hud.bike = bike;
        hud.cam = follow;
    }
}
