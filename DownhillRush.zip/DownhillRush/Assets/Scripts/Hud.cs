using UnityEngine;

/// <summary>
/// Immediate-mode HUD that mimics the reference: two on-screen joysticks (L / R), a green km/h gauge at the
/// bottom right, an "R" counter at the bottom centre and small menu / camera / reset buttons at the top right.
/// </summary>
public class Hud : MonoBehaviour
{
    public BikeController bike;
    public FollowCam cam;

    Texture2D ring, disc, white, arc;
    GUIStyle big, small, tiny;
    static readonly Color Green = new Color(0.55f, 1f, 0.15f);

    void Awake()
    {
        ring = MakeCircle(128, true);
        disc = MakeCircle(128, false);
        white = new Texture2D(1, 1); white.SetPixel(0, 0, Color.white); white.Apply();
    }

    void Update() { GameInput.Poll(); }

    static Texture2D MakeCircle(int s, bool ringOnly)
    {
        var t = new Texture2D(s, s, TextureFormat.RGBA32, false) { filterMode = FilterMode.Bilinear };
        float r = s * 0.5f - 2f;
        for (int y = 0; y < s; y++)
            for (int x = 0; x < s; x++)
            {
                float d = Vector2.Distance(new Vector2(x, y), new Vector2(s * 0.5f, s * 0.5f));
                float a = ringOnly ? Mathf.Clamp01(1.5f - Mathf.Abs(d - r) * 0.9f) : Mathf.Clamp01(r - d);
                t.SetPixel(x, y, new Color(1, 1, 1, a));
            }
        t.Apply();
        return t;
    }

    void EnsureStyles()
    {
        if (big != null) return;
        big = new GUIStyle(GUI.skin.label) { fontSize = 46, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleRight };
        small = new GUIStyle(GUI.skin.label) { fontSize = 20, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleLeft };
        tiny = new GUIStyle(GUI.skin.label) { fontSize = 15, alignment = TextAnchor.MiddleLeft };
    }

    void OnGUI()
    {
        if (bike == null) return;
        EnsureStyles();
        float s = Screen.height / 720f;
        float W = Screen.width / s, H = 720f;
        Matrix4x4 baseM = Matrix4x4.Scale(new Vector3(s, s, 1f));
        GUI.matrix = baseM;
        Rect safe = Screen.safeArea;
        float topInset = Mathf.Max(0f, (Screen.height - safe.yMax) / s);
        float leftInset = Mathf.Max(0f, safe.x / s);
        float rightInset = Mathf.Max(0f, (Screen.width - safe.xMax) / s);

        // --- Joysticks ---
        DrawStick(GameInput.Left, new Vector2(110f, H - 110f), s, H);
        DrawStick(GameInput.Right, new Vector2(W - 110f, H - 110f), s, H);
        GUI.color = new Color(1, 1, 1, 0.8f);
        GUI.Label(new Rect(98f, H - 124f, 24f, 24f), "L", tiny);
        GUI.Label(new Rect(W - 122f, H - 124f, 24f, 24f), "R", tiny);

        // --- Speed gauge (bottom right) ---
        float kmh = bike.SpeedKmh;
        float frac = Mathf.Clamp01(kmh / 90f);
        Rect bar = new Rect(W - 250f, H - 38f, 200f, 8f);
        GUI.color = new Color(1, 1, 1, 0.25f); GUI.DrawTexture(bar, white);
        GUI.color = Green; GUI.DrawTexture(new Rect(bar.x, bar.y, bar.width * frac, bar.height), white);
        big.normal.textColor = Green;
        GUI.color = Color.white;
        GUI.Label(new Rect(W - 330f, H - 120f, 160f, 60f), Mathf.RoundToInt(kmh).ToString(), big);
        small.normal.textColor = Color.white;
        GUI.Label(new Rect(W - 165f, H - 105f, 80f, 30f), "km/h", small);

        // --- Bottom-centre counter ("R 0" in the reference) ---
        GUI.color = Color.white;
        GUI.DrawTexture(new Rect(W * 0.5f - 60f, H - 40f, 26f, 24f), white);
        GUI.color = Color.black;
        GUI.Label(new Rect(W * 0.5f - 55f, H - 41f, 24f, 24f), "R", small);
        GUI.color = Color.white;
        GUI.Label(new Rect(W * 0.5f - 26f, H - 41f, 120f, 24f), bike.Resets.ToString(), small);

        GUI.matrix = baseM * Matrix4x4.Translate(new Vector3(leftInset, topInset, 0f));
        // --- Top-left: distance + airtime ---
        GUI.color = new Color(1, 1, 1, 0.85f);
        float pct = Mathf.Clamp01(bike.TrailT / TrackBuilder.Length);
        GUI.DrawTexture(new Rect(14f, 14f, 160f, 8f), white);
        GUI.color = Green; GUI.DrawTexture(new Rect(14f, 14f, 160f * pct, 8f), white);
        GUI.color = Color.white;
        GUI.Label(new Rect(14f, 26f, 300f, 22f), Mathf.RoundToInt(bike.TrailT) + " / " + (int)TrackBuilder.Length + " m", tiny);
        GUI.Label(new Rect(14f, 46f, 300f, 22f), "Last air " + bike.LastAirtime.ToString("0.0") + " s   Best " + bike.BestAirtime.ToString("0.0") + " s", tiny);
        GUI.Label(new Rect(14f, 66f, 300f, 22f), "Top speed " + Mathf.RoundToInt(bike.BestSpeedKmh) + " km/h", tiny);

        GUI.matrix = baseM * Matrix4x4.Translate(new Vector3(-rightInset, topInset, 0f));
        // --- Top-right buttons ---
        if (GUI.Button(new Rect(W - 150f, 12f, 40f, 40f), "↺")) bike.ManualReset();
        if (GUI.Button(new Rect(W - 104f, 12f, 40f, 40f), "▣") && cam != null) cam.NextMode();

        // Keyboard hint for desktop testing.
        if (Application.isEditor || Application.platform == RuntimePlatform.WindowsPlayer || Application.platform == RuntimePlatform.OSXPlayer || Application.platform == RuntimePlatform.LinuxPlayer)
        {
            GUI.color = new Color(1, 1, 1, 0.7f);
            GUI.Label(new Rect(W * 0.5f - 260f, 12f, 520f, 22f), "A/D steer  •  W pedal  •  S brake  •  Space jump  •  W/S in air = lean  •  R reset  •  C camera", tiny);
        }
        GUI.matrix = baseM;
    }

    void DrawStick(GameInput.Stick st, Vector2 idleCentre, float s, float H)
    {
        Vector2 c = idleCentre, thumb = idleCentre;
        if (st.active)
        {
            c = new Vector2(st.origin.x / s, H - st.origin.y / s);
            thumb = c + new Vector2(st.Delta.x, -st.Delta.y) * 70f;
        }
        GUI.color = new Color(1, 1, 1, st.active ? 0.9f : 0.55f);
        GUI.DrawTexture(new Rect(c.x - 60f, c.y - 60f, 120f, 120f), ring);
        GUI.color = new Color(1, 1, 1, st.active ? 0.8f : 0.35f);
        GUI.DrawTexture(new Rect(thumb.x - 16f, thumb.y - 16f, 32f, 32f), disc);
        GUI.color = Color.white;
    }
}
