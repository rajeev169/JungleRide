using UnityEngine;

/// <summary>
/// Downhill bike: a slick rolling sphere (rigidbody) steered with arcade rules, plus a procedurally built
/// rider/bike visual that leans, pitches, spins its wheels and kicks up dust.
/// </summary>
public class BikeController : MonoBehaviour
{
    public const float Radius = 0.45f;
    public const float MaxSpeed = 24f;      // m/s  (~86 km/h)

    public float yaw = 180f;                // heading in degrees (180 = toward -Z, down the course)
    public bool Grounded { get; private set; }
    public float SpeedKmh { get { return Vel.magnitude * 3.6f; } }
    public float TrailT { get { return -transform.position.z; } }
    public float LastAirtime, BestSpeedKmh, BestAirtime;
    public int Resets;

    Rigidbody rb;
    Transform visual, wheelF, wheelR;
    ParticleSystem dust;
    Vector3 visFwd = Vector3.back, visUp = Vector3.up, groundNormal = Vector3.up;
    float airTime, pitch, lean, wheelAngle, prevVy;
    bool wantJump, wasGrounded;
    float groundedGrace;

    Vector3 Vel
    {
        get
        {
#if UNITY_6000_0_OR_NEWER
            return rb.linearVelocity;
#else
            return rb.velocity;
#endif
        }
        set
        {
#if UNITY_6000_0_OR_NEWER
            rb.linearVelocity = value;
#else
            rb.velocity = value;
#endif
        }
    }

    public static BikeController Create()
    {
        var go = new GameObject("BikeBody");
        return go.AddComponent<BikeController>();
    }

    void Awake()
    {
        gameObject.layer = 2; // Ignore Raycast, so our own ground probe never hits us

        rb = gameObject.AddComponent<Rigidbody>();
        rb.mass = 80f;
        rb.constraints = RigidbodyConstraints.FreezeRotation;
        rb.interpolation = RigidbodyInterpolation.Interpolate;
        rb.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;

        var sc = gameObject.AddComponent<SphereCollider>();
        sc.radius = Radius;
#if UNITY_6000_0_OR_NEWER
        var pm = new PhysicsMaterial("slick");
        pm.frictionCombine = PhysicsMaterialCombine.Minimum;
#else
        var pm = new PhysicMaterial("slick");
        pm.frictionCombine = PhysicMaterialCombine.Minimum;
#endif
        pm.dynamicFriction = 0.02f;
        pm.staticFriction = 0.02f;
        pm.bounciness = 0f;
        sc.material = pm;

        BuildVisual();
        ResetTo(6f);
    }

    // ---------------------------------------------------------------------------------------------

    public void ResetTo(float t)
    {
        t = Mathf.Clamp(t, 3f, TrackBuilder.Length - 20f);
        Vector3 p = TrackBuilder.PointOnTrail(t, Radius + 0.4f);
        yaw = TrackBuilder.TrailYaw(t); // heading along the trail (180 = straight down -Z)
        transform.position = p;
        rb.position = p;
        Vel = Vector3.zero;
        rb.angularVelocity = Vector3.zero;
        airTime = 0f; pitch = 0f; lean = 0f; prevVy = 0f;
        visFwd = Quaternion.Euler(0, yaw, 0) * Vector3.forward;
        visUp = Vector3.up;
        groundNormal = Vector3.up;
    }

    public void ManualReset()
    {
        Resets++;
        ResetTo(Mathf.Max(6f, TrailT - 15f));
    }

    void Update()
    {
        if (GameInput.jump) wantJump = true;
        if (GameInput.reset) ManualReset();

        // Out of bounds / fell off the hill / finished: put the rider back on the trail.
        float t = TrailT;
        float u = transform.position.x - TrackBuilder.CenterX(Mathf.Clamp(t, 0f, TrackBuilder.Length));
        if (t > TrackBuilder.Length - 6f) { ResetTo(6f); }
        else if (t < 0f || Mathf.Abs(u) > 40f || transform.position.y < TrackBuilder.Height(Mathf.Clamp(t, 0f, TrackBuilder.Length), u) - 6f)
        {
            Resets++; ResetTo(Mathf.Max(6f, t - 5f));
        }
        BestSpeedKmh = Mathf.Max(BestSpeedKmh, SpeedKmh);
    }

    void FixedUpdate()
    {
        float dt = Time.fixedDeltaTime;
        Vector3 v = Vel;

        RaycastHit hit;
        bool hitGround = Physics.Raycast(rb.position, Vector3.down, out hit, Radius + 0.25f, ~(1 << 2), QueryTriggerInteraction.Ignore);
        groundedGrace = hitGround ? 0.08f : groundedGrace - dt;
        Grounded = groundedGrace > 0f;
        if (hitGround) groundNormal = Vector3.Slerp(groundNormal, hit.normal, 0.5f).normalized;

        float spd = v.magnitude;
        float turn = Grounded ? Mathf.Lerp(120f, 48f, Mathf.Clamp01(spd / 18f)) : 65f;
        yaw += GameInput.steer * turn * dt;

        Vector3 fwd = Quaternion.Euler(0, yaw, 0) * Vector3.forward;
        Vector3 fwdG = Vector3.ProjectOnPlane(fwd, groundNormal).normalized;
        Vector3 groundPos = rb.position + Vector3.down * Radius;

        if (Grounded)
        {
            if (spd > 0.5f)
            {
                // Carve: swing the velocity toward where the bike is pointing without losing speed.
                float k = 1f - Mathf.Exp(-7f * dt);
                v = Vector3.Slerp(v / spd, fwdG, k).normalized * spd;
            }
            if (GameInput.pedal && spd < MaxSpeed * 0.8f) v += fwdG * 4f * dt;
            if (GameInput.brake)
            {
                v *= Mathf.Exp(-(spd > 3f ? 1.8f : 4f) * dt);
                if (spd > 3f) EmitDust(groundPos - fwd * 0.6f, 1);
            }
            if (wantJump)
            {
                v += groundNormal * 5.2f;
                groundedGrace = 0f; Grounded = false;
            }
            pitch = Mathf.MoveTowards(pitch, 0f, 160f * dt);
        }
        else
        {
            pitch = Mathf.Clamp(pitch + GameInput.pitch * 90f * dt, -55f, 55f);
        }
        wantJump = false;

        // Air / rolling resistance (quadratic) and a hard speed limit.
        spd = v.magnitude;
        v -= v * spd * 0.0035f * dt;
        if (v.magnitude > MaxSpeed) v = v.normalized * MaxSpeed;
        Vel = v;

        // Airtime bookkeeping + landing dust.
        if (!Grounded) airTime += dt;
        if (Grounded && !wasGrounded)
        {
            if (airTime > 0.45f) { LastAirtime = airTime; BestAirtime = Mathf.Max(BestAirtime, airTime); }
            if (prevVy < -7f) EmitDust(groundPos, 14);
            airTime = 0f;
        }
        wasGrounded = Grounded;
        prevVy = v.y;
    }

    void EmitDust(Vector3 where, int count)
    {
        dust.transform.position = where;
        dust.Emit(count);
    }

    // ---------------------------------------------------------------------------------------------

    void LateUpdate()
    {
        float dt = Time.deltaTime;
        Vector3 v = Vel;
        float spd = v.magnitude;
        Vector3 fwd = Quaternion.Euler(0, yaw, 0) * Vector3.forward;

        Vector3 targetFwd, targetUp;
        if (Grounded)
        {
            targetFwd = Vector3.ProjectOnPlane(fwd, groundNormal).normalized;
            targetUp = groundNormal;
        }
        else
        {
            float horiz = new Vector2(v.x, v.z).magnitude;
            targetFwd = (fwd + Vector3.up * Mathf.Clamp(v.y / Mathf.Max(5f, horiz), -1f, 1f)).normalized;
            targetUp = Vector3.up;
        }
        float k = 1f - Mathf.Exp(-12f * dt);
        visFwd = Vector3.Slerp(visFwd, targetFwd, k).normalized;
        visUp = Vector3.Slerp(visUp, targetUp, k).normalized;

        lean = Mathf.Lerp(lean, GameInput.steer * 22f * Mathf.Clamp01(spd / 10f + 0.3f), 1f - Mathf.Exp(-8f * dt));

        Quaternion q = Quaternion.LookRotation(visFwd, visUp)
                     * Quaternion.AngleAxis(lean, Vector3.forward)
                     * Quaternion.AngleAxis(-pitch, Vector3.right);
        visual.SetPositionAndRotation(transform.position + Vector3.down * Radius, q);

        wheelAngle += spd / 0.35f * Mathf.Rad2Deg * dt;
        wheelF.localRotation = Quaternion.Euler(wheelAngle, 0, 0);
        wheelR.localRotation = Quaternion.Euler(wheelAngle, 0, 0);
    }

    // ---------------------------------------------------------------------------------------------

    void BuildVisual()
    {
        var black = new Color(0.07f, 0.07f, 0.08f);
        var white = new Color(0.92f, 0.92f, 0.92f);
        var green = new Color(0.55f, 1.0f, 0.10f);

        visual = new GameObject("Rider").transform; // in world space, not parented to the rigidbody

        // Wheels: holder spins, tyre + green rim + valve are children.
        wheelF = MakeWheel(new Vector3(0, 0.35f, 0.62f), black, green);
        wheelR = MakeWheel(new Vector3(0, 0.35f, -0.62f), black, green);

        // Frame, fork, bars, seat.
        Mats.Prim(PrimitiveType.Cube, visual, new Vector3(0, 0.62f, 0.0f), new Vector3(0.08f, 0.08f, 0.95f), black, new Vector3(-8, 0, 0));
        Mats.Prim(PrimitiveType.Cube, visual, new Vector3(0, 0.50f, -0.25f), new Vector3(0.07f, 0.55f, 0.07f), black, new Vector3(-20, 0, 0));
        Mats.Prim(PrimitiveType.Cube, visual, new Vector3(0, 0.58f, 0.60f), new Vector3(0.07f, 0.55f, 0.07f), green, new Vector3(18, 0, 0));
        Mats.Prim(PrimitiveType.Cube, visual, new Vector3(0, 0.88f, 0.52f), new Vector3(0.62f, 0.04f, 0.04f), black);
        Mats.Prim(PrimitiveType.Cube, visual, new Vector3(0, 0.80f, -0.35f), new Vector3(0.12f, 0.05f, 0.30f), black);

        // Rider.
        Mats.Prim(PrimitiveType.Capsule, visual, new Vector3(0, 1.18f, 0.02f), new Vector3(0.34f, 0.30f, 0.34f), black, new Vector3(28, 0, 0));
        Mats.Prim(PrimitiveType.Cube, visual, new Vector3(0, 1.20f, -0.10f), new Vector3(0.10f, 0.32f, 0.04f), green, new Vector3(28, 0, 0));
        for (int s = -1; s <= 1; s += 2)
        {
            Mats.Prim(PrimitiveType.Capsule, visual, new Vector3(0.10f * s, 0.84f, -0.12f), new Vector3(0.15f, 0.32f, 0.15f), white, new Vector3(-15, 0, 0));      // thighs / shorts
            Mats.Prim(PrimitiveType.Capsule, visual, new Vector3(0.10f * s, 0.46f, -0.08f), new Vector3(0.13f, 0.26f, 0.13f), black, new Vector3(10, 0, 0));       // shins
            Mats.Prim(PrimitiveType.Capsule, visual, new Vector3(0.22f * s, 1.05f, 0.30f), new Vector3(0.10f, 0.26f, 0.10f), black, new Vector3(62, 0, 8 * s));      // arms
        }
        Mats.Prim(PrimitiveType.Sphere, visual, new Vector3(0, 1.58f, 0.22f), new Vector3(0.30f, 0.30f, 0.32f), black);          // helmet
        Mats.Prim(PrimitiveType.Cube, visual, new Vector3(0, 1.57f, 0.38f), new Vector3(0.22f, 0.07f, 0.10f), white);            // goggles
        Mats.Prim(PrimitiveType.Cube, visual, new Vector3(0, 1.74f, 0.20f), new Vector3(0.06f, 0.03f, 0.30f), green);            // helmet stripe

        // Dust particles (world space).
        var dgo = new GameObject("Dust");
        dust = dgo.AddComponent<ParticleSystem>();
        dust.Stop();
        var main = dust.main;
        main.simulationSpace = ParticleSystemSimulationSpace.World;
        main.startLifetime = 0.9f;
        main.startSpeed = 1.2f;
        main.startSize = new ParticleSystem.MinMaxCurve(0.35f, 0.8f);
        main.startColor = new Color(0.80f, 0.66f, 0.48f, 0.55f);
        main.gravityModifier = -0.05f;
        main.loop = false; main.playOnAwake = false;
        var em = dust.emission; em.enabled = false;
        var shape = dust.shape; shape.enabled = true; shape.shapeType = ParticleSystemShapeType.Sphere; shape.radius = 0.25f;
        var col = dust.colorOverLifetime; col.enabled = true;
        var grad = new Gradient();
        grad.SetKeys(new[] { new GradientColorKey(Color.white, 0f), new GradientColorKey(Color.white, 1f) },
                     new[] { new GradientAlphaKey(0.6f, 0f), new GradientAlphaKey(0f, 1f) });
        col.color = grad;
        var sz = dust.sizeOverLifetime; sz.enabled = true;
        sz.size = new ParticleSystem.MinMaxCurve(1f, new AnimationCurve(new Keyframe(0, 0.5f), new Keyframe(1, 1.6f)));
        var pr = dgo.GetComponent<ParticleSystemRenderer>();
        var sh = Shader.Find("Sprites/Default");
        if (sh != null) pr.sharedMaterial = new Material(sh);
        dust.Play();
    }

    Transform MakeWheel(Vector3 localPos, Color tyre, Color rim)
    {
        var holder = new GameObject("Wheel").transform;
        holder.SetParent(visual, false);
        holder.localPosition = localPos;
        var sideways = new Vector3(0, 0, 90);
        Mats.Prim(PrimitiveType.Cylinder, holder, Vector3.zero, new Vector3(0.70f, 0.045f, 0.70f), tyre, sideways);
        Mats.Prim(PrimitiveType.Cylinder, holder, Vector3.zero, new Vector3(0.58f, 0.05f, 0.58f), rim, sideways);
        Mats.Prim(PrimitiveType.Cylinder, holder, Vector3.zero, new Vector3(0.50f, 0.055f, 0.50f), new Color(0.12f, 0.12f, 0.12f), sideways);
        Mats.Prim(PrimitiveType.Cube, holder, new Vector3(0, 0.26f, 0), new Vector3(0.09f, 0.14f, 0.05f), Color.white); // spin marker
        return holder;
    }
}
