using UnityEngine;

/// <summary>
/// Builds the whole island downhill course procedurally: a winding dirt trail carved into a grassy hillside,
/// with rollers, kickers/tabletops, banked edges, palm trees and an ocean.
/// The track runs toward -Z. "t" = distance along the trail, "u" = sideways offset from the trail centre.
/// </summary>
public static class TrackBuilder
{
    public const float Length = 900f;     // metres of trail
    public const float Width = 90f;       // total width of terrain strip
    public const float Du = 1f;           // lateral resolution
    public const float Slope = 0.16f;     // metres dropped per metre travelled (~9 degrees)

    // Distances along the trail where jumps sit.
    static readonly float[] Jumps = { 110f, 215f, 330f, 450f, 565f, 690f, 810f };

    public static float CenterX(float t)
    {
        return 14f * Mathf.Sin(t * 0.018f) + 7f * Mathf.Sin(t * 0.047f + 1f);
    }

    static float JumpProfile(float t)
    {
        float h = 0f;
        foreach (float tj in Jumps)
        {
            float d = t - tj;
            if (d > -7f && d <= 0f)       { float k = 1f + d / 7f; h += 1.6f * k * k; }          // kicker lip
            else if (d > 0f && d <= 14f)  { h += 1.6f * (1f - d / 14f); }                         // back side
            else if (d > 22f && d < 36f)  { h += 0.9f * Mathf.Sin(Mathf.PI * (d - 22f) / 14f); }   // landing ramp
        }
        return h;
    }

    public static float Height(float t, float u)
    {
        float au = Mathf.Abs(u);
        float h = -Slope * t;

        // Only the trail itself gets rollers and jumps.
        float onTrail = Mathf.Clamp01(1f - (au - 3.5f) / 3f);
        float rollerZone = Mathf.Clamp01(Mathf.Sin(t * 0.02f) * 2f);
        h += onTrail * (0.28f * Mathf.Sin(t * 0.65f) * rollerZone + JumpProfile(t));

        // Banked hillsides on both sides, steeper further out so you can't leave the course.
        if (au > 4f) h += 0.06f * Mathf.Pow(au - 4f, 1.5f) + (au > 16f ? 1.3f * (au - 16f) : 0f);

        // Natural unevenness, much calmer on the trail.
        h += (Mathf.PerlinNoise(t * 0.15f, u * 0.15f + 50f) - 0.5f) * (0.15f + (1f - onTrail) * 1.4f);
        return h;
    }

    public static Vector3 PointOnTrail(float t, float lift = 0f)
    {
        return new Vector3(CenterX(t), Height(t, 0f) + lift, -t);
    }

    public static float TrailYaw(float t)
    {
        float dx = CenterX(t + 3f) - CenterX(t);
        return Mathf.Atan2(dx, -3f) * Mathf.Rad2Deg;
    }

    // ------------------------------------------------------------------------------------------

    public static GameObject Build()
    {
        var root = new GameObject("Course");
        BuildTerrain(root.transform);
        BuildTrees(root.transform);
        BuildOcean(root.transform);
        BuildFinishArch(root.transform);
        return root;
    }

    static void BuildTerrain(Transform parent)
    {
        int rows = (int)Length;
        int cols = (int)(Width / Du);
        var verts = new Vector3[(rows + 1) * (cols + 1)];
        var uvs = new Vector2[verts.Length];
        for (int r = 0; r <= rows; r++)
        {
            float t = r;
            for (int c = 0; c <= cols; c++)
            {
                float u = -Width * 0.5f + c * Du;
                int i = r * (cols + 1) + c;
                verts[i] = new Vector3(CenterX(t) + u, Height(t, u), -t);
                uvs[i] = new Vector2(c / (float)cols, t / 6f);
            }
        }
        var tris = new int[rows * cols * 6];
        int k = 0;
        for (int r = 0; r < rows; r++)
        {
            for (int c = 0; c < cols; c++)
            {
                int a = r * (cols + 1) + c, b = a + 1, cc = a + (cols + 1), d = cc + 1;
                tris[k++] = a; tris[k++] = b; tris[k++] = d;
                tris[k++] = a; tris[k++] = d; tris[k++] = cc;
            }
        }
        var mesh = new Mesh { name = "CourseMesh", indexFormat = UnityEngine.Rendering.IndexFormat.UInt32 };
        mesh.vertices = verts;
        mesh.uv = uvs;
        mesh.triangles = tris;
        mesh.RecalculateNormals();
        mesh.RecalculateBounds();

        var go = new GameObject("Terrain");
        go.transform.SetParent(parent, false);
        go.AddComponent<MeshFilter>().sharedMesh = mesh;
        var mat = Mats.Make(Color.white, 0.02f);
        mat.mainTexture = MakeTexture();
        go.AddComponent<MeshRenderer>().sharedMaterial = mat;
        go.AddComponent<MeshCollider>().sharedMesh = mesh;
    }

    // The terrain UV maps u across the whole strip (Width metres) and v along the trail (6 m per repeat),
    // so the texture is generated in WORLD metres. That keeps the noise isotropic (no stretched streaks)
    // and gives the narrow dirt trail enough pixels to stay sharp.
    const float TileLen = 6f;

    // Noise that tiles seamlessly along the trail direction (cross-fade of two samples).
    static float TileNoise(float u, float tm, float freq)
    {
        float a = Mathf.PerlinNoise(u * freq + 300f, tm * freq);
        float b = Mathf.PerlinNoise(u * freq + 300f, (tm - TileLen) * freq);
        return Mathf.Lerp(a, b, tm / TileLen);
    }

    static Texture2D MakeTexture()
    {
        const int W = 1024, H = 128;
        var tex = new Texture2D(W, H, TextureFormat.RGB24, true)
        {
            wrapMode = TextureWrapMode.Repeat,
            filterMode = FilterMode.Bilinear,
            anisoLevel = 4
        };
        var dirt = new Color(0.74f, 0.53f, 0.30f);
        var dirtDark = new Color(0.55f, 0.38f, 0.22f);
        var grass = new Color(0.34f, 0.58f, 0.18f);
        var grassDark = new Color(0.20f, 0.38f, 0.11f);
        var px = new Color32[W * H];
        for (int y = 0; y < H; y++)
        {
            float tm = (y + 0.5f) / H * TileLen;
            for (int x = 0; x < W; x++)
            {
                float u = -Width * 0.5f + (x + 0.5f) / W * Width;
                float au = Mathf.Abs(u);
                float n = TileNoise(u, tm, 0.9f);     // fine detail
                float p = TileNoise(u, tm, 0.17f);    // broad patches
                float sp = TileNoise(u, tm, 5.0f);    // speckle
                float dirtAmt = Mathf.Clamp01(1f - (au - 3.5f) / 3f);
                float rut = Mathf.Clamp01(1f - Mathf.Abs(au - 0.9f) / 0.5f) * 0.25f;   // darker tyre-worn lines
                Color d = Color.Lerp(dirt, dirtDark, Mathf.Clamp01(rut + n * 0.35f + sp * 0.15f));
                Color g = Color.Lerp(grassDark, grass, Mathf.Clamp01(0.25f + p * 0.5f + sp * 0.35f)) * (0.85f + n * 0.3f);
                px[y * W + x] = Color.Lerp(g, d, dirtAmt);
            }
        }
        tex.SetPixels32(px);
        tex.Apply();
        return tex;
    }

    static void BuildTrees(Transform parent)
    {
        var rng = new System.Random(7);
        var group = new GameObject("Palms").transform;
        group.SetParent(parent, false);
        var trunkCol = new Color(0.45f, 0.33f, 0.20f);
        var leafCol = new Color(0.16f, 0.46f, 0.14f);
        var trunkMat = Mats.Make(trunkCol);
        var leafMat = Mats.Make(leafCol);

        for (int i = 0; i < 170; i++)
        {
            float t = (float)rng.NextDouble() * (Length - 10f) + 5f;
            float side = rng.NextDouble() < 0.5 ? -1f : 1f;
            float u = side * (7f + (float)rng.NextDouble() * 30f);
            Vector3 pos = new Vector3(CenterX(t) + u, Height(t, u), -t);

            var tree = new GameObject("Palm").transform;
            tree.SetParent(group, false);
            tree.position = pos;
            float h = 4f + (float)rng.NextDouble() * 3.5f;
            tree.rotation = Quaternion.Euler((float)(rng.NextDouble() - 0.5) * 14f, (float)rng.NextDouble() * 360f, (float)(rng.NextDouble() - 0.5) * 14f);

            var trunk = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            Object.Destroy(trunk.GetComponent<Collider>());
            trunk.transform.SetParent(tree, false);
            trunk.transform.localPosition = new Vector3(0, h * 0.5f, 0);
            trunk.transform.localScale = new Vector3(0.35f, h * 0.5f, 0.35f);
            trunk.GetComponent<Renderer>().sharedMaterial = trunkMat;

            for (int f = 0; f < 6; f++)
            {
                var frond = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                Object.Destroy(frond.GetComponent<Collider>());
                frond.transform.SetParent(tree, false);
                frond.transform.localPosition = new Vector3(0, h, 0);
                frond.transform.localRotation = Quaternion.Euler(0, f * 60f, 0) * Quaternion.Euler(0, 0, -18f);
                frond.transform.Translate(new Vector3(1.6f, 0, 0), Space.Self);
                frond.transform.localScale = new Vector3(3.6f, 0.12f, 0.9f);
                frond.GetComponent<Renderer>().sharedMaterial = leafMat;
            }
        }
    }

    static void BuildOcean(Transform parent)
    {
        var ocean = GameObject.CreatePrimitive(PrimitiveType.Plane);
        Object.Destroy(ocean.GetComponent<Collider>());
        ocean.name = "Ocean";
        ocean.transform.SetParent(parent, false);
        ocean.transform.position = new Vector3(0f, -Slope * Length - 8f, -Length * 0.5f);
        ocean.transform.localScale = new Vector3(400f, 1f, 400f);
        ocean.GetComponent<Renderer>().sharedMaterial = Mats.Make(new Color(0.15f, 0.55f, 0.65f), 0.6f);
    }

    static void BuildFinishArch(Transform parent)
    {
        float t = Length - 12f;
        Vector3 p = PointOnTrail(t);
        var arch = new GameObject("FinishArch").transform;
        arch.SetParent(parent, false);
        arch.position = p;
        Mats.Prim(PrimitiveType.Cube, arch, new Vector3(-5f, 2.5f, 0), new Vector3(0.4f, 5f, 0.4f), new Color(0.55f, 1f, 0.1f));
        Mats.Prim(PrimitiveType.Cube, arch, new Vector3(5f, 2.5f, 0), new Vector3(0.4f, 5f, 0.4f), new Color(0.55f, 1f, 0.1f));
        Mats.Prim(PrimitiveType.Cube, arch, new Vector3(0, 5f, 0), new Vector3(10.4f, 0.8f, 0.4f), Color.white);
    }
}
