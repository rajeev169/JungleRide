using UnityEngine;

/// <summary>Third-person chase camera behind the rider, like the reference footage. Press C / camera button to cycle views.</summary>
[RequireComponent(typeof(Camera))]
public class FollowCam : MonoBehaviour
{
    public BikeController bike;

    static readonly float[] Dist = { 5.2f, 3.4f, 8.5f };
    static readonly float[] Height = { 2.3f, 1.6f, 3.6f };
    int mode;
    float camYaw;
    Camera cam;

    void Awake() { cam = GetComponent<Camera>(); }

    public void NextMode() { mode = (mode + 1) % Dist.Length; }

    public void Snap()
    {
        camYaw = bike.yaw;
        Vector3 dir = Quaternion.Euler(0, camYaw, 0) * Vector3.forward;
        transform.position = bike.transform.position - dir * Dist[mode] + Vector3.up * Height[mode];
        transform.LookAt(bike.transform.position + Vector3.up);
    }

    void LateUpdate()
    {
        if (bike == null) return;
        if (GameInput.camera) NextMode();
        float dt = Time.deltaTime;

        camYaw = Mathf.LerpAngle(camYaw, bike.yaw, 1f - Mathf.Exp(-4f * dt));
        Vector3 dir = Quaternion.Euler(0, camYaw, 0) * Vector3.forward;
        Vector3 p = bike.transform.position;

        Vector3 want = p - dir * Dist[mode] + Vector3.up * Height[mode];
        // Don't dip under the hillside.
        RaycastHit h;
        if (Physics.Raycast(want + Vector3.up * 40f, Vector3.down, out h, 80f, ~(1 << 2)))
            want.y = Mathf.Max(want.y, h.point.y + 0.8f);

        transform.position = Vector3.Lerp(transform.position, want, 1f - Mathf.Exp(-10f * dt));
        Vector3 look = p + Vector3.up * 1.0f + dir * 3f;
        Quaternion target = Quaternion.LookRotation(look - transform.position, Vector3.up);
        transform.rotation = Quaternion.Slerp(transform.rotation, target, 1f - Mathf.Exp(-12f * dt));

        cam.fieldOfView = Mathf.Lerp(cam.fieldOfView, 60f + bike.SpeedKmh * 0.18f, 1f - Mathf.Exp(-3f * dt));
    }
}
