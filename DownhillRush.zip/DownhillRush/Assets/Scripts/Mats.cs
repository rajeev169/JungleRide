using UnityEngine;

/// <summary>Material / primitive helpers. Works in Built-in, URP and HDRP-less projects.</summary>
public static class Mats
{
    static Shader _lit;

    // Borrow the shader of a default primitive: always valid for the project's render pipeline
    // and never stripped from builds.
    static Shader Lit
    {
        get
        {
            if (_lit == null)
            {
                var p = GameObject.CreatePrimitive(PrimitiveType.Cube);
                _lit = p.GetComponent<Renderer>().sharedMaterial.shader;
                Object.Destroy(p);
            }
            return _lit;
        }
    }

    public static Material Make(Color c, float smoothness = 0.08f)
    {
        var m = new Material(Lit);
        m.color = c;
        if (m.HasProperty("_Glossiness")) m.SetFloat("_Glossiness", smoothness);
        if (m.HasProperty("_Smoothness")) m.SetFloat("_Smoothness", smoothness);
        if (m.HasProperty("_Metallic")) m.SetFloat("_Metallic", 0f);
        return m;
    }

    public static GameObject Prim(PrimitiveType type, Transform parent, Vector3 localPos, Vector3 localScale,
                                  Color color, Vector3? euler = null, bool keepCollider = false)
    {
        var go = GameObject.CreatePrimitive(type);
        if (!keepCollider) Object.Destroy(go.GetComponent<Collider>());
        go.transform.SetParent(parent, false);
        go.transform.localPosition = localPos;
        go.transform.localScale = localScale;
        go.transform.localRotation = Quaternion.Euler(euler ?? Vector3.zero);
        go.GetComponent<Renderer>().sharedMaterial = Make(color);
        return go;
    }
}
