using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEngine;

/// <summary>
/// Shaders that are only looked up from code (Shader.Find) are stripped from player builds unless they are
/// listed under Project Settings > Graphics > Always Included Shaders. This adds them automatically before every build.
/// </summary>
public class IncludeShadersOnBuild : IPreprocessBuildWithReport
{
    public int callbackOrder { get { return 0; } }

    static readonly string[] ShaderNames = { "Legacy Shaders/Diffuse", "Legacy Shaders/VertexLit", "Sprites/Default" };

    public void OnPreprocessBuild(BuildReport report) { Ensure(); }

    public static void Ensure()
    {
        var gfx = AssetDatabase.LoadAssetAtPath<Object>("ProjectSettings/GraphicsSettings.asset");
        if (gfx == null) { Debug.LogWarning("IncludeShadersOnBuild: GraphicsSettings.asset not found."); return; }

        var so = new SerializedObject(gfx);
        var list = so.FindProperty("m_AlwaysIncludedShaders");
        foreach (var name in ShaderNames)
        {
            var shader = Shader.Find(name);
            if (shader == null) { Debug.LogWarning("IncludeShadersOnBuild: shader not found: " + name); continue; }

            bool present = false;
            for (int i = 0; i < list.arraySize; i++)
                if (list.GetArrayElementAtIndex(i).objectReferenceValue == shader) { present = true; break; }
            if (present) continue;

            list.arraySize++;
            list.GetArrayElementAtIndex(list.arraySize - 1).objectReferenceValue = shader;
            Debug.Log("IncludeShadersOnBuild: added " + name);
        }
        so.ApplyModifiedProperties();
        AssetDatabase.SaveAssets();
    }
}
