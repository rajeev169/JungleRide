// Runs automatically when the project is opened in Unity.
// Creates the one scene the game needs, adds it to Build Settings and sets Android options.
// You can run it again any time from the menu: Jungle Rider > Run Project Setup.
using System.IO;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.SceneManagement;
using UnityEngine;

[InitializeOnLoad]
public static class ProjectSetup
{
    const string ScenePath = "Assets/Scenes/Main.unity";
    const string DoneMarker = "ProjectSettings/JungleRiderSetup.done";

    static ProjectSetup()
    {
        EditorApplication.delayCall += () =>
        {
            if (!File.Exists(ScenePath) || !File.Exists(DoneMarker))
                Run();
        };
    }

    [MenuItem("Jungle Rider/Run Project Setup")]
    public static void Run()
    {
        if (EditorApplication.isPlayingOrWillChangePlaymode) return;

        // 1. Scene with a single "Game" object; everything else is built by code at runtime.
        if (!File.Exists(ScenePath))
        {
            Directory.CreateDirectory("Assets/Scenes");
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            new GameObject("Game").AddComponent<GameBootstrap>();
            EditorSceneManager.SaveScene(scene, ScenePath);
            AssetDatabase.Refresh();
        }

        // 2. Build Settings
        EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };

        // 3. Player settings - only the first time, so your own later changes are kept.
        if (!File.Exists(DoneMarker))
        {
            PlayerSettings.companyName = "AppForge";
            PlayerSettings.productName = "Jungle Rider Offroad";
            PlayerSettings.SetApplicationIdentifier(NamedBuildTarget.Android, "com.appforge.junglerider");
            PlayerSettings.defaultInterfaceOrientation = UIOrientation.LandscapeLeft;
            PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64 | AndroidArchitecture.ARMv7;
            PlayerSettings.SetScriptingBackend(NamedBuildTarget.Android, ScriptingImplementation.IL2CPP);
            QualitySettings.shadowDistance = 60f;
            File.WriteAllText(DoneMarker, "Jungle Rider setup done. Delete this file to apply the player settings again.");
        }

        // 4. Open the scene so pressing Play just works.
        var active = EditorSceneManager.GetActiveScene();
        if (active.path != ScenePath && !active.isDirty)
            EditorSceneManager.OpenScene(ScenePath);

        Debug.Log("Jungle Rider: project setup done. Press Play to test, or File > Build Settings > Android > Build.");
    }
}
