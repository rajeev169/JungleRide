// Simple lit shader that uses the mesh's vertex colours (all jungle props are vertex-coloured).
// Built-in render pipeline. Lives in Resources so it is always included in the build.
Shader "JungleRider/VertexLit"
{
    Properties
    {
        _Color ("Tint", Color) = (1,1,1,1)
    }
    SubShader
    {
        Tags { "RenderType"="Opaque" }
        LOD 200
        Cull Back

        CGPROGRAM
        #pragma surface surf Lambert addshadow
        #pragma target 3.0
        #pragma multi_compile_instancing

        fixed4 _Color;

        struct Input
        {
            float4 color : COLOR;
        };

        void surf (Input IN, inout SurfaceOutput o)
        {
            o.Albedo = IN.color.rgb * _Color.rgb;
            o.Alpha = 1;
        }
        ENDCG
    }
    FallBack "Diffuse"
}
