// Shiny lit shader for metal/rubber parts (icons, wheels, crank). Icon cameras switch fog off while they render.
Shader "JungleRider/Metal"
{
    Properties
    {
        _Color ("Colour", Color) = (0.8,0.8,0.8,1)
        _SpecColor ("Specular", Color) = (1,1,1,1)
        _Shininess ("Shininess", Range(0.03, 1)) = 0.5
        _Rim ("Rim light", Range(0, 1)) = 0.3
    }
    SubShader
    {
        Tags { "RenderType"="Opaque" }
        LOD 200
        CGPROGRAM
        #pragma surface surf BlinnPhong
        #pragma target 3.0
        fixed4 _Color;
        half _Shininess;
        half _Rim;
        struct Input { float3 viewDir; };
        void surf (Input IN, inout SurfaceOutput o)
        {
            o.Albedo = _Color.rgb;
            o.Specular = _Shininess;
            o.Gloss = 1;
            half rim = 1.0 - saturate(dot(normalize(IN.viewDir), o.Normal));
            o.Emission = _Color.rgb * pow(rim, 3) * _Rim;
            o.Alpha = 1;
        }
        ENDCG
    }
    FallBack "Diffuse"
}
