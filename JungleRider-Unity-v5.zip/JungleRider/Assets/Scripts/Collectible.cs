using System;
using UnityEngine;

/// <summary>A mango or a gem floating over the trail. Ride through it to collect it.</summary>
public class Collectible : MonoBehaviour
{
    public bool gem;
    public int id;
    public static event Action<Collectible> Picked;

    static Mesh mangoMesh, gemMesh;
    static Material gemMat;
    Vector3 basePos;
    float phase;
    bool taken;

    public static Collectible Spawn(PickupSpot s, Vector3 pos, Transform parent)
    {
        var go = new GameObject(s.gem ? "Gem" : "Mango");
        go.transform.SetParent(parent, false);
        go.transform.position = pos;
        var mf = go.AddComponent<MeshFilter>();
        var mr = go.AddComponent<MeshRenderer>();
        mr.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
        if (s.gem)
        {
            mf.sharedMesh = GemMesh();
            mr.sharedMaterial = GemMaterial();
        }
        else
        {
            mf.sharedMesh = MangoMesh();
            mr.sharedMaterial = JungleProps.Material;
        }
        var col = go.AddComponent<SphereCollider>();
        col.isTrigger = true;
        col.radius = s.gem ? 1.0f : 0.85f;
        var c = go.AddComponent<Collectible>();
        c.gem = s.gem;
        c.id = s.id;
        c.basePos = pos;
        c.phase = s.id * 0.37f;
        return c;
    }

    static Mesh MangoMesh()
    {
        if (mangoMesh != null) return mangoMesh;
        var mb = new MeshBuilder();
        var rnd = new System.Random(11);
        mb.Blob(Vector3.zero, new Vector3(0.24f, 0.3f, 0.22f), new Color(1f, 0.68f, 0.12f), rnd, 5, 9, 0.05f);
        mb.Blob(new Vector3(0.08f, 0.12f, 0.05f), new Vector3(0.1f, 0.12f, 0.1f), new Color(1f, 0.5f, 0.15f), rnd, 3, 6, 0.05f);   // red-orange blush
        mb.Cylinder(new Vector3(0, 0.28f, 0), new Vector3(0.02f, 0.36f, 0), 0.02f, 0.015f, 5, new Color(0.35f, 0.25f, 0.1f));
        mb.Blob(new Vector3(0.09f, 0.36f, 0), new Vector3(0.1f, 0.025f, 0.05f), new Color(0.2f, 0.6f, 0.15f), rnd, 2, 6, 0.05f);    // leaf
        mangoMesh = mb.ToMesh("Mango");
        return mangoMesh;
    }

    static Mesh GemMesh()
    {
        if (gemMesh != null) return gemMesh;
        var mb = new MeshBuilder();
        Color c = new Color(0.35f, 0.85f, 1f);
        Vector3 top = new Vector3(0, 0.38f, 0), bottom = new Vector3(0, -0.3f, 0);
        const int n = 6;
        for (int k = 0; k < n; k++)
        {
            float a0 = k * Mathf.PI * 2f / n, a1 = (k + 1) * Mathf.PI * 2f / n;
            Vector3 p0 = new Vector3(Mathf.Cos(a0), 0, Mathf.Sin(a0)) * 0.28f, p1 = new Vector3(Mathf.Cos(a1), 0, Mathf.Sin(a1)) * 0.28f;
            mb.TriOut(top, p0, p1, MeshBuilder.Shade(c, k % 2 == 0 ? 1f : 0.85f), Vector3.zero);
            mb.TriOut(bottom, p1, p0, MeshBuilder.Shade(c, k % 2 == 0 ? 0.7f : 0.6f), Vector3.zero);
        }
        gemMesh = mb.ToMesh("Gem");
        return gemMesh;
    }

    static Material GemMaterial()
    {
        if (gemMat != null) return gemMat;
        var shader = Shader.Find("JungleRider/Metal");
        if (shader == null) shader = Shader.Find("Standard");
        gemMat = new Material(shader) { name = "Gem" };
        gemMat.SetColor("_Color", new Color(0.35f, 0.85f, 1f));
        gemMat.SetColor("_SpecColor", Color.white);
        gemMat.SetFloat("_Shininess", 0.6f);
        gemMat.SetFloat("_Rim", 0.5f);
        return gemMat;
    }

    void Update()
    {
        float t = Time.time + phase;
        transform.position = basePos + Vector3.up * Mathf.Sin(t * 2.4f) * 0.12f;
        transform.rotation = Quaternion.Euler(0f, t * (gem ? 120f : 70f), gem ? 0f : 12f);
    }

    void OnTriggerEnter(Collider other)
    {
        if (taken) return;
        var rb = other.attachedRigidbody;
        if (rb == null || rb.GetComponent<BikeController>() == null) return;
        taken = true;
        Picked?.Invoke(this);
        Destroy(gameObject);
    }
}
