using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.SceneManagement;

/// <summary>
/// The whole game starts here. The scene only contains one object with this script;
/// camera, light, jungle, bike and UI are all created from code.
/// </summary>
public class GameBootstrap : MonoBehaviour
{
    enum State { Menu, Countdown, Playing, Paused, Result }

    const int EndlessLives = 3;
    const int RaceRiders = 10;
    const int MangoesPerStar = 20;      // level reward
    const int TrickPointsPerMango = 50; // trick score turned into mangoes
    static readonly Color FogColor = new Color(0.6f, 0.72f, 0.56f);

    State state;
    Camera cam;
    CameraFollow camFollow;
    BikeInput input;
    BikeController bike;
    TrackBuilder builder;
    TrailPath path;
    GameUI ui;
    Light sun;
    ControlIcons icons;
    WeatherFX weather;
    TrickSystem tricks;
    RaceAI race;
    Season season = Season.Summer;

    GameMode mode;
    int level = 1;
    bool raceMode;
    TrackConfig cfg;
    readonly List<int> checkpoints = new List<int>();
    int nextCheckpoint;
    int progressIdx;
    int respawnIdx;
    int crashes;
    float raceTime;
    float countdownLeft;
    float distance;
    float crashCooldown;

    // this run
    int runMangoes, runGems, mangoTarget, lastBackflips;
    bool runOpen;            // mangoes/gems not yet added to the wallet
    bool wasInWater;
    float splashTimer;
    readonly string[] missionLines = new string[3];
    readonly bool[] missionDone = new bool[3];

    /// <summary>
    /// Starts the game even if the build used a different scene (for example a scene made by a
    /// build workflow): the scene's own objects are switched off and the game builds itself.
    /// </summary>
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    static void AutoStart()
    {
#if UNITY_2023_1_OR_NEWER
        if (FindAnyObjectByType<GameBootstrap>() != null) return;
#else
        if (FindObjectOfType<GameBootstrap>() != null) return;
#endif
        foreach (var go in SceneManager.GetActiveScene().GetRootGameObjects())
            go.SetActive(false);
        new GameObject("Game").AddComponent<GameBootstrap>();
    }

    void Awake()
    {
        Application.targetFrameRate = 60;
        Screen.sleepTimeout = SleepTimeout.NeverSleep;
        Screen.orientation = ScreenOrientation.LandscapeLeft;
        Time.timeScale = 1f;

        Economy.CheckLogin();
        SetupWorld();

        GameAudio.Create();
        input = new GameObject("BikeInput").AddComponent<BikeInput>();
        icons = ControlIcons.Create(input);
        ui = GameUI.Create(input, icons);
        bike = BikeController.Create(input);
        builder = new GameObject("Jungle").AddComponent<TrackBuilder>();
        camFollow.target = bike.transform;
        icons.SetBike(bike);
        GameAudio.I.Attach(bike, input);
        weather = WeatherFX.Create(cam, sun);
        weather.SetBike(bike);
        tricks = TrickSystem.Create(bike);
        tricks.Trick += OnTrick;
        tricks.BadLanding += () => ui.Toast("BAD LANDING!", 1.2f);
        race = RaceAI.Create();
        Collectible.Picked += OnPicked;
        bike.ApplyUpgrades();

        ui.OnTrailRace = (s, r) => StartRun(GameMode.TrailRace, 1, s, r);
        ui.OnEndless = s => StartRun(GameMode.Endless, 1, s, false);
        ui.OnLevel = (l, r) => StartRun(GameMode.Levels, l, LevelDefs.Get(l).season, r);
        ui.OnPause = Pause;
        ui.OnResume = Resume;
        ui.OnRestart = () => StartRun(mode, level, season, raceMode);
        ui.OnMainMenu = GoToMenu;
        ui.OnNextLevel = () =>
        {
            int next = level + 1;
            if (next <= LevelDefs.Count && Economy.LevelUnlocked(next)) StartRun(GameMode.Levels, next, LevelDefs.Get(next).season, raceMode);
            else { GoToMenu(); ui.ShowMap(); }
        };
        ui.OnControlsChanged = () => { if (GameSettings.Control == ControlMode.Tilt) input.CalibrateTilt(); };
        ui.OnLooksChanged = () => bike.ApplyUpgrades();

        GoToMenu();
    }

    void OnDestroy()
    {
        Collectible.Picked -= OnPicked;
    }

    void SetupWorld()
    {
        RenderSettings.fog = true;
        RenderSettings.fogMode = FogMode.Exponential;
        RenderSettings.fogDensity = 0.012f;
        RenderSettings.fogColor = FogColor;
        RenderSettings.ambientMode = AmbientMode.Trilight;
        RenderSettings.ambientSkyColor = new Color(0.62f, 0.72f, 0.62f);
        RenderSettings.ambientEquatorColor = new Color(0.42f, 0.5f, 0.36f);
        RenderSettings.ambientGroundColor = new Color(0.2f, 0.22f, 0.15f);
        RenderSettings.skybox = null;
        QualitySettings.shadowDistance = 60f;

        var camGo = new GameObject("Main Camera");
        camGo.tag = "MainCamera";
        cam = camGo.AddComponent<Camera>();
        cam.clearFlags = CameraClearFlags.SolidColor;
        cam.backgroundColor = FogColor;
        cam.fieldOfView = 62f;
        cam.nearClipPlane = 0.2f;
        cam.farClipPlane = 260f;
        camGo.AddComponent<AudioListener>();
        camFollow = camGo.AddComponent<CameraFollow>();
        cam.cullingMask = ControlIcons.HideFromMainCamera(cam.cullingMask);

        sun = new GameObject("Sun").AddComponent<Light>();
        sun.type = LightType.Directional;
        sun.transform.rotation = Quaternion.Euler(48f, -35f, 0f);
        sun.color = new Color(1f, 0.95f, 0.85f);
        sun.intensity = 1.15f;
        sun.shadows = LightShadows.Soft;
        sun.shadowStrength = 0.7f;
        RenderSettings.sun = sun;
    }

    // ------------------------------------------------------------------ flow
    void ApplySeason(Season s)
    {
        season = s;
        var look = Seasons.Apply(s, cam, sun);
        bike.SetSurface(look);
        GameAudio.I.SetSeason(look);
        weather.SetSeason(s);
    }

    void GoToMenu()
    {
        CommitRun();
        Time.timeScale = 1f;
        state = State.Menu;
        GameAudio.I.SetRiding(false);
        GameAudio.I.SetPaused(false);
        tricks.Active = false;
        ApplySeason(Seasons.Today());
        // show the first trail behind the menu, with the camera circling the bike
        raceMode = false;
        Prepare(TrackConfig.TrailRace());
        bike.SetFrozen(true);
        input.InputActive = false;
        camFollow.orbit = true;
        camFollow.orbitDistance = 4.2f;
        camFollow.orbitHeight = 1.6f;
        ui.ShowMenu();
    }

    void StartRun(GameMode newMode, int newLevel, Season newSeason, bool withRace)
    {
        CommitRun();
        Time.timeScale = 1f;
        GameAudio.I.SetRiding(false);
        GameAudio.I.SetPaused(false);
        ApplySeason(newSeason);
        mode = newMode;
        level = newLevel;
        raceMode = withRace && newMode != GameMode.Endless;
        switch (mode)
        {
            case GameMode.Endless: cfg = TrackConfig.Endless(); break;
            case GameMode.Levels: cfg = TrackConfig.Level(level); break;
            default: cfg = TrackConfig.TrailRace(); break;
        }
        bike.ApplyUpgrades();
        Prepare(cfg);
        crashes = 0;
        raceTime = 0f;
        distance = 0f;
        countdownLeft = 3f;
        runMangoes = runGems = 0;
        lastBackflips = 0;
        runOpen = true;
        wasInWater = false;
        tricks.ResetRun();
        tricks.Active = false;
        mangoTarget = 0;
        if (mode == GameMode.Levels)
        {
            int total = path.CountMangoes();
            mangoTarget = Mathf.Max(5, Mathf.FloorToInt(total * 0.8f / 5f) * 5);
        }
        state = State.Countdown;
        bike.SetFrozen(true);
        input.InputActive = false;
        camFollow.orbit = false;
        camFollow.SnapBehind();
        ui.ShowHud();
        ui.SetRunWallet(0, 0);
        ui.SetRacePosition(raceMode ? RaceAI.Ordinal(1) + " / " + (RaceRiders + 1) : null);
        UpdateMissions();
        ui.SetHud(InfoText(), 0f);
    }

    void Prepare(TrackConfig config)
    {
        cfg = config;
        path = new TrailPath(cfg);
        BuildCheckpoints();
        nextCheckpoint = 0;
        builder.Init(path, checkpoints);
        respawnIdx = TrailPath.StartIndex;
        progressIdx = TrailPath.StartIndex;
        PlaceBike(TrailPath.StartIndex);
        ui.Minimap.Setup(path, bike, checkpoints, raceMode ? race : null);
        ui.Minimap.ProgressIndex = progressIdx;
        if (raceMode) race.Setup(path, RaceRiders, (level - 1) / (float)(LevelDefs.Count - 1), cfg.seed + level * 13);
        else race.Clear();
    }

    /// <summary>Evenly spaced checkpoints, moved out of adventures, plus one before every gorge and one per mountain round.</summary>
    void BuildCheckpoints()
    {
        checkpoints.Clear();
        if (cfg.endless) return;
        int finish = path.FinishIndex;
        var list = new List<int>();
        int every = Mathf.Max(10, Mathf.RoundToInt(cfg.checkpointEvery / TrailPath.SegLen));
        int spiralStart = path.HasSpiral ? path.SpiralZone.start : int.MaxValue;
        for (int i = TrailPath.StartIndex + every; i < finish - 10; i += every)
        {
            if (i >= spiralStart) break;
            var z = path.ZoneAt(i);
            list.Add(z != null ? z.start - 2 : i);
        }
        foreach (var z in path.Zones)
        {
            if (z.IsGorge) list.Add(z.start - (z.type == FeatureType.Waterfall ? 8 : 3));   // room to speed up for the jump
            if (z.type == FeatureType.Spiral) list.Add(z.start);
        }
        foreach (int r in path.SpiralRoundStarts) list.Add(r);
        list.Sort();
        foreach (int c in list)
        {
            if (c <= TrailPath.StartIndex + 6 || c >= finish - 6) continue;
            if (checkpoints.Count > 0 && c - checkpoints[checkpoints.Count - 1] < 10) continue;
            checkpoints.Add(c);
        }
    }

    void PlaceBike(int idx)
    {
        builder.UpdateAround(idx);
        Vector3 p = path.Point(idx) + Vector3.up * (BikeController.AxleHeight + 0.25f);
        bike.Respawn(p, Quaternion.LookRotation(path.Forward(idx), Vector3.up));
        progressIdx = idx;
        crashCooldown = 1.5f;
        if (tricks) tricks.ResetJump();
    }

    void Pause()
    {
        if (state != State.Playing && state != State.Countdown) return;
        state = State.Paused;
        Time.timeScale = 0f;
        GameAudio.I.SetPaused(true);
        ui.ShowPause();
    }

    void Resume()
    {
        if (state != State.Paused) return;
        ui.HidePause();
        Time.timeScale = 1f;
        GameAudio.I.SetPaused(false);
        state = countdownLeft > 0f ? State.Countdown : State.Playing;
        if (GameSettings.Control == ControlMode.Tilt) input.CalibrateTilt();
    }

    // ------------------------------------------------------------------ loop
    void Update()
    {
        switch (state)
        {
            case State.Countdown: UpdateCountdown(); break;
            case State.Playing: UpdatePlaying(); break;
        }
    }

    void UpdateCountdown()
    {
        countdownLeft -= Time.deltaTime;
        if (raceMode) race.Tick(Time.deltaTime, 0f, bike.transform.position);
        if (countdownLeft > 0f)
        {
            ui.SetCountdown(Mathf.CeilToInt(countdownLeft).ToString());
            return;
        }
        ui.SetCountdown("");
        ui.Toast("GO!", 1f);
        state = State.Playing;
        GameAudio.I.SetRiding(true);
        bike.SetFrozen(false);
        input.InputActive = true;
        input.CalibrateTilt();
        tricks.Active = true;
        race.Running = raceMode;
    }

    void UpdatePlaying()
    {
        float dt = Time.deltaTime;
        raceTime += dt;
        crashCooldown -= dt;

        Vector3 pos = bike.transform.position;
        progressIdx = path.ClosestIndex(pos, progressIdx);
        builder.UpdateAround(progressIdx);
        distance = Mathf.Max(distance, (progressIdx - TrailPath.StartIndex) * TrailPath.SegLen);
        ui.Minimap.ProgressIndex = progressIdx;

        UpdateWater(pos);

        // checkpoints
        if (nextCheckpoint < checkpoints.Count && progressIdx >= checkpoints[nextCheckpoint])
        {
            respawnIdx = checkpoints[nextCheckpoint];
            nextCheckpoint++;
            bool round = path.HasSpiral && progressIdx >= path.SpiralZone.start;
            ui.Toast(round ? "MOUNTAIN ROUND " + RoundNumber() + " / 3" : "CHECKPOINT " + nextCheckpoint + "/" + checkpoints.Count);
        }

        // race
        if (raceMode)
        {
            race.Tick(dt, raceTime, pos);
            float metres = (path.Progress(pos, progressIdx) - TrailPath.StartIndex) * TrailPath.SegLen;
            ui.SetRacePosition(RaceAI.Ordinal(race.Position(metres)) + " / " + (race.Count + 1));
        }

        // finish
        if (!cfg.endless && progressIdx >= path.FinishIndex)
        {
            Finish();
            return;
        }

        // crash / fell off / left the trail
        float lateral = path.LateralOffset(pos, progressIdx);
        bool fell = pos.y < path.Point(progressIdx).y - 12f;
        bool lost = Mathf.Abs(lateral) > 28f;
        if (crashCooldown <= 0f && (bike.Crashed || fell || lost))
        {
            OnCrash();
            return;
        }

        UpdateMissions();
        ui.SetHud(InfoText(), bike.SpeedKmh);
    }

    int RoundNumber()
    {
        int n = 1;
        foreach (int r in path.SpiralRoundStarts) if (progressIdx >= r) n++;
        return n;
    }

    /// <summary>River crossing: slows the bike, splashes and soft water sounds.</summary>
    void UpdateWater(Vector3 pos)
    {
        bool inWater = false;
        var z = path.ZoneAt(progressIdx);
        if (z != null && z.type == FeatureType.River)
        {
            float p = path.Progress(pos, progressIdx);
            inWater = p >= z.gapStart - 0.7f && p <= z.gapEnd + 0.7f && pos.y < z.baseY + 0.45f;
        }
        bike.inWater = inWater;
        if (inWater && !wasInWater)
        {
            weather.Splash();
            GameAudio.I.PlayAt("splash_" + Random.Range(0, 2), pos, 0.75f);
            splashTimer = 0.5f;
        }
        if (inWater)
        {
            splashTimer -= Time.deltaTime;
            float speed = Mathf.Abs(bike.ForwardSpeed);
            if (splashTimer <= 0f && speed > 0.8f)
            {
                GameAudio.I.PlayAt("splash_" + Random.Range(0, 2), pos, 0.25f + 0.3f * Mathf.Clamp01(speed / 8f));
                splashTimer = Mathf.Lerp(0.8f, 0.35f, Mathf.Clamp01(speed / 8f));
            }
        }
        wasInWater = inWater;
    }

    void UpdateMissions()
    {
        if (mode != GameMode.Levels)
        {
            ui.SetMissions(null, null);
            return;
        }
        var def = LevelDefs.Get(level);
        missionLines[0] = "Finish under " + GameSettings.FormatTime(def.parTime).Replace(".0", "");
        missionDone[0] = raceTime <= def.parTime;
        missionLines[1] = "Collect " + mangoTarget + " fruits (" + runMangoes + "/" + mangoTarget + ")";
        missionDone[1] = runMangoes >= mangoTarget;
        missionLines[2] = "No crash";
        missionDone[2] = crashes == 0;
        ui.SetMissions(missionLines, missionDone);
    }

    string InfoText()
    {
        switch (mode)
        {
            case GameMode.Endless:
                return Mathf.FloorToInt(distance) + " m\nLives: " + Mathf.Max(0, EndlessLives - crashes);
            case GameMode.Levels:
                return "Level " + level + "   " + GameSettings.FormatTime(raceTime) + "\n" + Mathf.FloorToInt(distance) + " / " + Mathf.RoundToInt(cfg.length) + " m";
            default:
                return "Time " + GameSettings.FormatTime(raceTime) + "\n" + Mathf.FloorToInt(distance) + " / " + Mathf.RoundToInt(cfg.length) + " m";
        }
    }

    // ------------------------------------------------------------------ pickups & tricks
    void OnPicked(Collectible c)
    {
        if (state != State.Playing && state != State.Countdown) return;
        builder.picked.Add(c.id);
        if (c.gem)
        {
            runGems++;
            GameAudio.I.Play("pickup_gem", 0.55f);
            ui.Toast("GEM!", 1f);
        }
        else
        {
            runMangoes++;
            GameAudio.I.Play("pickup_mango", 0.32f);
        }
        ui.SetRunWallet(runMangoes, runGems);
    }

    void OnTrick(string name, int points, int combo)
    {
        ui.ShowTrick(name, points, combo);
        GameAudio.I.Play("trick_ok", 0.5f);
        int flips = tricks.Backflips - lastBackflips;
        lastBackflips = tricks.Backflips;
        if (flips > 0) Economy.ReportChallenge(Economy.ChallengeType.Backflips, flips);
    }

    /// <summary>Adds this run's mangoes, gems and ridden distance to the wallet / daily challenge (once).</summary>
    void CommitRun(int bonusMangoes = 0)
    {
        if (!runOpen) return;
        runOpen = false;
        int trickMangoes = tricks ? tricks.Score / TrickPointsPerMango : 0;
        Economy.Mangoes += runMangoes + trickMangoes + bonusMangoes;
        Economy.Gems += runGems;
        Economy.ReportChallenge(Economy.ChallengeType.Mangoes, runMangoes);
        Economy.ReportChallenge(Economy.ChallengeType.Distance, Mathf.FloorToInt(distance));
    }

    // ------------------------------------------------------------------ crash & finish
    void OnCrash()
    {
        crashes++;
        tricks.ResetJump();
        if (mode == GameMode.Endless)
        {
            if (crashes >= EndlessLives)
            {
                EndEndless();
                return;
            }
            ui.Toast("CRASH!  " + (EndlessLives - crashes) + " left");
            PlaceBike(path.SafeIndex(Mathf.Max(TrailPath.StartIndex, progressIdx - 1)));
        }
        else
        {
            ui.Toast("CRASH! Back to checkpoint");
            PlaceBike(respawnIdx);
        }
    }

    void StopRiding()
    {
        state = State.Result;
        GameAudio.I.SetRiding(false);
        bike.SetFrozen(true);
        bike.inWater = false;
        input.InputActive = false;
        tricks.Active = false;
        race.Running = false;
    }

    void Finish()
    {
        StopRiding();
        UpdateMissions();
        var info = new ResultInfo { mangoes = runMangoes, gems = runGems, trickScore = tricks.Score };
        int place = 0;
        List<KeyValuePair<string, float>> order = null;
        if (raceMode)
        {
            order = race.Results(raceTime);
            place = order.FindIndex(kv => kv.Key == "YOU") + 1;
            if (place == 1) Economy.ReportChallenge(Economy.ChallengeType.WinRace, 1);
        }

        if (mode == GameMode.Levels)
        {
            var def = LevelDefs.Get(level);
            int stars = 0;
            foreach (bool d in missionDone) if (d) stars++;
            Economy.RecordStars(level, stars);
            Economy.MarkCompleted(level);
            Economy.ReportChallenge(Economy.ChallengeType.Levels, 1);
            float best = GameSettings.BestLevelTime(level);
            if (best <= 0f || raceTime < best) GameSettings.SetBestLevelTime(level, raceTime);
            int bonus = stars * MangoesPerStar;
            CommitRun(bonus);
            info.mangoes += bonus + tricks.Score / TrickPointsPerMango;

            info.title = "LEVEL " + level + " COMPLETE!";
            info.stars = stars;
            info.missions = new[] { missionLines[0], "No crash", "Collect " + mangoTarget + " fruits" };
            info.missionDone = new[] { missionDone[0], missionDone[2], missionDone[1] };
            info.missionValues = new[]
            {
                GameSettings.FormatTime(raceTime),
                crashes == 0 ? "OK" : crashes + (crashes == 1 ? " crash" : " crashes"),
                runMangoes + "/" + mangoTarget,
            };
            info.body = raceMode ? "Race: " + RaceAI.Ordinal(place) + " of " + (race.Count + 1) : "";
            bool nextOpen = level < LevelDefs.Count && Economy.LevelUnlocked(level + 1);
            info.showNext = nextOpen;
            if (level < LevelDefs.Count && !nextOpen && Economy.Completed(level))
                info.body += (info.body.Length > 0 ? "\n" : "") + "Collect " + LevelDefs.AreaStarsNeeded(LevelDefs.Get(level + 1).area) + " stars to open the next area";
            if (level == LevelDefs.Count) info.body += (info.body.Length > 0 ? "\n" : "") + "All levels complete!";
        }
        else
        {
            CommitRun();
            info.mangoes += tricks.Score / TrickPointsPerMango;
            float best = GameSettings.BestTrailTime;
            bool record = best <= 0f || raceTime < best;
            if (record) GameSettings.BestTrailTime = raceTime;
            if (raceMode)
            {
                info.title = place == 1 ? "1st PLACE!" : RaceAI.Ordinal(place) + " PLACE";
                string podium = "";
                for (int k = 0; k < Mathf.Min(3, order.Count); k++)
                    podium += RaceAI.Ordinal(k + 1) + "   " + order[k].Key + "   " + GameSettings.FormatTime(order[k].Value) + "\n";
                info.body = podium + (place > 3 ? "...\n" + RaceAI.Ordinal(place) + "   YOU   " + GameSettings.FormatTime(raceTime) : "");
            }
            else
            {
                info.title = "FINISH!";
                info.body = "Time: " + GameSettings.FormatTime(raceTime) + (record ? "   NEW BEST!" : "   Best: " + GameSettings.FormatTime(best))
                          + "\nCrashes: " + crashes;
            }
        }

        // summit view after the mountain climb
        if (path.HasSpiral)
        {
            camFollow.orbitDistance = 16f;
            camFollow.orbitHeight = 7f;
            camFollow.orbit = true;
        }
        ui.ShowResult(info);
    }

    void EndEndless()
    {
        StopRiding();
        CommitRun();
        float best = GameSettings.BestEndless;
        bool record = distance > best;
        if (record) GameSettings.BestEndless = distance;
        var info = new ResultInfo
        {
            title = "RIDE OVER",
            body = "Distance: " + Mathf.FloorToInt(distance) + " m" + (record ? "   NEW BEST!" : "   Best: " + Mathf.FloorToInt(best) + " m")
                 + "\nTime: " + GameSettings.FormatTime(raceTime),
            mangoes = runMangoes + tricks.Score / TrickPointsPerMango,
            gems = runGems,
            trickScore = tricks.Score,
        };
        ui.ShowResult(info);
    }

    void OnApplicationPause(bool paused)
    {
        if (paused && state == State.Playing) Pause();
        if (paused) PlayerPrefs.Save();
    }
}
