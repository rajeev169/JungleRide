using System;
using UnityEngine;

public enum Upgrade { Grip = 0, Brakes = 1, Speed = 2, Suspension = 3 }

/// <summary>Bikes the player can own. Each has its own rim colour and small bonuses.</summary>
public class BikeDef
{
    public string name;
    public Color rim;
    public int priceMangoes, priceGems;
    public float speedBonus, gripBonus, brakeBonus;
}

/// <summary>Rider looks: a colour tint over the rider's suit.</summary>
public class LookDef
{
    public string name;
    public Color tint;
    public int priceMangoes, priceGems;
}

/// <summary>Mangoes, gems, upgrades, bikes, looks, stars, daily challenge and login rewards — all saved on the phone.</summary>
public static class Economy
{
    public const int MaxUpgrade = 5;
    public static event Action Changed;

    public static readonly BikeDef[] Bikes =
    {
        new BikeDef { name = "Jungle Green", rim = new Color(0.25f, 0.68f, 0.23f) },
        new BikeDef { name = "Red Rocket", rim = new Color(0.85f, 0.16f, 0.12f), priceMangoes = 1500, speedBonus = 1.2f },
        new BikeDef { name = "Blue Storm", rim = new Color(0.15f, 0.45f, 0.9f), priceGems = 30, gripBonus = 0.12f, brakeBonus = 0.12f },
    };

    public static readonly LookDef[] Looks =
    {
        new LookDef { name = "Original", tint = Color.white },
        new LookDef { name = "Forest", tint = new Color(0.78f, 1f, 0.78f), priceMangoes = 300 },
        new LookDef { name = "Sunset", tint = new Color(1.12f, 0.86f, 0.7f), priceMangoes = 400 },
        new LookDef { name = "Ice", tint = new Color(0.8f, 0.92f, 1.15f), priceGems = 10 },
    };

    static readonly string[] UpgradeNames = { "GRIP TYRES", "BRAKES", "TOP SPEED", "JUMP SUSPENSION" };
    static readonly string[] UpgradeInfo = { "Hold the trail in mud", "Stop faster", "Go faster downhill", "Softer landings, bigger air" };
    // price of the next level = base + 50 x current level (as in the shop mock-up)
    static readonly int[] UpgradeBase = { 200, 200, 300, 200 };

    public static string UpgradeName(Upgrade u) => UpgradeNames[(int)u];
    public static string UpgradeText(Upgrade u) => UpgradeInfo[(int)u];

    static int Get(string k, int d = 0) => PlayerPrefs.GetInt(k, d);
    static void Set(string k, int v) { PlayerPrefs.SetInt(k, v); PlayerPrefs.Save(); Changed?.Invoke(); }

    // ---------------- wallet ----------------
    public static int Mangoes { get => Get("mangoes"); set => Set("mangoes", Mathf.Max(0, value)); }
    public static int Gems { get => Get("gems"); set => Set("gems", Mathf.Max(0, value)); }

    public static bool Spend(int mangoes, int gems)
    {
        if (Mangoes < mangoes || Gems < gems) return false;
        PlayerPrefs.SetInt("mangoes", Mangoes - mangoes);
        PlayerPrefs.SetInt("gems", Gems - gems);
        PlayerPrefs.Save();
        Changed?.Invoke();
        return true;
    }

    // ---------------- upgrades ----------------
    public static int Level(Upgrade u) => Mathf.Clamp(Get("up_" + (int)u), 0, MaxUpgrade);
    public static int UpgradePrice(Upgrade u) => UpgradeBase[(int)u] + 50 * Level(u);

    public static bool BuyUpgrade(Upgrade u)
    {
        if (Level(u) >= MaxUpgrade) return false;
        if (!Spend(UpgradePrice(u), 0)) return false;
        Set("up_" + (int)u, Level(u) + 1);
        return true;
    }

    // ---------------- bikes & looks ----------------
    public static bool OwnsBike(int i) => i == 0 || Get("bike_own_" + i) == 1;
    public static int SelectedBike { get => Mathf.Clamp(Get("bike_sel"), 0, Bikes.Length - 1); set => Set("bike_sel", value); }
    public static BikeDef CurrentBike => Bikes[OwnsBike(SelectedBike) ? SelectedBike : 0];

    public static bool BuyOrSelectBike(int i)
    {
        if (!OwnsBike(i))
        {
            if (!Spend(Bikes[i].priceMangoes, Bikes[i].priceGems)) return false;
            Set("bike_own_" + i, 1);
        }
        SelectedBike = i;
        return true;
    }

    public static bool OwnsLook(int i) => i == 0 || Get("look_own_" + i) == 1;
    public static int SelectedLook { get => Mathf.Clamp(Get("look_sel"), 0, Looks.Length - 1); set => Set("look_sel", value); }
    public static LookDef CurrentLook => Looks[OwnsLook(SelectedLook) ? SelectedLook : 0];

    public static bool BuyOrSelectLook(int i)
    {
        if (!OwnsLook(i))
        {
            if (!Spend(Looks[i].priceMangoes, Looks[i].priceGems)) return false;
            Set("look_own_" + i, 1);
        }
        SelectedLook = i;
        return true;
    }

    // ---------------- stars ----------------
    public static int Stars(int level) => Mathf.Clamp(Get("stars_" + level), 0, 3);

    public static void RecordStars(int level, int stars)
    {
        if (stars > Stars(level)) Set("stars_" + level, stars);
    }

    public static bool Completed(int level) => Get("done_" + level) == 1;
    public static void MarkCompleted(int level) => Set("done_" + level, 1);

    public static int TotalStars()
    {
        int t = 0;
        for (int i = 1; i <= LevelDefs.Count; i++) t += Stars(i);
        return t;
    }

    public static bool LevelUnlocked(int level)
    {
        if (level <= 1) return true;
        if (!Completed(level - 1)) return false;
        var area = LevelDefs.Get(level).area;
        return TotalStars() >= LevelDefs.AreaStarsNeeded(area);
    }

    // ---------------- daily challenge ----------------
    public enum ChallengeType { Mangoes, Backflips, Levels, Distance, WinRace }

    public static string Today => DateTime.Now.ToString("yyyyMMdd");

    public static ChallengeType TodayChallenge
    {
        get
        {
            int seed = DateTime.Now.Year * 400 + DateTime.Now.DayOfYear;
            return (ChallengeType)(seed % 5);
        }
    }

    public static int ChallengeGoal(ChallengeType t)
    {
        switch (t)
        {
            case ChallengeType.Mangoes: return 60;
            case ChallengeType.Backflips: return 3;
            case ChallengeType.Levels: return 2;
            case ChallengeType.Distance: return 1500;
            default: return 1;
        }
    }

    public static string ChallengeText(ChallengeType t)
    {
        switch (t)
        {
            case ChallengeType.Mangoes: return "Collect 60 mangoes";
            case ChallengeType.Backflips: return "Do 3 backflips";
            case ChallengeType.Levels: return "Finish 2 levels";
            case ChallengeType.Distance: return "Ride 1500 m in total";
            default: return "Win a race (finish 1st)";
        }
    }

    public const int ChallengeRewardGems = 5;

    public static int ChallengeProgress => Get("ch_day") == int.Parse(Today) ? Get("ch_prog") : 0;
    public static bool ChallengeClaimed => Get("ch_claim_day") == int.Parse(Today);
    public static bool ChallengeDone => ChallengeProgress >= ChallengeGoal(TodayChallenge);

    /// <summary>Adds progress if the event matches today's challenge.</summary>
    public static void ReportChallenge(ChallengeType t, int amount)
    {
        if (t != TodayChallenge || amount <= 0) return;
        int today = int.Parse(Today);
        int prog = Get("ch_day") == today ? Get("ch_prog") : 0;
        PlayerPrefs.SetInt("ch_day", today);
        Set("ch_prog", Mathf.Min(ChallengeGoal(t), prog + amount));
    }

    public static bool ClaimChallenge()
    {
        if (!ChallengeDone || ChallengeClaimed) return false;
        PlayerPrefs.SetInt("ch_claim_day", int.Parse(Today));
        Gems += ChallengeRewardGems;
        return true;
    }

    // ---------------- 7-day login rewards ----------------
    /// <summary>Call once at start: updates the login streak (1..7).</summary>
    public static void CheckLogin()
    {
        int today = int.Parse(Today);
        int last = Get("login_last");
        if (last == today) return;
        int yesterday = int.Parse(DateTime.Now.AddDays(-1).ToString("yyyyMMdd"));
        int streak = last == yesterday ? Get("login_streak") % 7 + 1 : 1;
        PlayerPrefs.SetInt("login_last", today);
        Set("login_streak", streak);
    }

    public static int LoginDay => Mathf.Clamp(Get("login_streak", 1), 1, 7);
    public static bool LoginClaimed => Get("login_claim_day") == int.Parse(Today);
    public static int LoginRewardMangoes(int day) => day >= 7 ? 0 : 50 * day;
    public static int LoginRewardGems(int day) => day >= 7 ? 10 : 0;

    public static bool ClaimLogin()
    {
        if (LoginClaimed) return false;
        int d = LoginDay;
        PlayerPrefs.SetInt("login_claim_day", int.Parse(Today));
        PlayerPrefs.SetInt("mangoes", Mangoes + LoginRewardMangoes(d));
        PlayerPrefs.SetInt("gems", Gems + LoginRewardGems(d));
        PlayerPrefs.Save();
        Changed?.Invoke();
        return true;
    }
}
