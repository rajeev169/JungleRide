using System;
using UnityEngine;
using UnityEngine.UI;

/// <summary>Small helpers to build the UI from code (no prefabs or image files needed).</summary>
public static class UIFactory
{
    static Font font;
    static Sprite rounded, circle;

    public static readonly Color Green = new Color(0.22f, 0.62f, 0.25f, 0.95f);
    public static readonly Color Dark = new Color(0.05f, 0.1f, 0.06f, 0.82f);
    public static readonly Color Orange = new Color(0.95f, 0.55f, 0.12f, 0.95f);
    public static readonly Color Grey = new Color(0.35f, 0.38f, 0.35f, 0.9f);
    public static readonly Color Red = new Color(0.8f, 0.2f, 0.18f, 0.95f);

    public static Font Font
    {
        get
        {
            if (font == null)
            {
                try { font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf"); } catch { }
                if (font == null) { try { font = Resources.GetBuiltinResource<Font>("Arial.ttf"); } catch { } }
            }
            return font;
        }
    }

    /// <summary>White rounded-rectangle sprite (9-sliced), made in code.</summary>
    public static Sprite Rounded
    {
        get
        {
            if (rounded == null) rounded = MakeSprite(64, 18f, new Vector4(22, 22, 22, 22));
            return rounded;
        }
    }

    public static Sprite Circle
    {
        get
        {
            if (circle == null) circle = MakeSprite(128, 64f, Vector4.zero);
            return circle;
        }
    }

    static Sprite MakeSprite(int size, float radius, Vector4 border)
    {
        var tex = new Texture2D(size, size, TextureFormat.RGBA32, false) { wrapMode = TextureWrapMode.Clamp, filterMode = FilterMode.Bilinear };
        var px = new Color32[size * size];
        for (int y = 0; y < size; y++)
            for (int x = 0; x < size; x++)
            {
                float cx = Mathf.Clamp(x + 0.5f, radius, size - radius);
                float cy = Mathf.Clamp(y + 0.5f, radius, size - radius);
                float d = Vector2.Distance(new Vector2(x + 0.5f, y + 0.5f), new Vector2(cx, cy));
                byte a = (byte)(Mathf.Clamp01(radius - d + 0.5f) * 255f);
                px[y * size + x] = new Color32(255, 255, 255, a);
            }
        tex.SetPixels32(px);
        tex.Apply();
        return Sprite.Create(tex, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), 100f, 0, SpriteMeshType.FullRect, border);
    }

    // ---------------- small icons drawn in code ----------------
    static Sprite star, mango, gem, tick, lockIcon;

    delegate Color PixelFn(float x, float y);   // x, y in -1..1

    static Sprite Draw(int size, PixelFn fn)
    {
        var tex = new Texture2D(size, size, TextureFormat.RGBA32, false) { wrapMode = TextureWrapMode.Clamp, filterMode = FilterMode.Bilinear };
        var px = new Color[size * size];
        const int ss = 3;   // supersampling for smooth edges
        for (int y = 0; y < size; y++)
            for (int x = 0; x < size; x++)
            {
                Color acc = Color.clear;
                for (int sy = 0; sy < ss; sy++)
                    for (int sx = 0; sx < ss; sx++)
                    {
                        float fx = (x + (sx + 0.5f) / ss) / size * 2f - 1f, fy = (y + (sy + 0.5f) / ss) / size * 2f - 1f;
                        Color c = fn(fx, fy);
                        acc += new Color(c.r * c.a, c.g * c.a, c.b * c.a, c.a);
                    }
                acc /= ss * ss;
                px[y * size + x] = acc.a > 0f ? new Color(acc.r / acc.a, acc.g / acc.a, acc.b / acc.a, acc.a) : Color.clear;
            }
        tex.SetPixels(px);
        tex.Apply();
        return Sprite.Create(tex, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), 100f);
    }

    static float SegDist(Vector2 p, Vector2 a, Vector2 b)
    {
        Vector2 ab = b - a;
        float t = Mathf.Clamp01(Vector2.Dot(p - a, ab) / ab.sqrMagnitude);
        return Vector2.Distance(p, a + ab * t);
    }

    static bool InStar(float x, float y, float outer, float inner)
    {
        float ang = Mathf.Atan2(x, y);              // 0 = straight up
        float r = Mathf.Sqrt(x * x + y * y);
        float seg = Mathf.PI * 2f / 5f;
        float a = Mathf.Repeat(ang + seg / 2f, seg) - seg / 2f;
        // edge from the tip (angle 0, outer) to the valley (angle seg/2, inner)
        float aa = Mathf.Abs(a);
        Vector2 tip = new Vector2(0f, outer), valley = new Vector2(Mathf.Sin(seg / 2f) * inner, Mathf.Cos(seg / 2f) * inner);
        Vector2 p = new Vector2(Mathf.Sin(aa) * r, Mathf.Cos(aa) * r);
        Vector2 e = valley - tip;
        float cross = e.x * (p.y - tip.y) - e.y * (p.x - tip.x);
        return cross <= 0f;
    }

    /// <summary>White 5-point star (tint it with the Image colour).</summary>
    public static Sprite Star
    {
        get
        {
            if (star == null) star = Draw(96, (x, y) => InStar(x, y + 0.08f, 0.98f, 0.42f) ? Color.white : Color.clear);
            return star;
        }
    }

    public static Sprite Mango
    {
        get
        {
            if (mango == null)
                mango = Draw(96, (x, y) =>
                {
                    float dx = x / 0.7f, dy = (y + 0.12f) / 0.8f;
                    if (dx * dx + dy * dy <= 1f)
                    {
                        float shade = Mathf.Clamp01(0.75f + 0.35f * (-x * 0.6f + y * 0.8f));
                        Color c = Color.Lerp(new Color(0.95f, 0.5f, 0.08f), new Color(1f, 0.82f, 0.2f), shade);
                        if ((x + 0.25f) * (x + 0.25f) + (y - 0.25f) * (y - 0.25f) < 0.02f) c = Color.Lerp(c, Color.white, 0.6f);
                        return c;
                    }
                    float lx = (x - 0.2f) / 0.32f, ly = (y - 0.78f) / 0.12f;
                    if (lx * lx + ly * ly <= 1f) return new Color(0.25f, 0.65f, 0.2f);
                    return Color.clear;
                });
            return mango;
        }
    }

    public static Sprite Gem
    {
        get
        {
            if (gem == null)
                gem = Draw(96, (x, y) =>
                {
                    if (Mathf.Abs(x) + Mathf.Abs(y) > 0.92f) return Color.clear;
                    bool top = y > 0f, left = x < 0f;
                    Color c = top ? (left ? new Color(0.6f, 0.92f, 1f) : new Color(0.35f, 0.8f, 1f))
                                  : (left ? new Color(0.15f, 0.6f, 0.95f) : new Color(0.08f, 0.45f, 0.85f));
                    return c;
                });
            return gem;
        }
    }

    public static Sprite Tick
    {
        get
        {
            if (tick == null)
                tick = Draw(64, (x, y) =>
                {
                    Vector2 p = new Vector2(x, y);
                    float d = Mathf.Min(SegDist(p, new Vector2(-0.7f, 0.05f), new Vector2(-0.2f, -0.5f)), SegDist(p, new Vector2(-0.2f, -0.5f), new Vector2(0.75f, 0.6f)));
                    return d < 0.16f ? Color.white : Color.clear;
                });
            return tick;
        }
    }

    public static Sprite Lock
    {
        get
        {
            if (lockIcon == null)
                lockIcon = Draw(64, (x, y) =>
                {
                    bool body = Mathf.Abs(x) < 0.62f && y > -0.85f && y < 0.15f;
                    float r = Mathf.Sqrt(x * x + (y - 0.15f) * (y - 0.15f));
                    bool shackle = y > 0.15f && r < 0.5f && r > 0.3f;
                    if (body && (x * x + (y + 0.35f) * (y + 0.35f) < 0.02f)) return Color.clear; // keyhole
                    return body || shackle ? Color.white : Color.clear;
                });
            return lockIcon;
        }
    }

    public static Image Icon(Transform parent, Sprite sprite, Vector2 anchor, Vector2 pos, float size, Color color)
    {
        var rt = MakeRect("Icon", parent, anchor, pos, new Vector2(size, size));
        var img = rt.gameObject.AddComponent<Image>();
        img.sprite = sprite;
        img.color = color;
        img.preserveAspect = true;
        img.raycastTarget = false;
        return img;
    }

    /// <summary>A thin rotated bar from a to b (map paths).</summary>
    public static Image Bar(Transform parent, Vector2 a, Vector2 b, float width, Color color)
    {
        var rt = MakeRect("Bar", parent, new Vector2(0.5f, 0.5f), (a + b) * 0.5f, new Vector2(Vector2.Distance(a, b) + width * 0.5f, width));
        rt.localRotation = Quaternion.Euler(0, 0, Mathf.Atan2(b.y - a.y, b.x - a.x) * Mathf.Rad2Deg);
        var img = rt.gameObject.AddComponent<Image>();
        img.sprite = Rounded;
        img.type = Image.Type.Sliced;
        img.pixelsPerUnitMultiplier = 4f;
        img.color = color;
        img.raycastTarget = false;
        return img;
    }

    public static RectTransform MakeRect(string name, Transform parent, Vector2 anchor, Vector2 pos, Vector2 size)
    {
        var go = new GameObject(name, typeof(RectTransform));
        var rt = (RectTransform)go.transform;
        rt.SetParent(parent, false);
        rt.anchorMin = rt.anchorMax = anchor;
        rt.pivot = new Vector2(0.5f, 0.5f);
        rt.anchoredPosition = pos;
        rt.sizeDelta = size;
        return rt;
    }

    public static RectTransform Stretch(string name, Transform parent)
    {
        var go = new GameObject(name, typeof(RectTransform));
        var rt = (RectTransform)go.transform;
        rt.SetParent(parent, false);
        rt.anchorMin = Vector2.zero;
        rt.anchorMax = Vector2.one;
        rt.offsetMin = rt.offsetMax = Vector2.zero;
        return rt;
    }

    public static Image Panel(string name, Transform parent, Vector2 anchor, Vector2 pos, Vector2 size, Color color)
    {
        var rt = MakeRect(name, parent, anchor, pos, size);
        var img = rt.gameObject.AddComponent<Image>();
        img.sprite = Rounded;
        img.type = Image.Type.Sliced;
        img.color = color;
        return img;
    }

    public static Text Label(Transform parent, string text, int size, TextAnchor align, Color color, Vector2 anchor, Vector2 pos, Vector2 box)
    {
        var rt = MakeRect("Text", parent, anchor, pos, box);
        var t = rt.gameObject.AddComponent<Text>();
        t.font = Font;
        t.text = text;
        t.fontSize = size;
        t.alignment = align;
        t.color = color;
        t.horizontalOverflow = HorizontalWrapMode.Wrap;
        t.verticalOverflow = VerticalWrapMode.Overflow;
        t.raycastTarget = false;
        var sh = rt.gameObject.AddComponent<Shadow>();
        sh.effectColor = new Color(0, 0, 0, 0.6f);
        sh.effectDistance = new Vector2(2, -2);
        return t;
    }

    public static Text FillLabel(Transform parent, string text, int size, Color color)
    {
        var rt = Stretch("Text", parent);
        var t = rt.gameObject.AddComponent<Text>();
        t.font = Font;
        t.text = text;
        t.fontSize = size;
        t.alignment = TextAnchor.MiddleCenter;
        t.color = color;
        t.raycastTarget = false;
        return t;
    }

    public static Button MakeButton(Transform parent, string text, Vector2 anchor, Vector2 pos, Vector2 size, Color color, Action onClick, int fontSize = 44, GameAudio.Ui sound = GameAudio.Ui.Tap)
    {
        var img = Panel("Button " + text, parent, anchor, pos, size, color);
        var b = img.gameObject.AddComponent<Button>();
        b.targetGraphic = img;
        var colors = b.colors;
        colors.highlightedColor = new Color(1f, 1f, 1f, 1f);
        colors.pressedColor = new Color(0.75f, 0.75f, 0.75f, 1f);
        b.colors = colors;
        b.onClick.AddListener(() =>
        {
            if (GameAudio.I != null) GameAudio.I.PlayUi(sound);   // wooden knock
            Haptics.Tap();                                      // light vibration tap
            onClick?.Invoke();
        });
        FillLabel(img.transform, text, fontSize, Color.white);
        return b;
    }

    public static HoldButton MakeHoldButton(Transform parent, string text, Vector2 anchor, Vector2 pos, Vector2 size, Color color, int fontSize = 48)
    {
        var img = Panel("Hold " + text, parent, anchor, pos, size, color);
        FillLabel(img.transform, text, fontSize, Color.white);
        return img.gameObject.AddComponent<HoldButton>(); // added after the colour is set (it remembers it)
    }

    public static void SetButtonText(Button b, string text)
    {
        var t = b.GetComponentInChildren<Text>();
        if (t) t.text = text;
    }
}
