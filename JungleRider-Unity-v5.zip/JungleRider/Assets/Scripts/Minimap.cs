using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

/// <summary>Draws simple lines, dots and triangles in the UI (used by the round minimap).</summary>
public class MinimapGraphic : MaskableGraphic
{
    struct Line { public Vector2 a, b; public float w; public Color c; }
    struct Dot { public Vector2 p; public float r; public Color c; }
    struct Tri { public Vector2 a, b, c; public Color col; }

    readonly List<Line> lines = new List<Line>();
    readonly List<Dot> dots = new List<Dot>();
    readonly List<Tri> tris = new List<Tri>();

    public void Clear() { lines.Clear(); dots.Clear(); tris.Clear(); }
    public void AddLine(Vector2 a, Vector2 b, float w, Color c) => lines.Add(new Line { a = a, b = b, w = w, c = c });
    public void AddDot(Vector2 p, float r, Color c) => dots.Add(new Dot { p = p, r = r, c = c });
    public void AddTri(Vector2 a, Vector2 b, Vector2 c, Color col) => tris.Add(new Tri { a = a, b = b, c = c, col = col });
    public void Rebuild() => SetVerticesDirty();

    protected override void OnPopulateMesh(VertexHelper vh)
    {
        vh.Clear();
        foreach (var l in lines)
        {
            Vector2 d = l.b - l.a;
            if (d.sqrMagnitude < 1e-4f) continue;
            Vector2 n = new Vector2(-d.y, d.x).normalized * l.w * 0.5f;
            int i = vh.currentVertCount;
            vh.AddVert(l.a - n, l.c, Vector2.zero); vh.AddVert(l.a + n, l.c, Vector2.zero);
            vh.AddVert(l.b + n, l.c, Vector2.zero); vh.AddVert(l.b - n, l.c, Vector2.zero);
            vh.AddTriangle(i, i + 1, i + 2); vh.AddTriangle(i, i + 2, i + 3);
            // round joint so the trail looks smooth
            AddCircle(vh, l.b, l.w * 0.5f, l.c, 8);
        }
        foreach (var d in dots) AddCircle(vh, d.p, d.r, d.c, 14);
        foreach (var t in tris)
        {
            int i = vh.currentVertCount;
            vh.AddVert(t.a, t.col, Vector2.zero); vh.AddVert(t.b, t.col, Vector2.zero); vh.AddVert(t.c, t.col, Vector2.zero);
            vh.AddTriangle(i, i + 1, i + 2);
        }
    }

    static void AddCircle(VertexHelper vh, Vector2 c, float r, Color col, int seg)
    {
        int i0 = vh.currentVertCount;
        vh.AddVert(c, col, Vector2.zero);
        for (int k = 0; k <= seg; k++)
        {
            float a = k * Mathf.PI * 2f / seg;
            vh.AddVert(c + new Vector2(Mathf.Cos(a), Mathf.Sin(a)) * r, col, Vector2.zero);
        }
        for (int k = 0; k < seg; k++) vh.AddTriangle(i0, i0 + k + 1, i0 + k + 2);
    }
}

/// <summary>
/// Round live map in the corner while riding: the trail ahead turns with you (your direction is always up),
/// with icons for checkpoints, the finish, bridges, river, temple, waterfall and the other riders,
/// plus "X m to finish" underneath.
/// </summary>
public class Minimap : MonoBehaviour
{
    const float Range = 120f;   // metres from the centre to the edge

    MinimapGraphic g;
    Text label;
    float radius;
    TrailPath path;
    BikeController bike;
    List<int> checkpoints;
    RaceAI race;
    float nextDraw;
    public int ProgressIndex;

    static readonly Color TrailC = new Color(0.86f, 0.62f, 0.34f);
    static readonly Color WaterC = new Color(0.25f, 0.6f, 0.9f);
    static readonly Color WoodC = new Color(0.45f, 0.28f, 0.12f);
    static readonly Color RopeC = new Color(0.78f, 0.63f, 0.38f);
    static readonly Color StoneC = new Color(0.72f, 0.7f, 0.64f);
    static readonly Color CheckC = new Color(1f, 0.8f, 0.2f);
    static readonly Color YouC = new Color(1f, 0.55f, 0.1f);

    public static Minimap Create(Transform parent, Vector2 anchor, Vector2 pos, float size)
    {
        var root = UIFactory.MakeRect("Minimap", parent, anchor, pos, new Vector2(size, size));
        var ring = root.gameObject.AddComponent<Image>();
        ring.sprite = UIFactory.Circle;
        ring.color = new Color(0.85f, 0.9f, 0.85f, 0.55f);
        ring.raycastTarget = false;

        var inner = UIFactory.MakeRect("Inner", root, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(size - 10f, size - 10f));
        var bg = inner.gameObject.AddComponent<Image>();
        bg.sprite = UIFactory.Circle;
        bg.color = new Color(0.16f, 0.36f, 0.16f, 0.92f);
        bg.raycastTarget = false;
        var mask = inner.gameObject.AddComponent<Mask>();
        mask.showMaskGraphic = true;

        var gr = UIFactory.Stretch("Lines", inner).gameObject.AddComponent<MinimapGraphic>();
        gr.raycastTarget = false;

        var m = root.gameObject.AddComponent<Minimap>();
        m.g = gr;
        m.radius = (size - 10f) * 0.5f;
        m.label = UIFactory.Label(root.parent, "", 34, TextAnchor.MiddleCenter, Color.white, anchor, pos + new Vector2(0, -size * 0.5f - 30f), new Vector2(size + 120f, 50f));
        return m;
    }

    public void Setup(TrailPath p, BikeController b, List<int> cps, RaceAI ai)
    {
        path = p;
        bike = b;
        checkpoints = cps;
        race = ai;
    }

    void LateUpdate()
    {
        if (path == null || bike == null) return;
        if (Time.unscaledTime < nextDraw) return;
        nextDraw = Time.unscaledTime + 0.05f;

        Vector3 c = bike.transform.position;
        Vector3 f = bike.transform.forward; f.y = 0f;
        if (f.sqrMagnitude < 1e-4f) f = Vector3.forward;
        f.Normalize();
        Vector3 r = new Vector3(f.z, 0f, -f.x);
        float k = radius / Range;
        System.Func<Vector3, Vector2> map = w => { Vector3 d = w - c; return new Vector2(Vector3.Dot(d, r), Vector3.Dot(d, f)) * k; };

        g.Clear();
        int i0 = Mathf.Max(0, ProgressIndex - 30), i1 = ProgressIndex + 70;
        int fin = path.FinishIndex;
        if (fin != int.MaxValue) i1 = Mathf.Min(i1, fin + 6);

        // water first (under the trail)
        for (int z = 0; z < path.Zones.Count; z++)
        {
            var zone = path.Zones[z];
            if (zone.gapEnd < i0 || zone.gapStart > i1) continue;
            if (zone.type == FeatureType.River || zone.IsGorge)
            {
                Vector3 mid = path.PointAt((zone.gapStart + zone.gapEnd) * 0.5f);
                Vector3 rt = path.Right(zone.gapStart);
                float w = (zone.gapEnd - zone.gapStart + 1) * TrailPath.SegLen * k;
                g.AddLine(map(mid - rt * 60f), map(mid + rt * 60f), Mathf.Max(10f, w * (zone.IsGorge ? 0.5f : 1f)), zone.IsGorge ? new Color(0.12f, 0.2f, 0.12f) : WaterC);
                if (zone.IsGorge) g.AddLine(map(mid - rt * 60f), map(mid + rt * 60f), 7f, WaterC);
            }
        }

        // the trail
        Vector2 prev = map(path.Point(i0));
        for (int i = i0 + 1; i <= i1; i++)
        {
            Vector2 p = map(path.Point(i));
            g.AddLine(prev, p, 13f, TrailC);
            prev = p;
        }

        // adventures on top of the trail
        for (int z = 0; z < path.Zones.Count; z++)
        {
            var zone = path.Zones[z];
            if (zone.gapEnd < i0 || zone.gapStart > i1) continue;
            Vector2 a = map(path.Point(zone.gapStart - 1)), b = map(path.Point(Mathf.Min(zone.gapEnd + 1, i1)));
            switch (zone.type)
            {
                case FeatureType.WoodBridge: g.AddLine(a, b, 15f, WoodC); break;
                case FeatureType.RopeBridge: g.AddLine(a, b, 11f, RopeC); g.AddLine(a, b, 4f, WoodC); break;
                case FeatureType.Waterfall: g.AddDot(map(path.Point(zone.gapStart) + path.Right(zone.gapStart) * 16f), 11f, Color.white); break;
                case FeatureType.Temple: g.AddLine(a, b, 17f, StoneC); break;
                case FeatureType.Monkeys: g.AddDot(map(path.Point(zone.gapStart)), 8f, new Color(0.45f, 0.28f, 0.14f)); break;
            }
        }

        // checkpoints and finish
        if (checkpoints != null)
            foreach (int cp in checkpoints)
                if (cp >= i0 && cp <= i1)
                {
                    Vector2 p = map(path.Point(cp));
                    g.AddDot(p, 10f, Color.black);
                    g.AddDot(p, 8f, CheckC);
                }
        if (fin != int.MaxValue && fin <= i1)
        {
            Vector2 p = map(path.Point(fin));
            g.AddDot(p, 12f, Color.black);
            g.AddDot(p, 9f, Color.white);
        }

        // other riders
        if (race != null)
            foreach (var rider in race.Riders)
            {
                Vector3 pos = rider.position;
                if ((pos - c).sqrMagnitude > Range * Range * 1.2f) continue;
                g.AddDot(map(pos), 6.5f, rider.jersey);
            }

        // you: an arrow pointing up
        g.AddDot(Vector2.zero, 13f, Color.white);
        g.AddTri(new Vector2(0, 15f), new Vector2(9f, -8f), new Vector2(-9f, -8f), YouC);
        g.Rebuild();

        if (fin == int.MaxValue) label.text = "";
        else
        {
            float left = Mathf.Max(0f, (fin - path.Progress(c, ProgressIndex)) * TrailPath.SegLen);
            label.text = Mathf.CeilToInt(left) + " m to finish";
        }
    }
}
