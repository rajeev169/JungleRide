using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEngine;

/// <summary>
/// TEST RIDE (for the Android emulator on GitHub). Only runs when the game is started with the extra
/// "autotest" (for example: adb shell am start ... -e autotest "1-15"). Normal players never see it.
/// An autopilot rides each level with the real bike physics; the game saves screenshots at every adventure,
/// on every crash and when stuck, plus a text report, in the app's files folder: autotest/.
/// </summary>
public partial class GameBootstrap
{
    bool testing, crashPending, crashApproved;
    string testDir;
    StringBuilder testLog;
    int shotCount, crashShots;
    readonly List<string> testErrors = new List<string>();

    static string ReadTestRequest()
    {
#if UNITY_ANDROID && !UNITY_EDITOR
        try
        {
            using (var up = new AndroidJavaClass("com.unity3d.player.UnityPlayer"))
            using (var act = up.GetStatic<AndroidJavaObject>("currentActivity"))
            using (var intent = act.Call<AndroidJavaObject>("getIntent"))
                return intent.Call<string>("getStringExtra", "autotest");
        }
        catch { return null; }
#else
        var args = System.Environment.GetCommandLineArgs();
        for (int i = 0; i < args.Length - 1; i++) if (args[i] == "-autotest") return args[i + 1];
        return null;
#endif
    }

    /// <summary>"1-15", "3,5,12", "1-3,12" or "all".</summary>
    static List<int> ParseLevels(string s)
    {
        var list = new List<int>();
        if (string.IsNullOrEmpty(s)) return list;
        if (s.Trim().ToLower() == "all") s = "1-" + LevelDefs.Count;
        foreach (var part in s.Split(','))
        {
            var p = part.Trim();
            int dash = p.IndexOf('-');
            if (dash > 0)
            {
                if (int.TryParse(p.Substring(0, dash), out int a) && int.TryParse(p.Substring(dash + 1), out int b))
                    for (int l = a; l <= b; l++) list.Add(l);
            }
            else if (int.TryParse(p, out int one)) list.Add(one);
        }
        list.RemoveAll(l => l < 1 || l > LevelDefs.Count);
        return list;
    }

    void StartAutoTestIfRequested()
    {
        var levels = ParseLevels(ReadTestRequest());
        if (levels.Count > 0) StartCoroutine(AutoTest(levels));
    }

    void OnTestLog(string condition, string stackTrace, LogType type)
    {
        if (type != LogType.Error && type != LogType.Exception && type != LogType.Assert) return;
        if (testErrors.Count >= 40) return;
        string first = stackTrace;
        int nl = first.IndexOf('\n');
        if (nl > 0) first = first.Substring(0, nl);
        string line = type + ": " + condition + (first.Length > 0 ? "   [" + first + "]" : "");
        if (!testErrors.Contains(line)) testErrors.Add(line);
    }

    string ReportPath => Path.Combine(testDir, "report.txt");

    void WriteReport(bool done)
    {
        var all = new StringBuilder(testLog.ToString());
        all.AppendLine();
        all.AppendLine(testErrors.Count == 0 ? "Script errors: none" : "Script errors (" + testErrors.Count + "):");
        foreach (var e in testErrors) all.AppendLine("  " + e);
        if (done) all.AppendLine("\nTEST RIDE FINISHED");
        File.WriteAllText(ReportPath, all.ToString());
        if (done) File.WriteAllText(Path.Combine(testDir, "done.txt"), "done");
    }

    void Shot(string name)
    {
        if (++shotCount > 250) return;
#if UNITY_ANDROID && !UNITY_EDITOR
        ScreenCapture.CaptureScreenshot("autotest/" + name + ".png");   // Android: relative to the files folder
#else
        ScreenCapture.CaptureScreenshot(Path.Combine(testDir, name + ".png"));
#endif
    }

    IEnumerator AutoTest(List<int> levels)
    {
        testing = true;
        testDir = Path.Combine(Application.persistentDataPath, "autotest");
        if (Directory.Exists(testDir)) Directory.Delete(testDir, true);
        Directory.CreateDirectory(testDir);
        Application.logMessageReceived += OnTestLog;
        QualitySettings.shadows = ShadowQuality.Disable;   // the emulator has no graphics card: keep it light
        Time.maximumDeltaTime = 0.1f;                       // slow frames slow the game down instead of skipping physics
        Application.targetFrameRate = 30;
        if (Screen.width > 1280) Screen.SetResolution(Screen.width / 2, Screen.height / 2, true);   // half size: faster on the emulator

        testLog = new StringBuilder();
        testLog.AppendLine("JUNGLE RIDER - TEST RIDE");
        testLog.AppendLine("Device: " + SystemInfo.deviceModel + "  |  " + SystemInfo.graphicsDeviceName + "  |  " + SystemInfo.graphicsDeviceVersion);
        testLog.AppendLine("Screen: " + Screen.width + " x " + Screen.height + "   Levels: " + string.Join(",", levels.ConvertAll(l => l.ToString()).ToArray()));
        testLog.AppendLine();
        WriteReport(false);

        yield return new WaitForSecondsRealtime(3f);
        Shot("00_menu");
        yield return new WaitForSecondsRealtime(1f);

        foreach (int l in levels)
        {
            yield return TestLevel(l);
            WriteReport(false);
        }

        input.Autopilot = false;
        Application.logMessageReceived -= OnTestLog;
        WriteReport(true);
        Debug.Log("AUTOTEST DONE");
        testing = false;
        GoToMenu();
    }

    string ZoneLabel(int i)
    {
        for (int k = 0; k <= 3; k++)
        {
            var z = path.ZoneAt(i + k);
            if (z == null) continue;
            if (z.type == FeatureType.Spiral) return " (MOUNTAIN round " + RoundNumber() + ")";
            return " (" + (k == 0 ? "at " : "near ") + LevelDefs.FeatureName(z.type) + ")";
        }
        return "";
    }

    static string Slug(string s) => s.ToLower().Replace(' ', '_');

    IEnumerator TestLevel(int l)
    {
        var def = LevelDefs.Get(l);
        bool withRace = l % 3 == 1;   // race against computer riders on levels 1, 4, 7, 10, 13
        string tag = "L" + l.ToString("00");
        var feats = new List<string>();
        foreach (var f in def.features) feats.Add(LevelDefs.FeatureName(f.type));
        testLog.AppendLine("LEVEL " + l + "  (" + Seasons.Name(def.season) + (withRace ? ", race" : ", solo") + ")  " + string.Join(", ", feats.ToArray()));

        lastStars = 0; lastPlace = 0; crashShots = 0;
        StartRun(GameMode.Levels, l, def.season, withRace);
        input.Autopilot = true;
        input.autoSteer = input.autoThrottle = input.autoBrake = 0f;
        while (state == State.Countdown) yield return null;
        yield return null;
        Shot(tag + "_00_start");

        var seen = new HashSet<int>();
        int shotNo = 1, stucks = 0, flipsBefore = tricks.Backflips;
        bool flipTried = false, flipLogged = false;
        float still = 0f, air = 0f, brakeTap = 0f;
        float limit = def.parTime * 3f + 60f;
        float fpsSum = 0f, fpsMin = 999f; int frames = 0;
        string result = "";

        while (state == State.Playing || state == State.Paused)
        {
            if (state != State.Playing) { yield return null; continue; }
            float dt = Time.deltaTime;
            float fps = 1f / Mathf.Max(0.0001f, Time.unscaledDeltaTime);
            fpsSum += fps; frames++; if (frames > 30) fpsMin = Mathf.Min(fpsMin, fps);

            // ---------- autopilot ----------
            Vector3 pos = bike.transform.position;
            float speed = bike.ForwardSpeed;
            float prog = path.Progress(pos, progressIdx);
            float lookM = Mathf.Clamp(4f + Mathf.Abs(speed) * 0.6f, 5f, 14f);
            Vector3 target = path.PointAt(prog + lookM / TrailPath.SegLen);
            Vector3 local = bike.transform.InverseTransformPoint(target);
            float steer = Mathf.Clamp(Mathf.Atan2(local.x, Mathf.Max(0.5f, local.z)) * 2.4f, -1f, 1f);

            float bend = Vector3.Angle(path.Forward(progressIdx), path.Forward(progressIdx + 4));
            float want = bend > 30f ? 7f : bend > 18f ? 10f : 16f;
            var z = path.ZoneAt(progressIdx);
            var zAhead = path.ZoneAt(progressIdx + 3);
            if ((z != null && z.type == FeatureType.RopeBridge) || (zAhead != null && zAhead.type == FeatureType.RopeBridge)) want = 7f;
            bool jump = (z != null && z.type == FeatureType.Waterfall) || (zAhead != null && zAhead.type == FeatureType.Waterfall);
            if (jump) want = 16f;

            float thr = speed < want ? 1f : 0f;
            float brk = bike.Grounded && speed > want + 2.5f ? 1f : 0f;

            // one backflip test on the first waterfall jump
            if (!bike.Grounded) air += dt; else air = 0f;
            if (jump && !flipTried && air > 0.25f) { flipTried = true; brakeTap = 0.12f; }
            if (brakeTap > 0f) { brk = 1f; brakeTap -= dt; }
            else if (!bike.Grounded) brk = 0f;
            if (flipTried && !flipLogged && bike.Grounded && air == 0f && brakeTap <= 0f)
            {
                flipLogged = true;
                testLog.AppendLine("  Backflip test on the waterfall jump: " + (tricks.Backflips > flipsBefore ? "OK" : "not completed (see crashes)"));
            }

            input.autoSteer = steer;
            input.autoThrottle = thr;
            input.autoBrake = brk;

            // ---------- screenshots at each adventure ----------
            if (z != null && z.type != FeatureType.Spiral && progressIdx >= z.gapStart - 1 && seen.Add(z.id))
                Shot(tag + "_" + (shotNo++).ToString("00") + "_" + Slug(LevelDefs.FeatureName(z.type)));
            if (z != null && z.type == FeatureType.Spiral)
            {
                int key = 1000 + RoundNumber();
                if (seen.Add(key)) Shot(tag + "_" + (shotNo++).ToString("00") + "_mountain_round" + RoundNumber());
                if (progressIdx >= path.FinishIndex - 6 && seen.Add(2000)) Shot(tag + "_" + (shotNo++).ToString("00") + "_summit");
            }

            // ---------- stuck? ----------
            if (Mathf.Abs(speed) < 0.4f && !crashPending) still += dt; else still = 0f;
            if (still > 6f)
            {
                stucks++;
                testLog.AppendLine("  STUCK at " + Mathf.FloorToInt(distance) + " m" + ZoneLabel(progressIdx) + " (speed 0 for 6 s while pedalling)");
                Shot(tag + "_stuck" + stucks);
                yield return null;
                still = 0f;
                if (stucks >= 5) { result = "GAVE UP (stuck 5 times)"; break; }
                PlaceBike(path.SafeIndex(progressIdx + 4));
            }

            if (raceTime > limit) { result = "TIMEOUT after " + GameSettings.FormatTime(raceTime); break; }
            yield return null;
        }

        input.autoSteer = input.autoThrottle = input.autoBrake = 0f;
        if (state == State.Result && result.Length == 0)
        {
            var d = LevelDefs.Get(l);
            testLog.AppendLine("  FINISHED in " + GameSettings.FormatTime(raceTime) + "  (star time " + GameSettings.FormatTime(d.parTime) + ")  stars " + lastStars + "/3"
                + "  crashes " + crashes + "  fruits " + runMangoes + "/" + mangoTarget + "  gems " + runGems + "  tricks " + tricks.Score
                + (withRace ? "  race place " + RaceAI.Ordinal(lastPlace) + " of " + (race.Count + 1) : ""));
            yield return new WaitForSecondsRealtime(0.6f);
            Shot(tag + "_99_result");
            yield return new WaitForSecondsRealtime(0.5f);
        }
        else
        {
            if (result.Length == 0) result = "STOPPED (state " + state + ")";
            testLog.AppendLine("  NOT FINISHED: " + result + " at " + Mathf.FloorToInt(distance) + " / " + Mathf.RoundToInt(cfg.length) + " m" + ZoneLabel(progressIdx) + ", crashes " + crashes);
            Shot(tag + "_99_notfinished");
            yield return null;
            StopRiding();
            runOpen = false;
        }
        testLog.AppendLine("  Speed of the emulator: average " + (frames > 0 ? Mathf.RoundToInt(fpsSum / frames) : 0) + " fps, lowest " + (fpsMin > 900f ? 0 : Mathf.RoundToInt(fpsMin)) + " fps");
        testLog.AppendLine();
    }

    /// <summary>Test ride: take a picture of the crash before the bike is put back.</summary>
    bool TestCrashFirst()
    {
        if (!testing) return false;
        if (crashApproved) { crashApproved = false; return false; }
        if (!crashPending)
        {
            crashPending = true;
            StartCoroutine(TestCrashShot());
        }
        return true;
    }

    IEnumerator TestCrashShot()
    {
        testLog.AppendLine("  CRASH " + (crashes + 1) + " at " + Mathf.FloorToInt(distance) + " m" + ZoneLabel(progressIdx) + ": " + crashReason);
        if (crashShots++ < 5) Shot("L" + level.ToString("00") + "_crash" + (crashes + 1));
        yield return new WaitForEndOfFrame();
        yield return new WaitForSecondsRealtime(0.3f);
        crashPending = false;
        if (state == State.Playing)
        {
            crashApproved = true;
            OnCrash();
        }
    }
}
