using System;
using UnityEngine;

/// <summary>
/// Tricks: press BRAKE while in the air to do a backflip. Land it fully to score; land in the middle of the
/// flip and you crash. Long jumps score "BIG AIR". Tricks within 5 seconds of each other build a combo (x2, x3 ...).
/// </summary>
public class TrickSystem : MonoBehaviour
{
    public const int BackflipPoints = 500;
    const float ComboWindow = 5f;

    public bool Active;
    public int Score { get; private set; }
    public int Backflips { get; private set; }
    public int Combo { get; private set; } = 1;

    /// <summary>name, points, combo multiplier</summary>
    public event Action<string, int, int> Trick;
    public event Action BadLanding;

    BikeController bike;
    BikeInput input;
    float air, comboTimer, flip;
    bool flipping, wasGrounded = true;

    public static TrickSystem Create(BikeController b)
    {
        var t = b.gameObject.AddComponent<TrickSystem>();
        t.bike = b;
        t.input = b.input;
        return t;
    }

    public void ResetRun()
    {
        Score = 0;
        Backflips = 0;
        ResetJump();
        Combo = 1;
        comboTimer = 0f;
    }

    /// <summary>After a crash or respawn.</summary>
    public void ResetJump()
    {
        air = 0f;
        flip = 0f;
        flipping = false;
        wasGrounded = true;
        if (bike) bike.flipAngle = 0f;
        Combo = 1;
        comboTimer = 0f;
    }

    float FlipTime => 0.72f - 0.035f * Economy.Level(Upgrade.Suspension);
    float LandTolerance => 0.16f + 0.02f * Economy.Level(Upgrade.Suspension);   // fraction of a turn still allowed when landing

    void Update()
    {
        if (!Active || bike == null || Time.deltaTime <= 0f) return;
        float dt = Time.deltaTime;
        bool grounded = bike.Grounded;
        comboTimer -= dt;
        if (comboTimer <= 0f) Combo = 1;

        if (!grounded)
        {
            air += dt;
            bool brake = input && input.Brake > 0f;
            if (!flipping && brake && air > 0.22f) flipping = true;
            if (flipping)
            {
                // keeps turning while BRAKE is held; when released it finishes the turn it is on
                float target = brake ? float.MaxValue : Mathf.Ceil(flip / 360f - 0.001f) * 360f;
                flip = Mathf.Min(target, flip + 360f / FlipTime * dt);
            }
        }
        else if (!wasGrounded)
        {
            Land();
        }
        bike.flipAngle = flip;
        wasGrounded = grounded;
    }

    void Land()
    {
        int turns = Mathf.FloorToInt(flip / 360f);
        float rest = flip / 360f - turns;
        if (flipping)
        {
            if (rest >= 1f - LandTolerance) { turns++; rest = 0f; }
            if (rest > LandTolerance)
            {
                // landed upside down / sideways
                flip = 0f; flipping = false; air = 0f;
                bike.flipAngle = 0f;
                Combo = 1;
                comboTimer = 0f;
                bike.forceCrash = true;
                BadLanding?.Invoke();
                return;
            }
        }

        int points = 0;
        string name = null;
        if (turns > 0)
        {
            Backflips += turns;
            points += BackflipPoints * turns;
            name = turns == 1 ? "BACKFLIP!" : turns == 2 ? "DOUBLE BACKFLIP!" : turns + "x BACKFLIP!";
        }
        if (air > 0.9f)
        {
            int big = Mathf.RoundToInt(air * 100f / 10f) * 10;
            points += big;
            if (name == null) name = "BIG AIR!";
        }
        if (name != null)
        {
            if (comboTimer > 0f) Combo++;
            else Combo = 1;
            comboTimer = ComboWindow;
            Score += points * Combo;
            Trick?.Invoke(name, points, Combo);
        }
        flip = 0f;
        flipping = false;
        air = 0f;
        bike.flipAngle = 0f;
    }
}
