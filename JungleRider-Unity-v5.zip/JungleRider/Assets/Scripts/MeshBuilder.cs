using System.Collections.Generic;
using UnityEngine;

/// <summary>Builds flat-shaded, vertex-coloured low-poly meshes from simple shapes.</summary>
public class MeshBuilder
{
    readonly List<Vector3> verts = new List<Vector3>();
    readonly List<Color> colors = new List<Color>();
    readonly List<int> tris = new List<int>();

    public void Tri(Vector3 a, Vector3 b, Vector3 c, Color col)
    {
        int i = verts.Count;
        verts.Add(a); verts.Add(b); verts.Add(c);
        colors.Add(col); colors.Add(col); colors.Add(col);
        tris.Add(i); tris.Add(i + 1); tris.Add(i + 2);
    }

    public void Quad(Vector3 a, Vector3 b, Vector3 c, Vector3 d, Color col)
    {
        Tri(a, b, c, col);
        Tri(a, c, d, col);
    }

    /// <summary>Triangle whose front face points away from <paramref name="inside"/> (Unity: clockwise = front).</summary>
    public void TriOut(Vector3 a, Vector3 b, Vector3 c, Color col, Vector3 inside)
    {
        Vector3 n = Vector3.Cross(b - a, c - a);
        if (Vector3.Dot(n, (a + b + c) / 3f - inside) < 0f) Tri(a, c, b, col);
        else Tri(a, b, c, col);
    }

    public void QuadOut(Vector3 a, Vector3 b, Vector3 c, Vector3 d, Color col, Vector3 inside)
    {
        TriOut(a, b, c, col, inside);
        TriOut(a, c, d, col, inside);
    }

    public void DoubleQuad(Vector3 a, Vector3 b, Vector3 c, Vector3 d, Color col)
    {
        Quad(a, b, c, d, col);
        Quad(a, d, c, b, Shade(col, 0.85f));
    }

    /// <summary>Cylinder/cone frustum from p0 (radius r0) to p1 (radius r1).</summary>
    public void Cylinder(Vector3 p0, Vector3 p1, float r0, float r1, int sides, Color col, bool caps = true)
    {
        Vector3 axis = (p1 - p0).normalized;
        Vector3 side = Vector3.Cross(axis, Mathf.Abs(axis.y) > 0.9f ? Vector3.right : Vector3.up).normalized;
        Vector3 side2 = Vector3.Cross(axis, side);
        for (int i = 0; i < sides; i++)
        {
            float a0 = i * Mathf.PI * 2f / sides, a1 = (i + 1) * Mathf.PI * 2f / sides;
            Vector3 d0 = side * Mathf.Cos(a0) + side2 * Mathf.Sin(a0);
            Vector3 d1 = side * Mathf.Cos(a1) + side2 * Mathf.Sin(a1);
            Color c = Shade(col, 0.9f + 0.1f * Mathf.Cos(a0 * 3f));
            Vector3 mid = (p0 + p1) * 0.5f;
            QuadOut(p0 + d0 * r0, p1 + d0 * r1, p1 + d1 * r1, p0 + d1 * r0, c, mid);
            if (caps)
            {
                if (r1 > 0.001f) TriOut(p1, p1 + d1 * r1, p1 + d0 * r1, col, mid);
                if (r0 > 0.001f) TriOut(p0, p0 + d0 * r0, p0 + d1 * r0, col, mid);
            }
        }
    }

    /// <summary>Low-poly blob (squashed sphere) with a little random wobble.</summary>
    public void Blob(Vector3 center, Vector3 radius, Color col, System.Random rnd, int rings = 4, int segs = 7, float wobble = 0.15f)
    {
        var pts = new Vector3[rings + 1, segs];
        for (int r = 0; r <= rings; r++)
        {
            float lat = Mathf.PI * r / rings - Mathf.PI / 2f;
            for (int s = 0; s < segs; s++)
            {
                float lon = Mathf.PI * 2f * s / segs;
                float w = (r == 0 || r == rings) ? 1f : 1f + ((float)rnd.NextDouble() - 0.5f) * 2f * wobble;
                Vector3 d = new Vector3(Mathf.Cos(lat) * Mathf.Cos(lon), Mathf.Sin(lat), Mathf.Cos(lat) * Mathf.Sin(lon));
                pts[r, s] = center + Vector3.Scale(d, radius) * w;
            }
        }
        for (int r = 0; r < rings; r++)
            for (int s = 0; s < segs; s++)
            {
                int s1 = (s + 1) % segs;
                float shade = 0.85f + 0.3f * r / rings;
                Color c = new Color(col.r * shade, col.g * shade, col.b * shade, 1f);
                QuadOut(pts[r, s], pts[r + 1, s], pts[r + 1, s1], pts[r, s1], c, center);
            }
    }

    public void Box(Vector3 center, Vector3 size, Quaternion rot, Color col)
    {
        Vector3 h = size * 0.5f;
        Vector3[] c = new Vector3[8];
        for (int i = 0; i < 8; i++)
            c[i] = center + rot * new Vector3((i & 1) == 0 ? -h.x : h.x, (i & 2) == 0 ? -h.y : h.y, (i & 4) == 0 ? -h.z : h.z);
        QuadOut(c[0], c[2], c[3], c[1], Shade(col, 0.8f), center);   // -z
        QuadOut(c[4], c[5], c[7], c[6], Shade(col, 0.8f), center);   // +z
        QuadOut(c[0], c[4], c[6], c[2], Shade(col, 0.9f), center);   // -x
        QuadOut(c[1], c[3], c[7], c[5], Shade(col, 0.9f), center);   // +x
        QuadOut(c[2], c[6], c[7], c[3], col, center);                // +y
        QuadOut(c[0], c[1], c[5], c[4], Shade(col, 0.6f), center);   // -y
    }

    public static Color Shade(Color c, float k) => new Color(c.r * k, c.g * k, c.b * k, 1f);

    public Mesh ToMesh(string name)
    {
        var m = new Mesh { name = name };
        if (verts.Count > 65000) m.indexFormat = UnityEngine.Rendering.IndexFormat.UInt32;
        m.SetVertices(verts);
        m.SetColors(colors);
        m.SetTriangles(tris, 0);
        m.RecalculateNormals();
        m.RecalculateBounds();
        return m;
    }
}
