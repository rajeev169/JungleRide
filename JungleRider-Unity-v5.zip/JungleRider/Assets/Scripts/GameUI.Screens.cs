using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

/// <summary>World map, shop and daily rewards screens.</summary>
public partial class GameUI
{
    GameObject map, shop, daily;

    // ------------------------------------------------------------------ world map
    readonly Button[] nodeButtons = new Button[LevelDefs.Count];
    readonly Image[][] nodeStars = new Image[LevelDefs.Count][];
    GameObject lockedOverlay;
    RectTransform youPin;
    Text mapMangoes, mapGems, mapStars, lockedText;

    // positions from the world map mock-up (1612 x 720 picture)
    static Vector2 M(float x, float y) => new Vector2((x / 1612f - 0.5f) * 1920f, (0.5f - y / 720f) * 1080f);

    static readonly Vector2[] NodeXY =
    {
        new Vector2(120, 640), new Vector2(260, 600), new Vector2(380, 650), new Vector2(500, 610), new Vector2(560, 520),
        new Vector2(470, 440), new Vector2(560, 370), new Vector2(700, 400), new Vector2(820, 330), new Vector2(760, 250),
        new Vector2(880, 200), new Vector2(1050, 270), new Vector2(1180, 330), new Vector2(1300, 280), new Vector2(1400, 200),
    };

    static readonly Vector2[] RiverXY =
    {
        new Vector2(-60, 515), new Vector2(180, 495), new Vector2(330, 545), new Vector2(480, 555), new Vector2(620, 505), new Vector2(760, 440),
        new Vector2(900, 415), new Vector2(1050, 440), new Vector2(1180, 450), new Vector2(1280, 420), new Vector2(1380, 330), new Vector2(1440, 230),
        new Vector2(1470, 100), new Vector2(1475, -60),
    };

    static Color SeasonColor(Season s) => s == Season.Summer ? new Color(1f, 0.65f, 0.15f) : s == Season.Monsoon ? new Color(0.25f, 0.6f, 0.95f) : new Color(0.92f, 0.95f, 1f);

    void BuildMap(Transform root)
    {
        map = UIFactory.Stretch("WorldMap", root).gameObject;
        var bg = map.AddComponent<Image>();
        bg.color = new Color(0.3f, 0.52f, 0.22f);
        var content = UIFactory.MakeRect("Content", map.transform, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(1920, 1080));

        // jungle: tree tops
        var rnd = new System.Random(21);
        for (int k = 0; k < 140; k++)
        {
            var p = new Vector2((float)rnd.NextDouble() * 2400f - 1200f, (float)rnd.NextDouble() * 1200f - 600f);
            float size = 50f + (float)rnd.NextDouble() * 90f;
            Color c = Color.Lerp(new Color(0.16f, 0.4f, 0.14f), new Color(0.36f, 0.62f, 0.25f), (float)rnd.NextDouble());
            UIFactory.Icon(content, UIFactory.Circle, new Vector2(0.5f, 0.5f), p, size, c);
        }
        // river
        for (int k = 0; k < RiverXY.Length - 1; k++)
        {
            UIFactory.Bar(content, M(RiverXY[k].x, RiverXY[k].y), M(RiverXY[k + 1].x, RiverXY[k + 1].y), 50f, new Color(0.3f, 0.6f, 0.82f));
            UIFactory.Bar(content, M(RiverXY[k].x, RiverXY[k].y), M(RiverXY[k + 1].x, RiverXY[k + 1].y), 8f, new Color(0.65f, 0.85f, 0.98f, 0.8f));
        }
        // dirt path between levels
        for (int k = 0; k < NodeXY.Length - 1; k++)
            UIFactory.Bar(content, M(NodeXY[k].x, NodeXY[k].y), M(NodeXY[k + 1].x, NodeXY[k + 1].y), 26f, new Color(0.86f, 0.64f, 0.38f));
        // little landmarks: bridge, temple, waterfall
        var bridge = UIFactory.Bar(content, M(510, 540), M(530, 605), 30f, new Color(0.45f, 0.28f, 0.12f));
        var temple = M(1055, 185);
        UIFactory.Panel("TempleTop", content, new Vector2(0.5f, 0.5f), temple + new Vector2(0, 60), new Vector2(140, 26), new Color(0.55f, 0.55f, 0.52f));
        UIFactory.Panel("TempleL", content, new Vector2(0.5f, 0.5f), temple + new Vector2(-50, -5), new Vector2(30, 120), new Color(0.58f, 0.58f, 0.55f));
        UIFactory.Panel("TempleR", content, new Vector2(0.5f, 0.5f), temple + new Vector2(50, -5), new Vector2(30, 120), new Color(0.58f, 0.58f, 0.55f));
        UIFactory.Panel("Waterfall", content, new Vector2(0.5f, 0.5f), M(1452, 205), new Vector2(54, 160), new Color(0.92f, 0.97f, 1f));

        // area names
        AreaLabel(content, "BAMBOO FOREST", M(330, 550));
        AreaLabel(content, "RIVER VALLEY", M(700, 465));
        AreaLabel(content, "MONKEY WOODS", M(620, 225));
        AreaLabel(content, "TEMPLE RUINS", M(1060, 105));

        // locked area (Waterfall Cliffs) overlay
        float lx = M(1150, 0).x;
        lockedOverlay = UIFactory.MakeRect("Locked", content, new Vector2(0.5f, 0.5f), new Vector2((lx + 1300f) * 0.5f, 0), new Vector2(1300f - lx, 1300)).gameObject;
        lockedOverlay.AddComponent<Image>().color = new Color(0.55f, 0.55f, 0.52f, 0.62f);
        var lockBox = UIFactory.Panel("LockBox", content, new Vector2(0.5f, 0.5f), M(1385, 475), new Vector2(560, 190), new Color(0.06f, 0.1f, 0.07f, 0.92f));
        lockBox.transform.SetParent(lockedOverlay.transform, true);
        UIFactory.Icon(lockBox.transform, UIFactory.Lock, new Vector2(0.5f, 1f), new Vector2(0, -40), 46, Color.white);
        UIFactory.Label(lockBox.transform, "LOCKED AREA", 42, TextAnchor.MiddleCenter, Color.white, new Vector2(0.5f, 0.5f), new Vector2(0, -5), new Vector2(540, 60));
        lockedText = UIFactory.Label(lockBox.transform, "", 34, TextAnchor.MiddleCenter, Gold, new Vector2(0.5f, 0f), new Vector2(0, 38), new Vector2(540, 50));
        AreaLabel(content, "WATERFALL CLIFFS", M(1440, 100));

        // level nodes
        for (int i = 0; i < LevelDefs.Count; i++)
        {
            int level = i + 1;
            Vector2 p = M(NodeXY[i].x, NodeXY[i].y);
            var b = UIFactory.MakeButton(content, level.ToString(), new Vector2(0.5f, 0.5f), p, new Vector2(100, 100), UIFactory.Green, () => TapLevel(level), 46);
            var img = b.GetComponent<Image>();
            img.sprite = UIFactory.Circle;
            img.type = Image.Type.Simple;
            var ring = b.gameObject.AddComponent<Outline>();
            ring.effectColor = new Color(1f, 1f, 1f, 0.9f);
            ring.effectDistance = new Vector2(4, -4);
            var sd = LevelDefs.Get(level).season;
            UIFactory.Icon(b.transform, UIFactory.Circle, new Vector2(0.5f, 0.5f), new Vector2(36, 36), 34, Color.white);
            UIFactory.Icon(b.transform, UIFactory.Circle, new Vector2(0.5f, 0.5f), new Vector2(36, 36), 26, SeasonColor(sd));
            nodeStars[i] = new Image[3];
            for (int k = 0; k < 3; k++)
                nodeStars[i][k] = UIFactory.Icon(b.transform, UIFactory.Star, new Vector2(0.5f, 0.5f), new Vector2((k - 1) * 30f, -72), 30, StarOff);
            nodeButtons[i] = b;
        }

        // "YOU" pin
        youPin = UIFactory.MakeRect("You", content, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(80, 120));
        UIFactory.Label(youPin, "YOU", 30, TextAnchor.MiddleCenter, Color.white, new Vector2(0.5f, 1f), new Vector2(0, -10), new Vector2(120, 40));
        UIFactory.Icon(youPin, UIFactory.Circle, new Vector2(0.5f, 0.5f), new Vector2(0, -5), 66, new Color(0.95f, 0.5f, 0.1f));
        UIFactory.Icon(youPin, UIFactory.Circle, new Vector2(0.5f, 0.5f), new Vector2(0, -5), 34, new Color(0.1f, 0.15f, 0.1f));

        // top bar
        mapMangoes = WalletPill(map.transform, new Vector2(0f, 1f), new Vector2(310, -65), out mapGems, true, out mapStars);
        var legend = UIFactory.Panel("Legend", map.transform, new Vector2(0f, 1f), new Vector2(240, -215), new Vector2(420, 170), UIFactory.Dark);
        string[] names = { "Summer level", "Monsoon level", "Winter level" };
        for (int k = 0; k < 3; k++)
        {
            UIFactory.Icon(legend.transform, UIFactory.Circle, new Vector2(0f, 1f), new Vector2(40, -35 - k * 50), 28, SeasonColor((Season)k));
            UIFactory.Label(legend.transform, names[k], 32, TextAnchor.MiddleLeft, Color.white, new Vector2(0f, 1f), new Vector2(225, -35 - k * 50), new Vector2(330, 48));
        }
        UIFactory.MakeButton(map.transform, "SHOP", new Vector2(1f, 1f), new Vector2(-430, -70), new Vector2(230, 100), UIFactory.Orange, () => OpenShop(ShowMap), 42);
        UIFactory.MakeButton(map.transform, "DAILY", new Vector2(1f, 1f), new Vector2(-170, -70), new Vector2(230, 100), UIFactory.Green, () => OpenDaily(ShowMap), 42);
        UIFactory.MakeButton(map.transform, "BACK", new Vector2(0f, 0f), new Vector2(150, 80), new Vector2(240, 100), UIFactory.Grey, () => ShowMenu(), 42);
    }

    void AreaLabel(Transform parent, string text, Vector2 pos)
    {
        var p = UIFactory.Panel("Area", parent, new Vector2(0.5f, 0.5f), pos, new Vector2(text.Length * 25f + 50f, 58), new Color(0.06f, 0.12f, 0.07f, 0.85f));
        UIFactory.FillLabel(p.transform, text, 34, Color.white).fontStyle = FontStyle.Bold;
    }

    public void ShowMap() => Show(map);

    void RefreshMap()
    {
        int current = 1;
        for (int i = 0; i < LevelDefs.Count; i++)
        {
            int level = i + 1;
            bool open = Economy.LevelUnlocked(level);
            if (open) current = level;
            int stars = Economy.Stars(level);
            var img = nodeButtons[i].GetComponent<Image>();
            img.color = !open ? new Color(0.45f, 0.47f, 0.45f, 1f) : UIFactory.Green;
            for (int k = 0; k < 3; k++)
            {
                nodeStars[i][k].color = k < stars ? Gold : StarOff;
                nodeStars[i][k].gameObject.SetActive(open);
            }
        }
        nodeButtons[current - 1].GetComponent<Image>().color = new Color(0.95f, 0.55f, 0.12f, 1f);
        youPin.anchoredPosition = M(NodeXY[current - 1].x, NodeXY[current - 1].y) + new Vector2(0, 110);
        int total = Economy.TotalStars();
        lockedOverlay.SetActive(total < LevelDefs.LockedAreaStars);
        lockedText.text = "Collect " + LevelDefs.LockedAreaStars + " stars to unlock  (" + total + "/" + LevelDefs.LockedAreaStars + ")";
        RefreshMapWallet();
    }

    void RefreshMapWallet()
    {
        if (!mapMangoes) return;
        mapMangoes.text = Economy.Mangoes.ToString("N0");
        mapGems.text = Economy.Gems.ToString();
        mapStars.text = Economy.TotalStars().ToString();
    }

    void TapLevel(int level)
    {
        if (!Economy.LevelUnlocked(level))
        {
            var def = LevelDefs.Get(level);
            if (Economy.Completed(level - 1) && Economy.TotalStars() < LevelDefs.AreaStarsNeeded(def.area))
                Toast("Collect " + LevelDefs.AreaStarsNeeded(def.area) + " stars to open " + LevelDefs.Areas[def.area].name);
            else
                Toast("Finish level " + (level - 1) + " first");
            return;
        }
        var d = LevelDefs.Get(level);
        string adv = "";
        foreach (var f in d.features) adv += (adv.Length > 0 ? ", " : "") + LevelDefs.FeatureName(f.type);
        OpenModePicker("LEVEL " + level + "  -  " + Seasons.Name(d.season).ToUpper(), race => OnLevel?.Invoke(level, race));
        Toast(adv, 2.5f);
    }

    // ------------------------------------------------------------------ shop
    Transform shopContent;
    int shopTab;
    readonly Button[] shopTabs = new Button[3];
    Text shopMangoes, shopGems;
    Action shopReturn;

    void BuildShop(Transform root)
    {
        shop = UIFactory.Stretch("Shop", root).gameObject;
        var dim = shop.AddComponent<Image>();
        dim.color = new Color(0, 0, 0, 0.55f);
        var p = UIFactory.Panel("Box", shop.transform, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(1760, 980), UIFactory.Dark);
        var t = p.transform;
        UIFactory.Label(t, "SHOP", 84, TextAnchor.MiddleLeft, Color.white, new Vector2(0f, 1f), new Vector2(260, -75), new Vector2(420, 110)).fontStyle = FontStyle.Bold;
        UIFactory.Icon(t, UIFactory.Mango, new Vector2(1f, 1f), new Vector2(-470, -75), 62, Color.white);
        shopMangoes = UIFactory.Label(t, "", 50, TextAnchor.MiddleLeft, Color.white, new Vector2(1f, 1f), new Vector2(-320, -75), new Vector2(230, 80));
        UIFactory.Icon(t, UIFactory.Gem, new Vector2(1f, 1f), new Vector2(-180, -75), 54, Color.white);
        shopGems = UIFactory.Label(t, "", 50, TextAnchor.MiddleLeft, Color.white, new Vector2(1f, 1f), new Vector2(-75, -75), new Vector2(130, 80));
        string[] tabs = { "UPGRADES", "BIKES", "RIDER LOOK" };
        for (int k = 0; k < 3; k++)
        {
            int tab = k;
            shopTabs[k] = UIFactory.MakeButton(t, tabs[k], new Vector2(0f, 1f), new Vector2(170 + k * 300, -185), new Vector2(280, 90), UIFactory.Grey, () => { shopTab = tab; RefreshShop(); }, 38);
        }
        shopContent = UIFactory.MakeRect("Content", t, new Vector2(0.5f, 0.5f), new Vector2(0, -95), new Vector2(1680, 620));
        UIFactory.MakeButton(t, "BACK", new Vector2(0.5f, 0f), new Vector2(0, 70), new Vector2(320, 100), UIFactory.Grey, CloseShop, 42);
    }

    void OpenShop(Action back)
    {
        shopReturn = back;
        Show(shop);
        RefreshShop();
    }

    void CloseShop()
    {
        shop.SetActive(false);
        OnLooksChanged?.Invoke();
        var r = shopReturn;
        shopReturn = null;
        if (r != null) r(); else ShowMenu();
    }

    void RefreshShopWallet()
    {
        if (!shopMangoes) return;
        shopMangoes.text = Economy.Mangoes.ToString("N0");
        shopGems.text = Economy.Gems.ToString();
    }

    void RefreshShop()
    {
        for (int k = 0; k < 3; k++) shopTabs[k].GetComponent<Image>().color = k == shopTab ? UIFactory.Green : UIFactory.Grey;
        for (int c = shopContent.childCount - 1; c >= 0; c--) Destroy(shopContent.GetChild(c).gameObject);
        RefreshShopWallet();
        if (shopTab == 0)
        {
            for (int k = 0; k < 4; k++) UpgradeCard((Upgrade)k, new Vector2(-630 + k * 420, 0));
        }
        else if (shopTab == 1)
        {
            for (int k = 0; k < Economy.Bikes.Length; k++) BikeCard(k, new Vector2((k - 1) * 540, 0));
        }
        else
        {
            for (int k = 0; k < Economy.Looks.Length; k++) LookCard(k, new Vector2(-630 + k * 420, 0));
        }
    }

    Transform Card(Vector2 pos, float width, string title, string sub)
    {
        var card = UIFactory.Panel("Card", shopContent, new Vector2(0.5f, 0.5f), pos, new Vector2(width, 600), new Color(1f, 1f, 1f, 0.07f));
        UIFactory.Label(card.transform, title, 40, TextAnchor.MiddleLeft, Color.white, new Vector2(0f, 1f), new Vector2(width / 2f, -50), new Vector2(width - 40, 60)).fontStyle = FontStyle.Bold;
        UIFactory.Label(card.transform, sub, 28, TextAnchor.UpperLeft, new Color(0.85f, 0.9f, 0.85f), new Vector2(0f, 1f), new Vector2(width / 2f, -120), new Vector2(width - 40, 70));
        return card.transform;
    }

    /// <summary>Orange price button with a mango or gem icon, or a plain label button.</summary>
    void PriceButton(Transform card, int mangoes, int gems, string label, Color color, Action onClick, bool enabled = true)
    {
        string text = label ?? "      " + (mangoes > 0 ? mangoes.ToString("N0") : gems.ToString());
        var b = UIFactory.MakeButton(card, text, new Vector2(0.5f, 0f), new Vector2(0, 70), new Vector2(330, 100), color, onClick, 44);
        b.interactable = enabled;
        if (label == null)
            UIFactory.Icon(b.transform, gems > 0 && mangoes == 0 ? UIFactory.Gem : UIFactory.Mango, new Vector2(0.5f, 0.5f), new Vector2(-70, 0), 52, Color.white);
    }

    void UpgradeCard(Upgrade u, Vector2 pos)
    {
        var card = Card(pos, 390, Economy.UpgradeName(u), Economy.UpgradeText(u));
        int lvl = Economy.Level(u);
        for (int k = 0; k < Economy.MaxUpgrade; k++)
            UIFactory.Panel("Bar", card, new Vector2(0f, 1f), new Vector2(50 + k * 72, -215), new Vector2(64, 30), k < lvl ? UIFactory.Green : new Color(1f, 1f, 1f, 0.12f));
        UIFactory.Label(card, "Level " + lvl + " / " + Economy.MaxUpgrade, 30, TextAnchor.MiddleLeft, new Color(0.85f, 0.9f, 0.85f), new Vector2(0f, 1f), new Vector2(195, -265), new Vector2(350, 50));
        if (lvl >= Economy.MaxUpgrade)
            PriceButton(card, 0, 0, "MAX", UIFactory.Grey, null, false);
        else
        {
            int price = Economy.UpgradePrice(u);
            PriceButton(card, price, 0, null, UIFactory.Orange, () =>
            {
                if (!Economy.BuyUpgrade(u)) Toast("Not enough mangoes");
                else if (GameAudio.I != null) GameAudio.I.Play("trick_ok", 0.5f);
                RefreshShop();
            });
        }
    }

    static string BikeStats(BikeDef b)
    {
        var parts = new List<string>();
        if (b.speedBonus > 0f) parts.Add("Top speed +" + Mathf.RoundToInt(b.speedBonus * 3.6f) + " km/h");
        if (b.gripBonus > 0f) parts.Add("Grip +" + Mathf.RoundToInt(b.gripBonus * 100f) + "%");
        if (b.brakeBonus > 0f) parts.Add("Brakes +" + Mathf.RoundToInt(b.brakeBonus * 100f) + "%");
        return parts.Count == 0 ? "Your first bike" : string.Join("\n", parts.ToArray());
    }

    void Swatch(Transform card, Color main, bool wheel)
    {
        if (wheel)
        {
            UIFactory.Icon(card, UIFactory.Circle, new Vector2(0.5f, 0.5f), new Vector2(0, 10), 200, new Color(0.08f, 0.08f, 0.08f));
            UIFactory.Icon(card, UIFactory.Circle, new Vector2(0.5f, 0.5f), new Vector2(0, 10), 150, main);
            UIFactory.Icon(card, UIFactory.Circle, new Vector2(0.5f, 0.5f), new Vector2(0, 10), 120, new Color(0.12f, 0.14f, 0.12f));
            UIFactory.Icon(card, UIFactory.Circle, new Vector2(0.5f, 0.5f), new Vector2(0, 10), 30, new Color(0.7f, 0.7f, 0.72f));
        }
        else
        {
            UIFactory.Icon(card, UIFactory.Circle, new Vector2(0.5f, 0.5f), new Vector2(0, 10), 170, new Color(0.08f, 0.08f, 0.08f));
            var c = new Color(Mathf.Clamp01(main.r * 0.75f), Mathf.Clamp01(main.g * 0.75f), Mathf.Clamp01(main.b * 0.75f), 1f);
            UIFactory.Icon(card, UIFactory.Circle, new Vector2(0.5f, 0.5f), new Vector2(0, 10), 150, c);
        }
    }

    void BikeCard(int i, Vector2 pos)
    {
        var b = Economy.Bikes[i];
        var card = Card(pos, 500, b.name.ToUpper(), BikeStats(b));
        Swatch(card, b.rim, true);
        bool owned = Economy.OwnsBike(i), selected = owned && Economy.SelectedBike == i;
        if (selected) PriceButton(card, 0, 0, "SELECTED", UIFactory.Grey, null, false);
        else if (owned) PriceButton(card, 0, 0, "SELECT", UIFactory.Green, () => { Economy.BuyOrSelectBike(i); RefreshShop(); });
        else PriceButton(card, b.priceMangoes, b.priceGems, null, UIFactory.Orange, () =>
        {
            if (!Economy.BuyOrSelectBike(i)) Toast(b.priceGems > 0 ? "Not enough gems" : "Not enough mangoes");
            RefreshShop();
        });
    }

    void LookCard(int i, Vector2 pos)
    {
        var l = Economy.Looks[i];
        var card = Card(pos, 390, l.name.ToUpper(), "Rider suit colour");
        Swatch(card, l.tint, false);
        bool owned = Economy.OwnsLook(i), selected = owned && Economy.SelectedLook == i;
        if (selected) PriceButton(card, 0, 0, "WEARING", UIFactory.Grey, null, false);
        else if (owned) PriceButton(card, 0, 0, "WEAR", UIFactory.Green, () => { Economy.BuyOrSelectLook(i); RefreshShop(); });
        else PriceButton(card, l.priceMangoes, l.priceGems, null, UIFactory.Orange, () =>
        {
            if (!Economy.BuyOrSelectLook(i)) Toast(l.priceGems > 0 ? "Not enough gems" : "Not enough mangoes");
            RefreshShop();
        });
    }

    // ------------------------------------------------------------------ daily challenge & 7-day reward
    Text dailyChallenge, dailyReward, dailyProgress, dailyDayTitle;
    RectTransform dailyBar;
    Button challengeClaim, loginClaim;
    readonly Image[] dayCards = new Image[7];
    readonly Image[] dayTicks = new Image[7];
    Action dailyReturn;
    float nextDailyTick;

    void BuildDaily(Transform root)
    {
        daily = UIFactory.Stretch("Daily", root).gameObject;
        var dim = daily.AddComponent<Image>();
        dim.color = new Color(0, 0, 0, 0.55f);
        var p = UIFactory.Panel("Box", daily.transform, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(1500, 960), UIFactory.Dark);
        var t = p.transform;
        UIFactory.Label(t, "TODAY'S CHALLENGE", 72, TextAnchor.MiddleCenter, Color.white, new Vector2(0.5f, 1f), new Vector2(0, -70), new Vector2(1300, 100)).fontStyle = FontStyle.Bold;
        dailyChallenge = UIFactory.Label(t, "", 50, TextAnchor.MiddleCenter, Gold, new Vector2(0.5f, 1f), new Vector2(0, -150), new Vector2(1300, 70));
        dailyReward = UIFactory.Label(t, "", 34, TextAnchor.MiddleCenter, new Color(0.85f, 0.9f, 0.85f), new Vector2(0.5f, 1f), new Vector2(0, -205), new Vector2(1300, 50));
        var barBg = UIFactory.Panel("BarBg", t, new Vector2(0.5f, 1f), new Vector2(-120, -265), new Vector2(900, 30), new Color(1f, 1f, 1f, 0.12f));
        dailyBar = UIFactory.MakeRect("Fill", barBg.transform, new Vector2(0f, 0.5f), Vector2.zero, new Vector2(0, 30));
        dailyBar.pivot = new Vector2(0f, 0.5f);
        var fill = dailyBar.gameObject.AddComponent<Image>();
        fill.sprite = UIFactory.Rounded; fill.type = Image.Type.Sliced; fill.color = UIFactory.Green;
        dailyProgress = UIFactory.Label(t, "", 34, TextAnchor.MiddleCenter, new Color(0.85f, 0.9f, 0.85f), new Vector2(0.5f, 1f), new Vector2(-120, -315), new Vector2(900, 50));
        challengeClaim = UIFactory.MakeButton(t, "      5", new Vector2(0.5f, 1f), new Vector2(530, -290), new Vector2(240, 90), UIFactory.Green, ClaimChallenge, 42);
        UIFactory.Icon(challengeClaim.transform, UIFactory.Gem, new Vector2(0.5f, 0.5f), new Vector2(-50, 0), 46, Color.white);

        dailyDayTitle = UIFactory.Label(t, "", 50, TextAnchor.MiddleCenter, Color.white, new Vector2(0.5f, 1f), new Vector2(0, -420), new Vector2(1300, 70));
        dailyDayTitle.fontStyle = FontStyle.Bold;
        for (int d = 1; d <= 7; d++)
        {
            var card = UIFactory.Panel("Day" + d, t, new Vector2(0.5f, 1f), new Vector2((d - 4) * 172f, -575), new Vector2(158, 190), new Color(1f, 1f, 1f, 0.08f));
            dayCards[d - 1] = card;
            UIFactory.Label(card.transform, "Day " + d, 34, TextAnchor.MiddleCenter, Color.white, new Vector2(0.5f, 1f), new Vector2(0, -30), new Vector2(150, 50)).fontStyle = FontStyle.Bold;
            bool gemDay = Economy.LoginRewardGems(d) > 0;
            UIFactory.Icon(card.transform, gemDay ? UIFactory.Gem : UIFactory.Mango, new Vector2(0.5f, 0.5f), new Vector2(0, 5), 56, Color.white);
            UIFactory.Label(card.transform, gemDay ? Economy.LoginRewardGems(d).ToString() : Economy.LoginRewardMangoes(d).ToString(), 34, TextAnchor.MiddleCenter, Color.white, new Vector2(0.5f, 0f), new Vector2(0, 52), new Vector2(150, 46));
            dayTicks[d - 1] = UIFactory.Icon(card.transform, UIFactory.Tick, new Vector2(0.5f, 0f), new Vector2(0, 18), 30, OkGreen);
        }
        loginClaim = UIFactory.MakeButton(t, "CLAIM", new Vector2(0.5f, 0f), new Vector2(0, 95), new Vector2(340, 110), UIFactory.Green, ClaimLogin, 50);
        UIFactory.MakeButton(t, "X", new Vector2(1f, 1f), new Vector2(-70, -70), new Vector2(90, 90), UIFactory.Grey, CloseDaily, 46);
    }

    void OpenDaily(Action back)
    {
        dailyReturn = back;
        daily.SetActive(true);
        daily.transform.SetAsLastSibling();
        RefreshDaily();
    }

    void CloseDaily()
    {
        daily.SetActive(false);
        var r = dailyReturn;
        dailyReturn = null;
        if (r != null) r();
        else RefreshWallets();
    }

    void ClaimChallenge()
    {
        if (Economy.ClaimChallenge())
        {
            Toast("+" + Economy.ChallengeRewardGems + " gems!");
            if (GameAudio.I != null) GameAudio.I.Play("pickup_gem", 0.6f);
        }
        RefreshDaily();
    }

    void ClaimLogin()
    {
        int d = Economy.LoginDay;
        if (Economy.ClaimLogin())
        {
            Toast(Economy.LoginRewardGems(d) > 0 ? "+" + Economy.LoginRewardGems(d) + " gems!" : "+" + Economy.LoginRewardMangoes(d) + " mangoes!");
            if (GameAudio.I != null) GameAudio.I.Play(Economy.LoginRewardGems(d) > 0 ? "pickup_gem" : "pickup_mango", 0.6f);
        }
        RefreshDaily();
    }

    void RefreshDaily()
    {
        var c = Economy.TodayChallenge;
        int goal = Economy.ChallengeGoal(c), prog = Mathf.Min(goal, Economy.ChallengeProgress);
        dailyChallenge.text = Economy.ChallengeText(c);
        dailyBar.sizeDelta = new Vector2(900f * prog / Mathf.Max(1, goal), 30);
        dailyProgress.text = (c == Economy.ChallengeType.Distance ? prog + " / " + goal + " m" : prog + " / " + goal) + (Economy.ChallengeClaimed ? "   - reward claimed" : " done");
        challengeClaim.gameObject.SetActive(Economy.ChallengeDone && !Economy.ChallengeClaimed);
        UpdateDailyClock();

        int day = Economy.LoginDay;
        bool claimed = Economy.LoginClaimed;
        dailyDayTitle.text = "DAILY REWARD  -  DAY " + day;
        for (int d = 1; d <= 7; d++)
        {
            bool done = d < day || (d == day && claimed);
            dayCards[d - 1].color = d == day && !claimed ? new Color(0.95f, 0.55f, 0.12f, 1f) : done ? new Color(0.22f, 0.45f, 0.22f, 0.95f) : new Color(1f, 1f, 1f, 0.08f);
            dayTicks[d - 1].enabled = done;
        }
        loginClaim.interactable = !claimed;
        UIFactory.SetButtonText(loginClaim, claimed ? "COME BACK TOMORROW" : "CLAIM");
        ((RectTransform)loginClaim.transform).sizeDelta = new Vector2(claimed ? 640 : 340, 110);
        RefreshWallets();
    }

    void UpdateDailyClock()
    {
        var left = DateTime.Today.AddDays(1) - DateTime.Now;
        dailyReward.text = "Reward: " + Economy.ChallengeRewardGems + " gems   -   resets in " + string.Format("{0:00}:{1:00}:{2:00}", (int)left.TotalHours, left.Minutes, left.Seconds);
    }

    void UpdateDaily()
    {
        if (daily == null || !daily.activeSelf || Time.unscaledTime < nextDailyTick) return;
        nextDailyTick = Time.unscaledTime + 1f;
        UpdateDailyClock();
    }
}
