using UnityEngine;
using UnityEngine.EventSystems;

/// <summary>Simple virtual joystick. Value is -1..1 on both axes.</summary>
public class VirtualJoystick : MonoBehaviour, IPointerDownHandler, IDragHandler, IPointerUpHandler
{
    public RectTransform knob;
    public Vector2 Value { get; private set; }
    RectTransform area;

    void Awake() => area = (RectTransform)transform;

    void OnDisable()
    {
        Value = Vector2.zero;
        if (knob) knob.anchoredPosition = Vector2.zero;
    }

    public void OnPointerDown(PointerEventData e) => OnDrag(e);

    public void OnDrag(PointerEventData e)
    {
        if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(area, e.position, e.pressEventCamera, out var local)) return;
        float radius = area.rect.width * 0.5f;
        Vector2 v = Vector2.ClampMagnitude(local / radius, 1f);
        Value = v;
        if (knob) knob.anchoredPosition = v * radius * 0.6f;
    }

    public void OnPointerUp(PointerEventData e)
    {
        Value = Vector2.zero;
        if (knob) knob.anchoredPosition = Vector2.zero;
    }
}
