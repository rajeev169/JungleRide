using System.Collections.Generic;
using UnityEngine;

public enum GameMode { TrailRace, Endless, Levels }

/// <summary>Describes one trail: how long, how twisty, how hilly, how many obstacles, and its adventures.</summary>
[System.Serializable]
public class TrackConfig
{
    public string title;
    public int seed;
    public bool endless;
    public float length = 1000f;          // metres (ignored when endless; a mountain adds its own length)
    public float curviness = 0.5f;        // 0..1
    public float hilliness = 0.5f;        // 0..1
    public float obstacles = 0.4f;        // 0..1 logs & rocks on the trail
    public float ramps = 0.3f;            // 0..1
    public float checkpointEvery = 250f;  // metres
    public int level;                     // 1..15 for levels, 0 otherwise
    public List<FeatureSpec> features = new List<FeatureSpec>();

    public const int LevelCount = LevelDefs.Count;

    public static TrackConfig TrailRace() => new TrackConfig
    {
        title = "Trail Race", seed = 7341, length = 1200f,
        curviness = 0.55f, hilliness = 0.55f, obstacles = 0.45f, ramps = 0.4f, checkpointEvery = 300f,
        features = LevelDefs.TrailRaceFeatures(),
    };

    /// <summary>Endless mode: adventures are added by the trail itself as you ride.</summary>
    public static TrackConfig Endless() => new TrackConfig
    {
        title = "Endless Ride", seed = Random.Range(1, 99999), endless = true,
        curviness = 0.3f, hilliness = 0.3f, obstacles = 0.2f, ramps = 0.25f, checkpointEvery = 400f
    };

    /// <summary>Levels 1..15 get longer and harder.</summary>
    public static TrackConfig Level(int level)
    {
        var def = LevelDefs.Get(level);
        float t = (level - 1) / (float)(LevelCount - 1);
        return new TrackConfig
        {
            title = "Level " + level,
            level = level,
            seed = 500 + level * 97,
            length = def.length,
            curviness = Mathf.Lerp(0.25f, 0.8f, t),
            hilliness = Mathf.Lerp(0.25f, 0.85f, t),
            obstacles = Mathf.Lerp(0.15f, 0.7f, t),
            ramps = Mathf.Lerp(0.25f, 0.6f, t),
            checkpointEvery = Mathf.Lerp(150f, 250f, t),
            features = new List<FeatureSpec>(def.features),
        };
    }

    /// <summary>Endless mode gets harder the further you ride. Returns 0..1.</summary>
    public float DifficultyAt(float metres)
    {
        return endless ? Mathf.Clamp01(metres / 3000f) : 0f;
    }
}
