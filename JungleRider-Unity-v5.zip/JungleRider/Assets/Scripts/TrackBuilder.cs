using System.Collections.Generic;
using UnityEngine;
#if UNITY_6000_0_OR_NEWER
using PhysMat = UnityEngine.PhysicsMaterial;
#else
using PhysMat = UnityEngine.PhysicMaterial;
#endif

/// <summary>
/// Builds the jungle around the trail in 48 m chunks: ground mesh (with collider), trees, bushes,
/// rocks, logs, ramps and gates. Chunks ahead of the bike are created, chunks behind are removed.
/// </summary>
public class TrackBuilder : MonoBehaviour
{
    public const int SegsPerChunk = 12;
    const int ChunksBehind = 1;
    const int ChunksAhead = 5;

    TrailPath path;
    readonly Dictionary<int, GameObject> chunks = new Dictionary<int, GameObject>();
    readonly HashSet<int> checkpointIndices = new HashSet<int>();
    readonly List<PickupSpot> spots = new List<PickupSpot>();
    PhysMat groundMat;
    GameObject mountain;

    /// <summary>Mangoes and gems already collected on this run (so they don't come back after a respawn).</summary>
    public readonly HashSet<int> picked = new HashSet<int>();

    public void Init(TrailPath trailPath, IEnumerable<int> checkpoints)
    {
        Clear();
        path = trailPath;
        checkpointIndices.Clear();
        foreach (var c in checkpoints) checkpointIndices.Add(c);
        groundMat = new PhysMat("Ground") { dynamicFriction = 0.6f, staticFriction = 0.6f };
        picked.Clear();
        if (path.HasSpiral) BuildMountain();
        UpdateAround(TrailPath.StartIndex);
    }

    public void Clear()
    {
        foreach (var kv in chunks) if (kv.Value) Destroy(kv.Value);
        chunks.Clear();
        if (mountain) Destroy(mountain);
        mountain = null;
    }

    /// <summary>The whole mountain road (3 rounds) as one piece, so the rounds above and below are always there.</summary>
    void BuildMountain()
    {
        int s0 = path.SpiralZone.start, s1 = path.FinishIndex + SegsPerChunk + 2;
        int cols = TrailPath.Offsets.Length, rows = s1 - s0 + 1;
        var verts = new Vector3[rows * cols];
        var colors = new Color[rows * cols];
        Seasons.GroundPalette(out Color dirtA, out Color dirtB, out Color edge, out Color grassA, out Color grassB, out Color deep);
        Color rockA = new Color(0.46f, 0.43f, 0.38f), rockB = new Color(0.36f, 0.34f, 0.3f);
        for (int r = 0; r < rows; r++)
        {
            int i = s0 + r;
            for (int c = 0; c < cols; c++)
            {
                float x = TrailPath.Offsets[c];
                Vector3 p = path.Surface(i, x);
                float rel = p.y - path.Point(i).y;
                verts[r * cols + c] = p;
                float n = Mathf.PerlinNoise(p.x * 0.15f + 20f, p.z * 0.15f + 20f);
                Color col;
                if (Mathf.Abs(x) <= 1.6f) col = Color.Lerp(dirtA, dirtB, n);
                else if (Mathf.Abs(x) <= 3.5f) col = Color.Lerp(Color.Lerp(dirtA, dirtB, n), edge, 0.5f);
                else if (Mathf.Abs(rel) > 1.5f) col = Color.Lerp(rockA, rockB, n) * (0.9f + 0.2f * Mathf.PerlinNoise(p.y * 0.4f, p.x * 0.3f));
                else col = Color.Lerp(grassA, grassB, n);
                col.a = 1f;
                colors[r * cols + c] = col;
            }
        }
        var tris = new List<int>();
        for (int r = 0; r < rows - 1; r++)
            for (int c = 0; c < cols - 1; c++)
            {
                int a = r * cols + c, b = (r + 1) * cols + c, cc = (r + 1) * cols + c + 1, d = r * cols + c + 1;
                tris.Add(a); tris.Add(b); tris.Add(cc);
                tris.Add(a); tris.Add(cc); tris.Add(d);
            }
        var mesh = new Mesh { name = "Mountain" };
        mesh.vertices = verts;
        mesh.colors = colors;
        mesh.SetTriangles(tris, 0);
        mesh.RecalculateNormals();
        mesh.RecalculateBounds();
        mountain = new GameObject("Mountain");
        mountain.transform.SetParent(transform, false);
        mountain.AddComponent<MeshFilter>().sharedMesh = mesh;
        var mr = mountain.AddComponent<MeshRenderer>();
        mr.sharedMaterial = JungleProps.Material;
        mr.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.On;
        var mc = mountain.AddComponent<MeshCollider>();
        mc.sharedMesh = mesh;
        mc.sharedMaterial = groundMat;
    }

    int LastChunk => path.Config.endless ? int.MaxValue : (path.FinishIndex + SegsPerChunk) / SegsPerChunk;

    public void UpdateAround(int pathIndex)
    {
        if (path == null) return;
        int c = pathIndex / SegsPerChunk;
        int from = Mathf.Max(0, c - ChunksBehind);
        int to = Mathf.Min(LastChunk, c + ChunksAhead);

        var remove = new List<int>();
        foreach (var kv in chunks) if (kv.Key < from || kv.Key > to) remove.Add(kv.Key);
        foreach (int k in remove) { Destroy(chunks[k]); chunks.Remove(k); }

        for (int k = from; k <= to; k++)
            if (!chunks.ContainsKey(k)) chunks[k] = BuildChunk(k);
    }

    GameObject BuildChunk(int chunk)
    {
        int i0 = chunk * SegsPerChunk, i1 = i0 + SegsPerChunk;
        var root = new GameObject("Chunk " + chunk);
        root.transform.SetParent(transform, false);

        // ---------- ground mesh (the mountain road has its own) ----------
        int cols = TrailPath.Offsets.Length;
        int rows = SegsPerChunk + 1;
        if (path.HasSpiral) rows = Mathf.Min(rows, path.SpiralZone.start - i0 + 1);
        if (rows >= 2)
        {
        var verts = new Vector3[rows * cols];
        var colors = new Color[rows * cols];
        for (int r = 0; r < rows; r++)
        {
            int i = i0 + r;
            for (int c = 0; c < cols; c++)
            {
                float x = TrailPath.Offsets[c];
                Vector3 p = path.Surface(i, x);
                if (Mathf.Abs(x) <= TrailPath.TrailHalfWidth)
                {
                    // gentle bumps on the dirt
                    p.y += (Mathf.PerlinNoise(p.x * 0.6f, p.z * 0.6f) - 0.5f) * 0.06f;
                }
                verts[r * cols + c] = p;
                colors[r * cols + c] = GroundColor(x, p);
            }
        }
        var tris = new List<int>();
        for (int r = 0; r < rows - 1; r++)
            for (int c = 0; c < cols - 1; c++)
            {
                int a = r * cols + c, b = (r + 1) * cols + c, cc = (r + 1) * cols + c + 1, d = r * cols + c + 1;
                tris.Add(a); tris.Add(b); tris.Add(cc);
                tris.Add(a); tris.Add(cc); tris.Add(d);
            }
        var mesh = new Mesh { name = "Ground " + chunk };
        mesh.vertices = verts;
        mesh.colors = colors;
        mesh.SetTriangles(tris, 0);
        mesh.RecalculateNormals();
        mesh.RecalculateBounds();

        var ground = new GameObject("Ground");
        ground.transform.SetParent(root.transform, false);
        ground.layer = 0;
        ground.AddComponent<MeshFilter>().sharedMesh = mesh;
        var mr = ground.AddComponent<MeshRenderer>();
        mr.sharedMaterial = JungleProps.Material;
        mr.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
        var mc = ground.AddComponent<MeshCollider>();
        mc.sharedMesh = mesh;
        mc.sharedMaterial = groundMat;
        }

        // ---------- adventures in this chunk ----------
        path.ZoneAt(i1 + 20);
        for (int k = 0, n = path.Zones.Count; k < n; k++)
        {
            var z = path.Zones[k];
            int anchor = Adventures.Anchor(z);
            if (anchor >= i0 && anchor < i1) Adventures.Build(z, path, root.transform);
        }

        // ---------- mangoes & gems ----------
        spots.Clear();
        path.PickupsIn(i0, i1, spots);
        foreach (var sp in spots)
            if (!picked.Contains(sp.id)) Collectible.Spawn(sp, path.PickupPosition(sp), root.transform);

        // ---------- props ----------
        var rnd = new System.Random(path.Config.seed * 7919 + chunk * 104729);
        var cfg = path.Config;
        int lastBlock = -100;
        for (int i = i0; i < i1; i++)
        {
            Vector3 fwd = path.Forward(i);
            float metres = i * TrailPath.SegLen;
            float diff = cfg.DifficultyAt(metres);
            var zone = path.ZoneAt(i);
            bool spiral = path.InSpiral(i);
            bool firstRound = spiral && (path.SpiralRoundStarts.Count == 0 || i < path.SpiralRoundStarts[0]);
            bool wet = zone != null && (zone.IsGorge || zone.type == FeatureType.River) && i >= zone.gapStart - 1 && i <= zone.gapEnd + 1;
            if (spiral) Adventures.SpiralEdge(path, i, root.transform, rnd);

            for (int side = -1; side <= 1; side += 2)
            {
                bool noTrees = spiral && !(firstRound && side < 0);
                bool noSmall = spiral || wet || (zone != null && zone.type == FeatureType.Temple);
                if (noTrees) { rnd.NextDouble(); }
                else if (rnd.NextDouble() < 0.6)
                {
                    float x = side * Range(rnd, spiral ? 14f : 9f, 30f);
                    double k = rnd.NextDouble();
                    var kind = k < 0.4 ? JungleProps.Kind.Palm : k < 0.8 ? JungleProps.Kind.Broadleaf : JungleProps.Kind.Giant;
                    var tree = JungleProps.Spawn(kind, rnd.Next(3), root.transform, path.Surface(i, x) + Vector3.down * 0.3f,
                        Quaternion.Euler(0, Range(rnd, 0, 360), 0), Range(rnd, 0.8f, 1.3f));
                    if (Mathf.Abs(x) < 16f)
                    {
                        var cap = tree.AddComponent<CapsuleCollider>();
                        cap.radius = kind == JungleProps.Kind.Giant ? 0.8f : 0.35f;
                        cap.height = 6f;
                        cap.center = new Vector3(0, 3f, 0);
                    }
                }
                if (noSmall) continue;
                if (rnd.NextDouble() < 0.5)
                    JungleProps.Spawn(JungleProps.Kind.Bush, rnd.Next(3), root.transform, path.Surface(i, side * Range(rnd, 6f, 13f)),
                        Quaternion.Euler(0, Range(rnd, 0, 360), 0), Range(rnd, 0.8f, 1.5f));
                if (rnd.NextDouble() < 0.4)
                    JungleProps.Spawn(JungleProps.Kind.Fern, rnd.Next(3), root.transform, path.Surface(i, side * Range(rnd, 4f, 7f)),
                        Quaternion.Euler(0, Range(rnd, 0, 360), 0), Range(rnd, 0.8f, 1.3f));
                if (rnd.NextDouble() < 0.12)
                {
                    var rock = JungleProps.Spawn(JungleProps.Kind.Rock, rnd.Next(3), root.transform, path.Surface(i, side * Range(rnd, 4.5f, 9f)),
                        Quaternion.Euler(0, Range(rnd, 0, 360), 0), Range(rnd, 0.7f, 1.6f));
                    var sc = rock.AddComponent<SphereCollider>();
                    sc.center = new Vector3(0, 0.25f, 0);
                    sc.radius = 0.6f;
                }
            }

            // ---------- gates ----------
            bool isCheckpoint = checkpointIndices.Contains(i);
            bool isFinish = !cfg.endless && i == path.FinishIndex;
            if (isCheckpoint || isFinish || i == TrailPath.StartIndex + 2)
            {
                var gate = JungleProps.Spawn(isFinish ? JungleProps.Kind.FinishGate : JungleProps.Kind.CheckpointGate, 0,
                    root.transform, path.Point(i), Quaternion.LookRotation(fwd), 1f);
                AddBox(gate, new Vector3(-4.6f, 2.2f, 0), new Vector3(0.35f, 4.4f, 0.35f));
                AddBox(gate, new Vector3(4.6f, 2.2f, 0), new Vector3(0.35f, 4.4f, 0.35f));
                lastBlock = i;
                continue;
            }

            // ---------- puddles (monsoon) ----------
            bool nearZone = spiral || zone != null || path.ZoneAt(i + 3) != null || path.ZoneAt(i - 2) != null;
            if (nearZone) continue;
            if (Seasons.Current == Season.Monsoon && i > TrailPath.StartIndex + 4 && rnd.NextDouble() < 0.14)
            {
                float px = Range(rnd, -2.2f, 2.2f);
                var puddle = JungleProps.Spawn(JungleProps.Kind.Puddle, rnd.Next(3), root.transform, path.Surface(i, px) + Vector3.up * 0.05f,
                    Quaternion.LookRotation((path.Point(i + 1) - path.Point(i)).normalized) * Quaternion.Euler(0, Range(rnd, -30f, 30f), 0), Range(rnd, 0.8f, 1.5f));
                puddle.GetComponent<MeshRenderer>().shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            }

            // ---------- obstacles on the trail ----------
            bool nearSpecial = i < TrailPath.StartIndex + 10 || (!cfg.endless && i > path.FinishIndex - 6) || NearCheckpoint(i, 5);
            if (nearSpecial || i - lastBlock < 4) continue;

            float obst = Mathf.Clamp01(cfg.obstacles + diff * 0.5f);
            float ramps = Mathf.Clamp01(cfg.ramps + diff * 0.3f);
            double roll = rnd.NextDouble();
            if (roll < obst * 0.07)
            {
                // fallen log across the trail
                var log = JungleProps.Spawn(JungleProps.Kind.Log, rnd.Next(3), root.transform,
                    path.Point(i) + path.Right(i) * Range(rnd, -0.8f, 0.8f) + Vector3.up * 0.1f,
                    Quaternion.LookRotation(fwd) * Quaternion.Euler(0, Range(rnd, -12f, 12f), 0), 1f);
                var cap = log.AddComponent<CapsuleCollider>();
                cap.direction = 0; // X axis
                cap.radius = 0.22f;
                cap.height = 5f;
                lastBlock = i;
            }
            else if (roll < obst * 0.07 + obst * 0.05)
            {
                // small rock on the trail
                float x = (rnd.NextDouble() < 0.5 ? -1f : 1f) * Range(rnd, 1f, 2.6f);
                var rock = JungleProps.Spawn(JungleProps.Kind.Rock, rnd.Next(3), root.transform, path.Surface(i, x) + Vector3.down * 0.1f,
                    Quaternion.Euler(0, Range(rnd, 0, 360), 0), Range(rnd, 0.4f, 0.65f));
                var sc = rock.AddComponent<SphereCollider>();
                sc.center = new Vector3(0, 0.25f, 0);
                sc.radius = 0.55f;
                lastBlock = i;
            }
            else if (roll < obst * 0.12 + ramps * 0.04)
            {
                // jump ramp, follows the slope of the trail
                Vector3 p0 = path.Point(i), p1 = path.Point(i + 1);
                Vector3 dir = (p1 - p0).normalized;
                var ramp = JungleProps.Spawn(JungleProps.Kind.Ramp, 0, root.transform,
                    p0 + path.Right(i) * Range(rnd, -0.9f, 0.9f) - Vector3.up * 0.05f, Quaternion.LookRotation(dir, Vector3.up), 1f);
                var rc = ramp.AddComponent<MeshCollider>();
                rc.sharedMesh = JungleProps.Get(JungleProps.Kind.Ramp, 0);
                rc.convex = true;
                lastBlock = i + 2;
            }
        }
        return root;
    }

    bool NearCheckpoint(int i, int range)
    {
        for (int k = -range; k <= range; k++) if (checkpointIndices.Contains(i + k)) return true;
        return false;
    }

    static void AddBox(GameObject go, Vector3 center, Vector3 size)
    {
        var b = go.AddComponent<BoxCollider>();
        b.center = center;
        b.size = size;
    }

    static float Range(System.Random r, float a, float b) => a + (float)r.NextDouble() * (b - a);

    static Color GroundColor(float x, Vector3 p)
    {
        Seasons.GroundPalette(out Color dirtA, out Color dirtB, out Color edge, out Color grassA, out Color grassB, out Color deep);
        float ax = Mathf.Abs(x);
        float n = Mathf.PerlinNoise(p.x * 0.15f + 20f, p.z * 0.15f + 20f);
        Color dirt = Color.Lerp(dirtA, dirtB, n);
        Color grass = Color.Lerp(grassA, grassB, n);
        if (ax <= 1.6f) return dirt;
        if (ax <= 3.5f) return Color.Lerp(dirt, edge, 0.5f);
        if (ax <= 6.5f) return Color.Lerp(edge, grass, 0.6f);
        if (ax <= 20.5f) return grass;
        return Color.Lerp(grass, deep, 0.6f);
    }
}
