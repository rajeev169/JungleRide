using UnityEngine;

public enum Season { Summer, Monsoon, Winter }

/// <summary>How each season looks, rides and sounds.</summary>
public class SeasonLook
{
    public string name;
    public Color fogColor;
    public float fogDensity;
    public Color sunColor;
    public float sunIntensity;
    public Vector3 sunEuler;
    public Color ambientSky, ambientEquator, ambientGround;
    public Color propTint;          // tints trees, bushes and ground
    public float grip = 1f;         // sideways grip
    public float brake = 1f;        // braking strength
    public float accel = 1f;        // pedalling strength
    public float ambientVolume = 1f;
    public float ambientCutoff = 22000f;
    public bool rain;
}

public static class Seasons
{
    public static Season Current { get; private set; } = Season.Summer;

    public static string Name(Season s) => s == Season.Summer ? "Summer" : s == Season.Monsoon ? "Monsoon" : "Winter";

    /// <summary>Fixed season for each level: 1-2 summer, 3-4 monsoon, 5 winter fog.</summary>
    public static Season ForLevel(int level) => level <= 2 ? Season.Summer : level <= 4 ? Season.Monsoon : Season.Winter;

    /// <summary>Season of today's date in India: Mar-Jun summer, Jul-Oct monsoon, Nov-Feb winter.</summary>
    public static Season Today()
    {
        int m = System.DateTime.Now.Month;
        if (m >= 3 && m <= 6) return Season.Summer;
        if (m >= 7 && m <= 10) return Season.Monsoon;
        return Season.Winter;
    }

    public static Season Random() => (Season)UnityEngine.Random.Range(0, 3);

    public static SeasonLook Get(Season s)
    {
        switch (s)
        {
            case Season.Monsoon:
                return new SeasonLook
                {
                    name = "Monsoon",
                    fogColor = new Color(0.46f, 0.52f, 0.5f), fogDensity = 0.02f,
                    sunColor = new Color(0.8f, 0.86f, 0.92f), sunIntensity = 0.6f, sunEuler = new Vector3(60f, -35f, 0f),
                    ambientSky = new Color(0.45f, 0.52f, 0.52f), ambientEquator = new Color(0.32f, 0.38f, 0.33f), ambientGround = new Color(0.14f, 0.16f, 0.13f),
                    propTint = new Color(0.82f, 0.95f, 0.84f),
                    grip = 0.55f, brake = 0.6f, accel = 0.9f,
                    ambientVolume = 0.6f, rain = true,
                };
            case Season.Winter:
                return new SeasonLook
                {
                    name = "Winter",
                    fogColor = new Color(0.8f, 0.83f, 0.86f), fogDensity = 0.032f,
                    sunColor = new Color(0.92f, 0.94f, 1f), sunIntensity = 0.75f, sunEuler = new Vector3(22f, -40f, 0f),
                    ambientSky = new Color(0.7f, 0.74f, 0.8f), ambientEquator = new Color(0.48f, 0.52f, 0.52f), ambientGround = new Color(0.22f, 0.24f, 0.22f),
                    propTint = new Color(0.88f, 0.93f, 0.95f),
                    grip = 1f, brake = 1f, accel = 1f,
                    ambientVolume = 0.65f, ambientCutoff = 900f,
                };
            default:
                return new SeasonLook
                {
                    name = "Summer",
                    fogColor = new Color(0.8f, 0.8f, 0.64f), fogDensity = 0.008f,
                    sunColor = new Color(1f, 0.93f, 0.78f), sunIntensity = 1.3f, sunEuler = new Vector3(55f, -30f, 0f),
                    ambientSky = new Color(0.72f, 0.74f, 0.6f), ambientEquator = new Color(0.5f, 0.52f, 0.36f), ambientGround = new Color(0.25f, 0.23f, 0.15f),
                    propTint = new Color(1.06f, 1.02f, 0.86f),
                    grip = 1.1f, brake = 1.05f, accel = 1.05f,
                    ambientVolume = 1f,
                };
        }
    }

    /// <summary>Applies the season's light, fog and colours to the world.</summary>
    public static SeasonLook Apply(Season s, Camera cam, Light sun)
    {
        Current = s;
        var look = Get(s);
        RenderSettings.fog = true;
        RenderSettings.fogMode = FogMode.Exponential;
        RenderSettings.fogColor = look.fogColor;
        RenderSettings.fogDensity = look.fogDensity;
        RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Trilight;
        RenderSettings.ambientSkyColor = look.ambientSky;
        RenderSettings.ambientEquatorColor = look.ambientEquator;
        RenderSettings.ambientGroundColor = look.ambientGround;
        if (cam) cam.backgroundColor = look.fogColor;
        if (sun)
        {
            sun.color = look.sunColor;
            sun.intensity = look.sunIntensity;
            sun.transform.rotation = Quaternion.Euler(look.sunEuler);
            sun.shadowStrength = s == Season.Summer ? 0.75f : 0.45f;
        }
        JungleProps.Material.SetColor("_Color", look.propTint);
        return look;
    }

    /// <summary>Ground colour of the trail and banks for the current season.</summary>
    public static void GroundPalette(out Color dirtA, out Color dirtB, out Color edge, out Color grassA, out Color grassB, out Color deep)
    {
        switch (Current)
        {
            case Season.Monsoon:
                dirtA = new Color(0.27f, 0.19f, 0.12f); dirtB = new Color(0.33f, 0.24f, 0.15f); edge = new Color(0.25f, 0.24f, 0.13f);
                grassA = new Color(0.1f, 0.34f, 0.1f); grassB = new Color(0.16f, 0.43f, 0.12f); deep = new Color(0.06f, 0.22f, 0.07f);
                break;
            case Season.Winter:
                dirtA = new Color(0.4f, 0.33f, 0.25f); dirtB = new Color(0.47f, 0.4f, 0.31f); edge = new Color(0.38f, 0.37f, 0.28f);
                grassA = new Color(0.2f, 0.34f, 0.17f); grassB = new Color(0.28f, 0.42f, 0.22f); deep = new Color(0.13f, 0.24f, 0.13f);
                break;
            default:
                dirtA = new Color(0.52f, 0.39f, 0.24f); dirtB = new Color(0.6f, 0.46f, 0.29f); edge = new Color(0.45f, 0.4f, 0.22f);
                grassA = new Color(0.27f, 0.45f, 0.13f); grassB = new Color(0.4f, 0.53f, 0.17f); deep = new Color(0.17f, 0.33f, 0.1f);
                break;
        }
    }
}
