using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Builds the adventures on the trail: wooden bridge over a gorge, rope bridge, river crossing, monkeys,
/// temple ruins with a hidden gem, the waterfall jump, and the stone edge on the mountain road.
/// Called by TrackBuilder for the chunk that holds each adventure.
/// </summary>
public static class Adventures
{
    static readonly Color Wood = new Color(0.55f, 0.38f, 0.2f);
    static readonly Color DarkWood = new Color(0.36f, 0.24f, 0.13f);
    static readonly Color StoneC = new Color(0.58f, 0.56f, 0.5f);
    static readonly Color Moss = new Color(0.36f, 0.48f, 0.26f);

    static Material waterMat, fallMat;
    static Texture2D waterTex, fallTex;

    public static void Build(Zone z, TrailPath path, Transform parent)
    {
        switch (z.type)
        {
            case FeatureType.WoodBridge: WoodBridge(z, path, parent); break;
            case FeatureType.RopeBridge: RopeBridge.Create(z, path, parent); break;
            case FeatureType.River: River(z, path, parent); break;
            case FeatureType.Monkeys: MonkeyTroop.Create(z, path, parent); break;
            case FeatureType.Temple: Temple(z, path, parent); break;
            case FeatureType.Waterfall: Waterfall(z, path, parent); break;
        }
    }

    /// <summary>The path index whose chunk builds this adventure.</summary>
    public static int Anchor(Zone z) => z.type == FeatureType.Spiral ? -1 : z.gapStart;

    // ------------------------------------------------------------------ helpers
    public static GameObject MeshObject(string name, Transform parent, Mesh mesh, Material mat, Vector3 pos, Quaternion rot, bool shadows = true)
    {
        var go = new GameObject(name);
        go.transform.SetParent(parent, false);
        go.transform.SetPositionAndRotation(pos, rot);
        go.AddComponent<MeshFilter>().sharedMesh = mesh;
        var r = go.AddComponent<MeshRenderer>();
        r.sharedMaterial = mat;
        r.shadowCastingMode = shadows ? UnityEngine.Rendering.ShadowCastingMode.On : UnityEngine.Rendering.ShadowCastingMode.Off;
        return go;
    }

    public static void AddBox(GameObject go, Vector3 center, Vector3 size)
    {
        var b = go.AddComponent<BoxCollider>();
        b.center = center;
        b.size = size;
    }

    static Color Vary(Color c, System.Random r, float k = 0.12f)
    {
        float f = 1f + ((float)r.NextDouble() - 0.5f) * 2f * k;
        return new Color(c.r * f, c.g * f, c.b * f, 1f);
    }

    static Texture2D MakeTex(bool fall)
    {
        const int W = 64, H = 128;
        var t = new Texture2D(W, H, TextureFormat.RGBA32, true) { wrapMode = TextureWrapMode.Repeat, filterMode = FilterMode.Bilinear };
        var px = new Color[W * H];
        for (int y = 0; y < H; y++)
            for (int x = 0; x < W; x++)
            {
                float u = x / (float)W, v = y / (float)H;
                Color c;
                if (fall)
                {
                    float streak = Mathf.PerlinNoise(u * 18f, v * 2.5f);
                    float foam = Mathf.PerlinNoise(u * 40f + 7f, v * 6f);
                    c = Color.Lerp(new Color(0.55f, 0.72f, 0.8f), new Color(0.95f, 0.98f, 1f), Mathf.Clamp01(streak * 1.3f - 0.2f + foam * 0.3f));
                }
                else
                {
                    float n = Mathf.PerlinNoise(u * 6f, v * 3f) * 0.6f + Mathf.PerlinNoise(u * 20f + 3f, v * 9f) * 0.4f;
                    c = Color.Lerp(new Color(0.16f, 0.36f, 0.42f), new Color(0.42f, 0.62f, 0.66f), Mathf.Clamp01((n - 0.35f) * 2.2f));
                    if (n > 0.72f) c = Color.Lerp(c, Color.white, (n - 0.72f) * 2.5f);
                }
                px[y * W + x] = c;
            }
        t.SetPixels(px);
        t.Apply();
        return t;
    }

    static Material TexMat(Texture2D tex, string name)
    {
        var shader = Shader.Find("JungleRider/TexturedLit");
        if (shader == null) shader = Shader.Find("Standard");
        return new Material(shader) { name = name, mainTexture = tex };
    }

    public static Material WaterMat
    {
        get
        {
            if (waterMat == null) { waterTex = MakeTex(false); waterMat = TexMat(waterTex, "Water"); }
            return waterMat;
        }
    }

    public static Material FallMat
    {
        get
        {
            if (fallMat == null) { fallTex = MakeTex(true); fallMat = TexMat(fallTex, "Waterfall"); }
            return fallMat;
        }
    }

    /// <summary>Flat textured quad (local X = width, local Z = length), facing up.</summary>
    static Mesh WaterQuad(float width, float length, float uvScale)
    {
        var m = new Mesh { name = "WaterQuad" };
        float w = width * 0.5f, l = length * 0.5f;
        m.vertices = new[] { new Vector3(-w, 0, -l), new Vector3(-w, 0, l), new Vector3(w, 0, l), new Vector3(w, 0, -l) };
        m.uv = new[] { new Vector2(0, 0), new Vector2(0, length / uvScale), new Vector2(width / uvScale, length / uvScale), new Vector2(width / uvScale, 0) };
        m.triangles = new[] { 0, 1, 2, 0, 2, 3 };
        m.RecalculateNormals();
        m.RecalculateBounds();
        return m;
    }

    /// <summary>Water across the trail (flows sideways, from left to right of the rider).</summary>
    static GameObject Water(string name, Transform parent, Vector3 centre, Vector3 trailDir, float alongTrail, float across, float speed)
    {
        Vector3 right = new Vector3(trailDir.z, 0f, -trailDir.x);
        var go = MeshObject(name, parent, WaterQuad(alongTrail, across, 8f), WaterMat, centre, Quaternion.LookRotation(right, Vector3.up), false);
        go.AddComponent<ScrollTexture>().speed = new Vector2(0f, -speed);
        return go;
    }

    static AudioSource Sound3D(Transform parent, Vector3 worldPos, string clip, float volume, float minDist, float maxDist)
    {
        if (GameAudio.I == null) return null;
        var c = GameAudio.I.Clip(clip);
        if (c == null) return null;
        var go = new GameObject("Sound " + clip);
        go.transform.SetParent(parent, false);
        go.transform.position = worldPos;
        var s = go.AddComponent<AudioSource>();
        s.clip = c;
        s.loop = true;
        s.volume = volume;
        s.spatialBlend = 1f;
        s.rolloffMode = AudioRolloffMode.Logarithmic;
        s.minDistance = minDist;
        s.maxDistance = maxDist;
        s.dopplerLevel = 0f;
        s.time = Random.Range(0f, Mathf.Max(0f, c.length - 0.1f));
        s.Play();
        var low = go.AddComponent<AudioLowPassFilter>();   // soft and far away
        low.cutoffFrequency = 2600f;
        return s;
    }

    // ------------------------------------------------------------------ wooden bridge
    static void WoodBridge(Zone z, TrailPath path, Transform parent)
    {
        Vector3 a = path.Point(z.gapStart - 1), b = path.Point(z.gapEnd + 1);
        Vector3 dir = (b - a); dir.y = 0f;
        float len = dir.magnitude + 1f;
        dir.Normalize();
        Vector3 mid = (a + b) * 0.5f;
        var rnd = new System.Random(z.id * 31 + 5);

        var mb = new MeshBuilder();
        const float half = 1.8f;
        // planks across
        for (float s = -len / 2f; s < len / 2f; s += 0.5f)
            mb.Box(new Vector3(0, -0.07f, s + 0.23f), new Vector3(half * 2f, 0.12f, 0.44f), Quaternion.Euler(0, (float)rnd.NextDouble() * 2f - 1f, 0), Vary(Wood, rnd));
        // beams under the planks
        foreach (float x in new[] { -1.4f, 0f, 1.4f })
            mb.Box(new Vector3(x, -0.25f, 0), new Vector3(0.22f, 0.25f, len), Quaternion.identity, DarkWood);
        // railings
        for (int sgn = -1; sgn <= 1; sgn += 2)
        {
            for (float s = -len / 2f; s <= len / 2f + 0.01f; s += 2f)
                mb.Box(new Vector3(sgn * (half + 0.05f), 0.5f, s), new Vector3(0.14f, 1.1f, 0.14f), Quaternion.identity, DarkWood);
            mb.Box(new Vector3(sgn * (half + 0.05f), 1.02f, 0), new Vector3(0.1f, 0.1f, len), Quaternion.identity, Wood);
            mb.Box(new Vector3(sgn * (half + 0.05f), 0.55f, 0), new Vector3(0.07f, 0.07f, len), Quaternion.identity, Wood);
        }
        // trestle legs down into the gorge at both ends and the middle
        foreach (float s in new[] { -len / 2f + 2f, 0f, len / 2f - 2f })
            foreach (float x in new[] { -1.5f, 1.5f })
                mb.Cylinder(new Vector3(x, -0.3f, s), new Vector3(x * 1.4f, -20f, s), 0.16f, 0.22f, 6, DarkWood, false);

        var go = MeshObject("WoodBridge", parent, mb.ToMesh("WoodBridge"), JungleProps.Material, mid, Quaternion.LookRotation(dir));
        AddBox(go, new Vector3(0, -0.12f, 0), new Vector3(half * 2f, 0.24f, len));
        AddBox(go, new Vector3(-half - 0.05f, 0.55f, 0), new Vector3(0.18f, 1.1f, len));
        AddBox(go, new Vector3(half + 0.05f, 0.55f, 0), new Vector3(0.18f, 1.1f, len));

        GorgeRiver(z, path, parent, mid, dir, len);
    }

    static void GorgeRiver(Zone z, TrailPath path, Transform parent, Vector3 mid, Vector3 dir, float len)
    {
        Vector3 water = mid + Vector3.down * (TrailPath.GorgeDepth - 1.6f);
        Water("GorgeRiver", parent, water, dir, len + 4f, 70f, 0.35f);
        Sound3D(parent, water, "river_loop", 0.55f, 8f, 70f);
    }

    // ------------------------------------------------------------------ river crossing
    static void River(Zone z, TrailPath path, Transform parent)
    {
        Vector3 a = path.Point(z.gapStart - 1), b = path.Point(z.gapEnd + 1);
        Vector3 dir = b - a; dir.y = 0f;
        float len = dir.magnitude;
        dir.Normalize();
        Vector3 centre = (a + b) * 0.5f;
        centre.y = z.baseY - 0.22f;
        Water("River", parent, centre, dir, len, 72f, 0.5f);
        Sound3D(parent, centre, "river_loop", 0.7f, 5f, 55f);

        // stones in the water
        var rnd = new System.Random(z.id * 17 + 3);
        Vector3 right = new Vector3(dir.z, 0f, -dir.x);
        for (int k = 0; k < 9; k++)
        {
            float x = ((float)rnd.NextDouble() < 0.5f ? -1f : 1f) * (4f + (float)rnd.NextDouble() * 18f);
            float s = ((float)rnd.NextDouble() - 0.5f) * len * 0.7f;
            JungleProps.Spawn(JungleProps.Kind.Rock, rnd.Next(3), parent, centre + right * x + dir * s + Vector3.down * 0.25f,
                Quaternion.Euler(0, (float)rnd.NextDouble() * 360f, 0), 0.6f + (float)rnd.NextDouble() * 0.8f);
        }
    }

    // ------------------------------------------------------------------ temple ruins
    static void Temple(Zone z, TrailPath path, Transform parent)
    {
        var rnd = new System.Random(z.id * 13 + 7);
        Vector3 dir = path.Forward(z.gapStart);
        Vector3 right = path.Right(z.gapStart);
        Quaternion rot = Quaternion.LookRotation(dir);

        // stone tiles on the trail
        var tiles = new MeshBuilder();
        Vector3 origin = path.Point(z.start);
        float total = (z.end - z.start) * TrailPath.SegLen;
        for (float s = 0; s < total; s += 1.1f)
            for (float x = -2.75f; x <= 2.76f; x += 1.1f)
            {
                if (rnd.NextDouble() < 0.12) continue;  // missing tiles
                tiles.Box(new Vector3(x, -0.03f, s), new Vector3(1.04f, 0.06f, 1.04f), Quaternion.Euler(0, (float)rnd.NextDouble() * 4f - 2f, 0), Vary(StoneC, rnd, 0.15f));
            }
        MeshObject("TempleTiles", parent, tiles.ToMesh("TempleTiles"), JungleProps.Material, origin, rot, false);

        // the arch over the trail
        Vector3 archPos = path.Point(z.gapStart + 4);
        var arch = new MeshBuilder();
        for (int sgn = -1; sgn <= 1; sgn += 2)
        {
            arch.Box(new Vector3(sgn * 4.4f, 0.4f, 0), new Vector3(1.6f, 0.8f, 1.6f), Quaternion.identity, StoneC);
            for (int k = 0; k < 5; k++)
                arch.Box(new Vector3(sgn * 4.4f, 1.3f + k * 1.0f, 0), new Vector3(1.15f, 0.96f, 1.15f), Quaternion.Euler(0, k * 3f, 0), Vary(StoneC, rnd));
        }
        arch.Box(new Vector3(0, 6.15f, 0), new Vector3(10.6f, 1.1f, 1.5f), Quaternion.identity, Vary(StoneC, rnd));
        arch.Box(new Vector3(0, 6.95f, 0), new Vector3(8.4f, 0.5f, 1.2f), Quaternion.identity, Moss);
        arch.Box(new Vector3(0, 7.5f, 0), new Vector3(1.6f, 0.9f, 1.0f), Quaternion.identity, Vary(StoneC, rnd)); // carved stone face block
        var archGo = MeshObject("TempleArch", parent, arch.ToMesh("TempleArch"), JungleProps.Material, archPos, rot);
        AddBox(archGo, new Vector3(-4.4f, 3f, 0), new Vector3(1.2f, 6f, 1.2f));
        AddBox(archGo, new Vector3(4.4f, 3f, 0), new Vector3(1.2f, 6f, 1.2f));

        // broken pillars and blocks along the sides
        var ruins = new MeshBuilder();
        for (int k = 0; k < 6; k++)
        {
            int i = z.start + 1 + k * 2;
            if (i == z.gapStart + 4) continue;
            int sgn = k % 2 == 0 ? 1 : -1;
            Vector3 p = path.Surface(i, sgn * 6.2f) - archPos;
            p = Quaternion.Inverse(rot) * p;
            int h = 1 + rnd.Next(4);
            for (int j = 0; j < h; j++)
                ruins.Box(p + new Vector3(0, 0.5f + j * 0.95f, 0), new Vector3(1.0f, 0.92f, 1.0f), Quaternion.Euler(0, (float)rnd.NextDouble() * 20f, (float)rnd.NextDouble() * 6f - 3f), Vary(StoneC, rnd));
        }
        // the low wall that hides the gem (left side)
        for (float s = 0.6f; s < 1.9f; s += 0.35f)
        {
            Vector3 p = path.Surface(z.start + 4 + (int)s, -5.0f) - archPos;
            p = Quaternion.Inverse(rot) * p + new Vector3(0, 0, (s % 1f) * TrailPath.SegLen);
            ruins.Box(p + new Vector3(0, 0.75f, 0), new Vector3(0.8f, 1.6f, 1.5f), Quaternion.identity, Vary(StoneC, rnd));
            ruins.Box(p + new Vector3(0, 1.6f, 0), new Vector3(0.85f, 0.15f, 1.5f), Quaternion.identity, Moss);
        }
        // fallen pillar pieces
        for (int k = 0; k < 4; k++)
        {
            int sgn = rnd.Next(2) == 0 ? -1 : 1;
            Vector3 p = Quaternion.Inverse(rot) * (path.Surface(z.start + rnd.Next(z.end - z.start), sgn * (8f + (float)rnd.NextDouble() * 5f)) - archPos);
            ruins.Cylinder(p + new Vector3(-0.9f, 0.45f, 0), p + new Vector3(0.9f, 0.45f, 0.4f), 0.45f, 0.45f, 8, Vary(StoneC, rnd));
        }
        var ruinsGo = MeshObject("TempleRuins", parent, ruins.ToMesh("TempleRuins"), JungleProps.Material, archPos, rot);
        ruinsGo.AddComponent<MeshCollider>().sharedMesh = ruinsGo.GetComponent<MeshFilter>().sharedMesh;
    }

    // ------------------------------------------------------------------ waterfall jump
    static void Waterfall(Zone z, TrailPath path, Transform parent)
    {
        Vector3 dir = path.Forward(z.gapStart);
        Vector3 right = path.Right(z.gapStart);
        Quaternion rot = Quaternion.LookRotation(dir);

        // big wooden kicker before the gap (ends right at the edge)
        Vector3 rampEnd = path.Point(z.gapStart - 1) + dir * 0.6f;
        const float rampLen = 5.5f, rampH = 1.5f, w = 1.7f;
        var mb = new MeshBuilder();
        Vector3 c = new Vector3(0, 0, -rampLen / 2f);
        Vector3 p0 = new Vector3(-w, -0.05f, -rampLen), p1 = new Vector3(w, -0.05f, -rampLen);
        Vector3 p2 = new Vector3(w, -0.05f, 0), p3 = new Vector3(-w, -0.05f, 0);
        Vector3 t2 = new Vector3(w, rampH, 0), t3 = new Vector3(-w, rampH, 0);
        mb.QuadOut(p0, p1, t2, t3, Wood, c + new Vector3(0, -2f, 2f));    // riding surface
        mb.QuadOut(p3, p2, t2, t3, DarkWood, c);                            // front face
        mb.TriOut(p0, p3, t3, DarkWood, c);
        mb.TriOut(p1, p2, t2, DarkWood, c);
        for (float s = 0.3f; s < rampLen; s += 0.6f)
        {
            float y = rampH * (1f - s / rampLen);
            mb.Box(new Vector3(0, y + 0.02f, -s), new Vector3(w * 2f + 0.1f, 0.05f, 0.08f), Quaternion.Euler(-Mathf.Atan2(rampH, rampLen) * Mathf.Rad2Deg, 0, 0), DarkWood);
        }
        var rampMesh = mb.ToMesh("WaterfallRamp");
        var ramp = MeshObject("WaterfallRamp", parent, rampMesh, JungleProps.Material, rampEnd, rot);
        var mc = ramp.AddComponent<MeshCollider>();
        var colMesh = new Mesh { name = "RampCollider" };
        colMesh.vertices = new[] { p0, p1, p2, p3, t2, t3 };
        colMesh.triangles = new[] { 0, 3, 5, 0, 5, 4, 0, 4, 1, 3, 2, 4, 3, 4, 5, 1, 4, 2, 0, 1, 2, 0, 2, 3 };
        colMesh.RecalculateBounds();
        mc.sharedMesh = colMesh;
        mc.convex = true;

        // the waterfall pours into the gorge from the right
        Vector3 gapMid = (path.Point(z.gapStart - 1) + path.Point(z.gapEnd + 1)) * 0.5f;
        gapMid.y = z.baseY;
        Vector3 fallBase = gapMid + right * 16f;
        float top = 12f, bottom = -TrailPath.GorgeDepth + 1f;
        var fall = new Mesh { name = "WaterfallSheet" };
        float hw = 4.5f;
        var verts = new List<Vector3>(); var uvs = new List<Vector2>(); var tris = new List<int>();
        const int rows = 10;
        for (int r = 0; r <= rows; r++)
        {
            float t = r / (float)rows;
            float y = Mathf.Lerp(top, bottom, t);
            float bulge = Mathf.Sin(t * Mathf.PI) * 1.2f + t * 2.5f;   // the water arcs out a little
            verts.Add(new Vector3(-hw, y, -bulge)); verts.Add(new Vector3(hw, y, -bulge));
            uvs.Add(new Vector2(0, t * 4f)); uvs.Add(new Vector2(1.5f, t * 4f));
            if (r > 0)
            {
                int k = r * 2;
                tris.Add(k - 2); tris.Add(k); tris.Add(k + 1);
                tris.Add(k - 2); tris.Add(k + 1); tris.Add(k - 1);
            }
        }
        fall.SetVertices(verts); fall.SetUVs(0, uvs); fall.SetTriangles(tris, 0);
        fall.RecalculateNormals(); fall.RecalculateBounds();
        // local Z of the sheet faces the trail
        var sheet = MeshObject("Waterfall", parent, fall, FallMat, fallBase, Quaternion.LookRotation(right, Vector3.up), false);
        sheet.AddComponent<ScrollTexture>().speed = new Vector2(0f, -1.6f);

        // rocky cliff behind the waterfall, stones on top
        var rocks = new MeshBuilder();
        var rnd = new System.Random(z.id * 41 + 9);
        for (int k = 0; k < 14; k++)
        {
            float y = Mathf.Lerp(bottom, top + 2f, k / 13f);
            rocks.Blob(new Vector3(((float)rnd.NextDouble() - 0.5f) * 14f, y, 2.5f + (float)rnd.NextDouble() * 2f),
                new Vector3(3f, 2.4f, 2f) * (0.8f + (float)rnd.NextDouble() * 0.6f), Vary(new Color(0.42f, 0.42f, 0.4f), rnd), rnd);
        }
        MeshObject("WaterfallCliff", parent, rocks.ToMesh("WaterfallCliff"), JungleProps.Material, fallBase, Quaternion.LookRotation(right, Vector3.up));

        // pool at the bottom, mist and the roar
        Water("WaterfallPool", parent, gapMid + Vector3.down * (TrailPath.GorgeDepth - 1.4f), dir, 16f, 70f, 0.6f);
        WeatherFX.Mist(parent, fallBase + Vector3.up * (bottom + 1f) - right * 2f);
        Sound3D(parent, fallBase + Vector3.up * (bottom * 0.4f), "waterfall_loop", 0.9f, 12f, 110f);
    }

    // ------------------------------------------------------------------ mountain road edge
    /// <summary>Small stones along the drop edge of the mountain road (no collider: you can still fall).</summary>
    public static void SpiralEdge(TrailPath path, int i, Transform parent, System.Random rnd)
    {
        if (i % 3 != 0) return;
        JungleProps.Spawn(JungleProps.Kind.Rock, rnd.Next(3), parent, path.Surface(i, -3.9f) + Vector3.down * 0.15f,
            Quaternion.Euler(0, (float)rnd.NextDouble() * 360f, 0), 0.35f + (float)rnd.NextDouble() * 0.2f);
    }
}

/// <summary>Moves a material's texture to make water flow (each object gets its own material copy).</summary>
public class ScrollTexture : MonoBehaviour
{
    public Vector2 speed;
    Material mat;
    Vector2 offset;

    void Start()
    {
        var r = GetComponent<Renderer>();
        if (r) mat = r.material;   // instance
    }

    void Update()
    {
        if (!mat) return;
        offset += speed * Time.deltaTime;
        offset.x %= 1f; offset.y %= 1f;
        mat.mainTextureOffset = offset;
    }

    void OnDestroy()
    {
        if (mat) Destroy(mat);
    }
}

/// <summary>
/// A rope bridge across a gorge. The planks hang in a curve, sag deeper under the rider and swing sideways
/// when you steer or ride fast. There are only rope hand-rails: steer badly and you fall into the gorge.
/// </summary>
public class RopeBridge : MonoBehaviour
{
    const float DeckHalf = 1.1f;
    const float BaseSag = 0.6f, LoadSag = 0.45f, PlankStep = 0.55f;

    Vector3 a, b, dir, right;
    float len;
    Transform[] planks;          // what you see
    MeshCollider deck;           // what you ride on: one smooth surface (no gaps or edges to get stuck on)
    Mesh deckMesh;
    Vector3[] deckVerts;
    const int DeckSegs = 48;
    LineRenderer[] ropes;
    float sway, swayVel, load, creakTimer, bikeT;
    static Mesh plankMesh, plankHangerMesh;
    static Material ropeMat;

    public static void Create(Zone z, TrailPath path, Transform parent)
    {
        var go = new GameObject("RopeBridge");
        go.transform.SetParent(parent, false);
        var rb = go.AddComponent<RopeBridge>();
        rb.Build(z, path);
    }

    void Build(Zone z, TrailPath path)
    {
        a = path.Point(z.gapStart - 1);
        b = path.Point(z.gapEnd + 1);
        dir = b - a; dir.y = 0f;
        len = dir.magnitude;
        dir.Normalize();
        right = new Vector3(dir.z, 0f, -dir.x);

        if (plankMesh == null)
        {
            var mb = new MeshBuilder();
            mb.Box(Vector3.zero, new Vector3(DeckHalf * 2f, 0.08f, 0.46f), Quaternion.identity, new Color(0.6f, 0.43f, 0.24f));
            plankMesh = mb.ToMesh("Plank");
            mb.Box(new Vector3(-DeckHalf, 0.5f, 0), new Vector3(0.04f, 1f, 0.04f), Quaternion.identity, new Color(0.7f, 0.6f, 0.4f));
            mb.Box(new Vector3(DeckHalf, 0.5f, 0), new Vector3(0.04f, 1f, 0.04f), Quaternion.identity, new Color(0.7f, 0.6f, 0.4f));
            plankHangerMesh = mb.ToMesh("PlankHangers");
            var shader = Shader.Find("JungleRider/Particle");
            if (shader == null) shader = Shader.Find("Sprites/Default");
            ropeMat = new Material(shader) { name = "Rope" };
        }

        int n = Mathf.Max(4, Mathf.RoundToInt(len / PlankStep));
        planks = new Transform[n];
        var rnd = new System.Random(z.id * 7 + 1);
        for (int k = 0; k < n; k++)
        {
            var p = new GameObject("Plank" + k);
            p.transform.SetParent(transform, false);
            p.AddComponent<MeshFilter>().sharedMesh = k % 3 == 1 ? plankHangerMesh : plankMesh;
            p.AddComponent<MeshRenderer>().sharedMaterial = JungleProps.Material;
            planks[k] = p.transform;
            p.transform.position = PlankPos(k, n, out Quaternion q);
            p.transform.rotation = q;
        }

        // the riding surface: a thin curved deck that follows the planks
        var dgo = new GameObject("DeckCollider");
        dgo.transform.SetParent(transform, false);
        var drb = dgo.AddComponent<Rigidbody>();
        drb.isKinematic = true;
        deckMesh = new Mesh { name = "RopeDeck" };
        deckMesh.MarkDynamic();
        deckVerts = new Vector3[(DeckSegs + 1) * 2];
        var tris = new int[DeckSegs * 6];
        for (int k = 0; k < DeckSegs; k++)
        {
            int l0 = k * 2, r0 = l0 + 1, l1 = l0 + 2, r1 = l0 + 3;
            tris[k * 6] = l0; tris[k * 6 + 1] = l1; tris[k * 6 + 2] = r1;   // facing up
            tris[k * 6 + 3] = l0; tris[k * 6 + 4] = r1; tris[k * 6 + 5] = r0;
        }
        UpdateDeckVerts();
        deckMesh.vertices = deckVerts;
        deckMesh.triangles = tris;
        deckMesh.RecalculateBounds();
        deck = dgo.AddComponent<MeshCollider>();
        deck.sharedMesh = deckMesh;

        // posts at both ends
        var posts = new MeshBuilder();
        foreach (Vector3 end in new[] { a - dir * 0.3f, b + dir * 0.3f })
            for (int sgn = -1; sgn <= 1; sgn += 2)
                posts.Cylinder(end + right * sgn * (DeckHalf + 0.25f) + Vector3.down * 1.5f, end + right * sgn * (DeckHalf + 0.25f) + Vector3.up * 1.6f, 0.16f, 0.13f, 7, new Color(0.38f, 0.26f, 0.14f));
        Adventures.MeshObject("RopeBridgePosts", transform, posts.ToMesh("RopeBridgePosts"), JungleProps.Material, Vector3.zero, Quaternion.identity);

        // 2 hand ropes + 2 ropes under the deck edges
        ropes = new LineRenderer[4];
        for (int r = 0; r < 4; r++)
        {
            var lgo = new GameObject("Rope" + r);
            lgo.transform.SetParent(transform, false);
            var lr = lgo.AddComponent<LineRenderer>();
            lr.sharedMaterial = ropeMat;
            lr.positionCount = n + 2;
            lr.widthMultiplier = r < 2 ? 0.06f : 0.045f;
            lr.startColor = lr.endColor = new Color(0.62f, 0.52f, 0.34f);
            lr.numCapVertices = 0;
            lr.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            lr.useWorldSpace = true;
            ropes[r] = lr;
        }

        // the gorge river below
        Vector3 mid = (a + b) * 0.5f;
        var water = new GameObject("GorgeRiverHolder").transform;
        water.SetParent(transform, false);
        var src = GameAudio.I != null ? GameAudio.I.Clip("river_loop") : null;
        Adventures.MeshObject("GorgeRiver", transform, MakeRiverQuad(len + 4f), Adventures.WaterMat, mid + Vector3.down * (TrailPath.GorgeDepth - 1.6f), Quaternion.LookRotation(right), false)
            .AddComponent<ScrollTexture>().speed = new Vector2(0, -0.35f);
        if (src)
        {
            var s = water.gameObject.AddComponent<AudioSource>();
            water.position = mid + Vector3.down * 20f;
            s.clip = src; s.loop = true; s.volume = 0.5f; s.spatialBlend = 1f; s.minDistance = 8f; s.maxDistance = 70f;
            s.rolloffMode = AudioRolloffMode.Logarithmic; s.dopplerLevel = 0f;
            s.Play();
            water.gameObject.AddComponent<AudioLowPassFilter>().cutoffFrequency = 2600f;
        }
        UpdateRopes();
    }

    static Mesh MakeRiverQuad(float along)
    {
        var m = new Mesh { name = "GorgeRiver" };
        float w = along * 0.5f, l = 35f;
        m.vertices = new[] { new Vector3(-w, 0, -l), new Vector3(-w, 0, l), new Vector3(w, 0, l), new Vector3(w, 0, -l) };
        m.uv = new[] { new Vector2(0, 0), new Vector2(0, 8), new Vector2(along / 8f, 8), new Vector2(along / 8f, 0) };
        m.triangles = new[] { 0, 1, 2, 0, 2, 3 };
        m.RecalculateNormals();
        m.RecalculateBounds();
        return m;
    }

    float Sag(float t) => BaseSag * 4f * t * (1f - t) + load * LoadSag * Mathf.Exp(-Mathf.Pow((t - bikeT) * len / 2.5f, 2f)) * (0.35f + 4f * bikeT * (1f - bikeT));

    Vector3 PlankPos(int k, int n, out Quaternion rot)
    {
        float t = (k + 0.5f) / n;
        float side = sway * 4f * t * (1f - t);
        Vector3 p = Vector3.Lerp(a, b, t) + Vector3.down * (Sag(t) + 0.04f) + right * side;
        float dt = 0.02f;
        float slope = (Sag(Mathf.Min(1f, t + dt)) - Sag(Mathf.Max(0f, t - dt))) / (2f * dt * len);
        float roll = -swayVel * 6f * 4f * t * (1f - t);
        rot = Quaternion.LookRotation(dir, Vector3.up) * Quaternion.Euler(Mathf.Atan(slope) * Mathf.Rad2Deg, 0f, roll);
        return p;
    }

    void FixedUpdate()
    {
        if (planks == null) return;
        float dt = Time.fixedDeltaTime;
        var bike = BikeController.Player;
        bool on = false;
        float speed = 0f, lateralVel = 0f, steer = 0f;
        if (bike)
        {
            Vector3 rel = bike.transform.position - a;
            float t = Vector3.Dot(new Vector3(rel.x, 0, rel.z), dir) / len;
            float lat = Vector3.Dot(rel, right) - sway * 4f * Mathf.Clamp01(t) * (1f - Mathf.Clamp01(t));
            on = t > -0.02f && t < 1.02f && Mathf.Abs(lat) < DeckHalf + 0.6f && rel.y > -2.5f && rel.y < 2f;
            if (on)
            {
                bikeT = Mathf.Clamp01(t);
                speed = Mathf.Abs(bike.ForwardSpeed);
                lateralVel = Vector3.Dot(bike.Velocity3, right);
                steer = bike.input ? bike.input.Steer : 0f;
            }
        }
        load = Mathf.MoveTowards(load, on ? 1f : 0f, dt * 3f);

        // sideways swing: a spring pushed by the rider's steering and speed, plus a little wind
        float drive = on ? (lateralVel * 0.9f + steer * 0.8f + Mathf.Sin(Time.time * 2.3f) * speed * 0.03f) : Mathf.Sin(Time.time * 0.7f) * 0.05f;
        swayVel += (-9f * sway - 1.6f * swayVel + drive) * dt;
        sway = Mathf.Clamp(sway + swayVel * dt, -0.45f, 0.45f);

        // move the riding surface
        UpdateDeckVerts();
        deckMesh.vertices = deckVerts;
        deckMesh.RecalculateBounds();
        deck.sharedMesh = null;
        deck.sharedMesh = deckMesh;

        // creaks
        if (on && speed > 0.8f && GameAudio.I != null)
        {
            creakTimer -= dt;
            if (creakTimer <= 0f)
            {
                GameAudio.I.PlayAt("rope_creak_" + Random.Range(0, 3), bike.transform.position, 0.35f + 0.35f * Mathf.Clamp01(speed / 8f + Mathf.Abs(sway)));
                creakTimer = Random.Range(0.45f, 1.1f) * Mathf.Lerp(1.4f, 0.7f, Mathf.Clamp01(speed / 10f));
            }
        }
    }

    void UpdateDeckVerts()
    {
        for (int k = 0; k <= DeckSegs; k++)
        {
            float t = k / (float)DeckSegs;
            float side = sway * 4f * t * (1f - t);
            Vector3 c = Vector3.Lerp(a, b, t) + Vector3.down * Sag(t) + right * side;
            // the ends reach a little onto the ground so there is no step
            if (k == 0) c -= dir * 0.4f;
            if (k == DeckSegs) c += dir * 0.4f;
            Vector3 rr = Quaternion.AngleAxis(-swayVel * 6f * 4f * t * (1f - t), dir) * right * DeckHalf;
            deckVerts[k * 2] = c - rr;
            deckVerts[k * 2 + 1] = c + rr;
        }
    }

    void LateUpdate()
    {
        if (planks == null) return;
        int n = planks.Length;
        for (int k = 0; k < n; k++)
        {
            planks[k].position = PlankPos(k, n, out Quaternion q);
            planks[k].rotation = q;
        }
        UpdateRopes();
    }

    void UpdateRopes()
    {
        if (ropes == null) return;
        int n = planks.Length;
        for (int r = 0; r < 4; r++)
        {
            float sgn = r % 2 == 0 ? -1f : 1f;
            float up = r < 2 ? 1.0f : -0.02f;
            var lr = ropes[r];
            Vector3 endOff = right * sgn * (DeckHalf + 0.25f) + Vector3.up * (r < 2 ? 1.45f : 0f);
            lr.SetPosition(0, a - dir * 0.3f + endOff);
            for (int k = 0; k < n; k++)
            {
                var t = planks[k];
                lr.SetPosition(k + 1, t.position + t.right * sgn * DeckHalf + t.up * up);
            }
            lr.SetPosition(n + 1, b + dir * 0.3f + endOff);
        }
    }
}

/// <summary>A few monkeys that run across the trail in front of the rider, chattering.</summary>
public class MonkeyTroop : MonoBehaviour
{
    TrailPath path;
    int crossIndex;
    Transform[] monkeys;
    float[] delays;
    Vector3 from, to;
    bool started;
    float t;
    static Mesh monkeyMesh;

    public static void Create(Zone z, TrailPath path, Transform parent)
    {
        var go = new GameObject("Monkeys");
        go.transform.SetParent(parent, false);
        var m = go.AddComponent<MonkeyTroop>();
        m.path = path;
        m.crossIndex = z.gapStart;
        m.Build(z);
    }

    static Mesh MonkeyMesh()
    {
        if (monkeyMesh != null) return monkeyMesh;
        var mb = new MeshBuilder();
        var rnd = new System.Random(4);
        Color fur = new Color(0.4f, 0.27f, 0.15f), face = new Color(0.82f, 0.66f, 0.5f), dark = new Color(0.25f, 0.16f, 0.09f);
        // facing +Z (running direction)
        mb.Blob(new Vector3(0, 0.55f, 0), new Vector3(0.2f, 0.22f, 0.3f), fur, rnd);
        mb.Blob(new Vector3(0, 0.78f, 0.3f), new Vector3(0.16f, 0.15f, 0.15f), fur, rnd);
        mb.Blob(new Vector3(0, 0.75f, 0.42f), new Vector3(0.1f, 0.09f, 0.05f), face, rnd);
        mb.Blob(new Vector3(-0.15f, 0.86f, 0.3f), new Vector3(0.05f, 0.06f, 0.03f), face, rnd);
        mb.Blob(new Vector3(0.15f, 0.86f, 0.3f), new Vector3(0.05f, 0.06f, 0.03f), face, rnd);
        foreach (float x in new[] { -0.13f, 0.13f })
        {
            mb.Cylinder(new Vector3(x, 0.5f, 0.2f), new Vector3(x, 0.05f, 0.3f), 0.05f, 0.04f, 5, dark);
            mb.Cylinder(new Vector3(x, 0.45f, -0.2f), new Vector3(x, 0.05f, -0.28f), 0.06f, 0.04f, 5, dark);
        }
        // curled tail
        Vector3 prev = new Vector3(0, 0.6f, -0.28f);
        for (int k = 1; k <= 6; k++)
        {
            float a = k * 0.45f;
            Vector3 p = new Vector3(0, 0.6f + Mathf.Sin(a) * 0.45f, -0.28f - Mathf.Cos(a - 0.4f) * 0.25f - k * 0.04f);
            mb.Cylinder(prev, p, 0.035f, 0.03f, 5, fur, false);
            prev = p;
        }
        monkeyMesh = mb.ToMesh("Monkey");
        return monkeyMesh;
    }

    void Build(Zone z)
    {
        Vector3 c = path.Point(crossIndex);
        Vector3 right = path.Right(crossIndex);
        from = c - right * 14f;
        to = c + right * 14f;
        int n = 3;
        monkeys = new Transform[n];
        delays = new float[n];
        for (int k = 0; k < n; k++)
        {
            Vector3 start = from + path.Forward(crossIndex) * (k - 1) * 1.6f;
            start.y = path.Surface(crossIndex, -14f).y;
            var go = Adventures.MeshObject("Monkey" + k, transform, MonkeyMesh(), JungleProps.Material, start, Quaternion.LookRotation(right), true);
            go.transform.localScale = Vector3.one * (k == 1 ? 0.8f : 1f);
            monkeys[k] = go.transform;
            delays[k] = k * 0.35f;
        }
    }

    void Update()
    {
        var bike = BikeController.Player;
        if (!started)
        {
            if (bike == null) return;
            int idx = path.ClosestIndex(bike.transform.position, Mathf.Max(0, crossIndex - 10));
            if (idx >= crossIndex - 9 && idx <= crossIndex && (path.Point(crossIndex) - bike.transform.position).magnitude < 45f)
            {
                started = true;
                if (GameAudio.I != null) GameAudio.I.PlayAt("monkey_" + Random.Range(0, 2), path.Point(crossIndex) - path.Right(crossIndex) * 8f, 0.8f);
            }
            return;
        }
        if (t > 6f) return;
        t += Time.deltaTime;
        Vector3 fwd = path.Forward(crossIndex);
        for (int k = 0; k < monkeys.Length; k++)
        {
            float u = Mathf.Clamp01((t - delays[k]) / 2.2f);
            float lat = Mathf.Lerp(-14f, 14f, u);
            Vector3 p = path.Surface(crossIndex, lat) + fwd * (k - 1) * 1.6f;
            p.y += Mathf.Abs(Mathf.Sin(u * Mathf.PI * 7f)) * 0.35f * (u > 0f && u < 1f ? 1f : 0f);
            monkeys[k].position = p;
        }
        if (t > 1.4f && t - Time.deltaTime <= 1.4f && GameAudio.I != null)
            GameAudio.I.PlayAt("monkey_" + Random.Range(0, 2), to, 0.6f);
    }
}
