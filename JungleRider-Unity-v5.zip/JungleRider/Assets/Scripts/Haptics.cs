using UnityEngine;

/// <summary>Very short, light vibration tap (about 15 ms) for menu buttons.</summary>
public static class Haptics
{
#if UNITY_ANDROID && !UNITY_EDITOR
    static AndroidJavaObject vibrator;
    static AndroidJavaClass effectClass;
    static int sdk = -1;
    static bool failed;
#endif

    public static void Tap()
    {
#if UNITY_ANDROID && !UNITY_EDITOR
        if (failed) return;
        try
        {
            if (vibrator == null)
            {
                using (var player = new AndroidJavaClass("com.unity3d.player.UnityPlayer"))
                using (var activity = player.GetStatic<AndroidJavaObject>("currentActivity"))
                    vibrator = activity.Call<AndroidJavaObject>("getSystemService", "vibrator");
                using (var version = new AndroidJavaClass("android.os.Build$VERSION"))
                    sdk = version.GetStatic<int>("SDK_INT");
                if (sdk >= 26) effectClass = new AndroidJavaClass("android.os.VibrationEffect");
            }
            if (vibrator == null) { failed = true; return; }
            if (sdk >= 26)
            {
                using (var effect = effectClass.CallStatic<AndroidJavaObject>("createOneShot", 15L, 70))
                    vibrator.Call("vibrate", effect);
            }
            else
            {
                vibrator.Call("vibrate", 15L);
            }
        }
        catch (System.Exception e)
        {
            failed = true;
            Debug.LogWarning("Vibration not available: " + e.Message);
        }
#endif
        // Never runs; it only tells Unity to add the VIBRATE permission to the Android app.
        if (Time.frameCount < 0) Handheld.Vibrate();
    }
}
