using UnityEngine;

/// <summary>
/// A fallen log you can ride over: a low, rounded bump the wheels roll up and over.
/// Hitting it gives a jolt, a small bounce and costs some speed (more when you hit it fast).
/// </summary>
public class LogBump : MonoBehaviour
{
    static Mesh bumpMesh;
    float lastHit = -10f;

    /// <summary>Adds the ride-over shape and the jolt to a log (the log lies along its local X axis).</summary>
    public static void Setup(GameObject log)
    {
        if (bumpMesh == null)
        {
            // low prism along X: 5.2 m long, 1.4 m deep, 0.2 m high above the log's centre
            const float hx = 2.6f, hz = 0.7f;
            var v = new[]
            {
                new Vector3(-hx, -0.12f, -hz), new Vector3(-hx, 0.2f, 0f), new Vector3(-hx, -0.12f, hz),
                new Vector3(hx, -0.12f, -hz), new Vector3(hx, 0.2f, 0f), new Vector3(hx, -0.12f, hz),
            };
            bumpMesh = new Mesh { name = "LogBump" };
            bumpMesh.vertices = v;
            bumpMesh.triangles = new[] { 0, 1, 4, 0, 4, 3, 1, 2, 5, 1, 5, 4, 0, 2, 1, 3, 4, 5, 0, 3, 5, 0, 5, 2 };
            bumpMesh.RecalculateNormals();
            bumpMesh.RecalculateBounds();
        }
        var mc = log.AddComponent<MeshCollider>();
        mc.sharedMesh = bumpMesh;
        mc.convex = true;

        var trigger = log.AddComponent<BoxCollider>();
        trigger.isTrigger = true;
        trigger.center = new Vector3(0f, 0.5f, 0f);
        trigger.size = new Vector3(5.2f, 1.2f, 0.6f);
        log.AddComponent<LogBump>();
    }

    void OnTriggerEnter(Collider other)
    {
        var rb = other.attachedRigidbody;
        if (rb == null || Time.time - lastHit < 1f) return;
        var bike = rb.GetComponent<BikeController>();
        if (bike == null || !bike.Grounded) return;
        float speed = Mathf.Abs(bike.ForwardSpeed);
        if (speed < 0.5f) return;
        lastHit = Time.time;

        // faster = bigger jolt: keep 92% of the speed when slow, 80% when flat out
        float keep = Mathf.Lerp(0.92f, 0.8f, Mathf.Clamp01(speed / 15f));
        float up = Mathf.Clamp(0.6f + speed * 0.1f, 0.6f, 2f);
        bike.Bump(keep, up);
        if (GameAudio.I != null) GameAudio.I.PlayAt("pedal_thump_" + Random.Range(0, 3), bike.transform.position, 0.9f);
    }
}
