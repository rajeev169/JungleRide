using System;
using System.Text;
using UnityEngine;

/// <summary>
/// Tiny .glb reader for the rider model (one mesh with UVs and one texture, like TRELLIS makes).
/// It needs no package, so the model works in any Unity version and any build setup.
/// The file is stored as Resources/RiderBike.bytes (a .glb renamed to .bytes).
/// </summary>
public static class MiniGlb
{
    [Serializable] class Root { public Accessor[] accessors; public BufferView[] bufferViews; public MeshDef[] meshes; public ImageDef[] images; }
    [Serializable] class Accessor { public int bufferView = -1; public int byteOffset; public int componentType; public int count; public string type; }
    [Serializable] class BufferView { public int buffer; public int byteOffset; public int byteLength; public int byteStride; }
    [Serializable] class MeshDef { public Primitive[] primitives; }
    [Serializable] class Primitive { public Attributes attributes; public int indices = -1; }
    [Serializable] class Attributes { public int POSITION = -1; public int NORMAL = -1; public int TEXCOORD_0 = -1; }
    [Serializable] class ImageDef { public int bufferView = -1; public string mimeType; }

    public static GameObject Load(byte[] data, string name, Transform parent)
    {
        if (data == null || data.Length < 20 || Encoding.ASCII.GetString(data, 0, 4) != "glTF")
            throw new Exception("not a GLB file");

        int jsonLen = BitConverter.ToInt32(data, 12);
        string json = Encoding.UTF8.GetString(data, 20, jsonLen);
        int binStart = 20 + jsonLen + 8; // skip the BIN chunk header
        var root = JsonUtility.FromJson<Root>(json);

        var go = new GameObject(name);
        go.transform.SetParent(parent, false);

        Texture2D tex = null;
        if (root.images != null && root.images.Length > 0 && root.images[0].bufferView >= 0)
        {
            var bv = root.bufferViews[root.images[0].bufferView];
            var bytes = new byte[bv.byteLength];
            Buffer.BlockCopy(data, binStart + bv.byteOffset, bytes, 0, bv.byteLength);
            tex = new Texture2D(2, 2, TextureFormat.RGBA32, true);
            tex.LoadImage(bytes);
            tex.wrapMode = TextureWrapMode.Clamp;
            tex.anisoLevel = 2;
        }

        var shader = Shader.Find("JungleRider/TexturedLit");
        if (shader == null) shader = Shader.Find("Standard");
        var mat = new Material(shader) { name = name + " Material" };
        if (tex) mat.mainTexture = tex;

        foreach (var meshDef in root.meshes)
            foreach (var prim in meshDef.primitives)
            {
                var mesh = BuildMesh(root, data, binStart, prim);
                var part = new GameObject(name + " Mesh");
                part.transform.SetParent(go.transform, false);
                part.AddComponent<MeshFilter>().sharedMesh = mesh;
                part.AddComponent<MeshRenderer>().sharedMaterial = mat;
            }
        return go;
    }

    static Mesh BuildMesh(Root root, byte[] data, int binStart, Primitive prim)
    {
        var mesh = new Mesh { name = "RiderBike" };
        // glTF is right-handed, Unity left-handed: flip X and reverse the triangle order.
        var pos = ReadVec3(root, data, binStart, prim.attributes.POSITION, true);
        if (pos.Length > 65000) mesh.indexFormat = UnityEngine.Rendering.IndexFormat.UInt32;
        mesh.vertices = pos;
        if (prim.attributes.TEXCOORD_0 >= 0)
        {
            var uv = ReadFloats(root, data, binStart, prim.attributes.TEXCOORD_0, 2);
            var uvs = new Vector2[uv.Length / 2];
            for (int i = 0; i < uvs.Length; i++) uvs[i] = new Vector2(uv[i * 2], 1f - uv[i * 2 + 1]);
            mesh.uv = uvs;
        }
        int[] idx;
        if (prim.indices >= 0) idx = ReadIndices(root, data, binStart, prim.indices);
        else { idx = new int[pos.Length]; for (int i = 0; i < idx.Length; i++) idx[i] = i; }
        for (int i = 0; i + 2 < idx.Length; i += 3) { int t = idx[i + 1]; idx[i + 1] = idx[i + 2]; idx[i + 2] = t; }
        mesh.triangles = idx;
        if (prim.attributes.NORMAL >= 0) mesh.normals = ReadVec3(root, data, binStart, prim.attributes.NORMAL, true);
        else mesh.RecalculateNormals();
        mesh.RecalculateBounds();
        return mesh;
    }

    static int Offset(Root root, Accessor a, int binStart, out int stride, int elemSize)
    {
        var bv = root.bufferViews[a.bufferView];
        stride = bv.byteStride > 0 ? bv.byteStride : elemSize;
        return binStart + bv.byteOffset + a.byteOffset;
    }

    static float[] ReadFloats(Root root, byte[] data, int binStart, int accessor, int comps)
    {
        var a = root.accessors[accessor];
        if (a.componentType != 5126) throw new Exception("only float attributes are supported");
        int off = Offset(root, a, binStart, out int stride, comps * 4);
        var result = new float[a.count * comps];
        for (int i = 0; i < a.count; i++)
            for (int c = 0; c < comps; c++)
                result[i * comps + c] = BitConverter.ToSingle(data, off + i * stride + c * 4);
        return result;
    }

    static Vector3[] ReadVec3(Root root, byte[] data, int binStart, int accessor, bool flipX)
    {
        var f = ReadFloats(root, data, binStart, accessor, 3);
        var v = new Vector3[f.Length / 3];
        for (int i = 0; i < v.Length; i++) v[i] = new Vector3(flipX ? -f[i * 3] : f[i * 3], f[i * 3 + 1], f[i * 3 + 2]);
        return v;
    }

    static int[] ReadIndices(Root root, byte[] data, int binStart, int accessor)
    {
        var a = root.accessors[accessor];
        int size = a.componentType == 5125 ? 4 : a.componentType == 5123 ? 2 : 1;
        int off = Offset(root, a, binStart, out int stride, size);
        var result = new int[a.count];
        for (int i = 0; i < a.count; i++)
        {
            int p = off + i * stride;
            result[i] = size == 4 ? (int)BitConverter.ToUInt32(data, p) : size == 2 ? BitConverter.ToUInt16(data, p) : data[p];
        }
        return result;
    }
}
