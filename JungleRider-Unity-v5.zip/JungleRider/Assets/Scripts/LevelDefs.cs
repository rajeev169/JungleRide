using System.Collections.Generic;
using UnityEngine;

/// <summary>Adventures that can appear on a trail.</summary>
public enum FeatureType { WoodBridge, RopeBridge, River, Monkeys, Temple, Waterfall, Spiral }

/// <summary>One adventure placed <see cref="at"/> metres after the start.</summary>
public struct FeatureSpec
{
    public FeatureType type;
    public float at;
    public FeatureSpec(FeatureType t, float metres) { type = t; at = metres; }
}

public class AreaDef
{
    public string name;
    public int starsNeeded;
}

public class LevelDef
{
    public int number;
    public int area;          // 0..4
    public Season season;
    public float length;      // metres (a spiral mountain adds its own length at the end)
    public FeatureSpec[] features;
    public float parTime;     // seconds, for the "finish under" star
}

/// <summary>The 15 levels in 5 jungle areas (world map), each with its season, adventures and missions.</summary>
public static class LevelDefs
{
    public const int Count = 15;
    public const int LockedAreaStars = 30;

    public static readonly AreaDef[] Areas =
    {
        new AreaDef { name = "BAMBOO FOREST" },
        new AreaDef { name = "RIVER VALLEY" },
        new AreaDef { name = "MONKEY WOODS" },
        new AreaDef { name = "TEMPLE RUINS" },
        new AreaDef { name = "WATERFALL CLIFFS", starsNeeded = LockedAreaStars },
    };

    // season dot on each level, as in the world map mock-up
    static readonly Season[] seasons =
    {
        Season.Summer, Season.Summer, Season.Summer,
        Season.Monsoon, Season.Monsoon, Season.Monsoon,
        Season.Winter, Season.Winter, Season.Summer,
        Season.Monsoon, Season.Winter, Season.Summer,
        Season.Monsoon, Season.Winter, Season.Summer,
    };

    static readonly float[] lengths = { 600, 700, 800, 800, 900, 1000, 900, 1000, 1100, 1000, 1100, 550, 1000, 1150, 800 };

    static FeatureSpec F(FeatureType t, float m) => new FeatureSpec(t, m);

    static readonly FeatureSpec[][] features =
    {
        new[] { F(FeatureType.WoodBridge, 300) },
        new[] { F(FeatureType.Monkeys, 200), F(FeatureType.WoodBridge, 450) },
        new[] { F(FeatureType.River, 250), F(FeatureType.WoodBridge, 550) },
        new[] { F(FeatureType.River, 200), F(FeatureType.RopeBridge, 500) },
        new[] { F(FeatureType.River, 200), F(FeatureType.River, 450), F(FeatureType.RopeBridge, 700) },
        new[] { F(FeatureType.RopeBridge, 300), F(FeatureType.River, 600), F(FeatureType.Monkeys, 800) },
        new[] { F(FeatureType.Monkeys, 200), F(FeatureType.RopeBridge, 450), F(FeatureType.Monkeys, 700) },
        new[] { F(FeatureType.Monkeys, 250), F(FeatureType.River, 500), F(FeatureType.RopeBridge, 750) },
        new[] { F(FeatureType.Monkeys, 200), F(FeatureType.WoodBridge, 450), F(FeatureType.Monkeys, 650), F(FeatureType.RopeBridge, 850) },
        new[] { F(FeatureType.Temple, 350), F(FeatureType.RopeBridge, 700) },
        new[] { F(FeatureType.River, 250), F(FeatureType.Temple, 550), F(FeatureType.WoodBridge, 850) },
        new[] { F(FeatureType.Temple, 250), F(FeatureType.Spiral, 550) },
        new[] { F(FeatureType.Waterfall, 350), F(FeatureType.RopeBridge, 700) },
        new[] { F(FeatureType.River, 200), F(FeatureType.Waterfall, 500), F(FeatureType.Monkeys, 750), F(FeatureType.Temple, 950) },
        new[] { F(FeatureType.Waterfall, 300), F(FeatureType.RopeBridge, 550), F(FeatureType.Spiral, 800) },
    };

    static LevelDef[] all;

    public static LevelDef Get(int number)
    {
        if (all == null)
        {
            all = new LevelDef[Count];
            for (int i = 0; i < Count; i++)
            {
                float len = lengths[i];
                foreach (var f in features[i]) if (f.type == FeatureType.Spiral) len += SpiralLengthEstimate;
                all[i] = new LevelDef
                {
                    number = i + 1,
                    area = i / 3,
                    season = seasons[i],
                    length = lengths[i],
                    features = features[i],
                    parTime = Mathf.Ceil(len / 8f / 10f) * 10f,   // about 29 km/h on average
                };
            }
        }
        return all[Mathf.Clamp(number, 1, Count) - 1];
    }

    /// <summary>Rough length of the three rounds up the mountain (the real one is measured by TrailPath).</summary>
    public const float SpiralLengthEstimate = 790f;

    public static int AreaStarsNeeded(int area) => Areas[Mathf.Clamp(area, 0, Areas.Length - 1)].starsNeeded;

    public static string FeatureName(FeatureType t)
    {
        switch (t)
        {
            case FeatureType.WoodBridge: return "BRIDGE";
            case FeatureType.RopeBridge: return "ROPE BRIDGE";
            case FeatureType.River: return "RIVER";
            case FeatureType.Monkeys: return "MONKEYS";
            case FeatureType.Temple: return "TEMPLE";
            case FeatureType.Waterfall: return "WATERFALL";
            default: return "MOUNTAIN";
        }
    }

    /// <summary>Adventures on the Trail Race track.</summary>
    public static List<FeatureSpec> TrailRaceFeatures() => new List<FeatureSpec>
    {
        F(FeatureType.River, 250), F(FeatureType.WoodBridge, 500), F(FeatureType.Monkeys, 750), F(FeatureType.RopeBridge, 950),
    };
}
