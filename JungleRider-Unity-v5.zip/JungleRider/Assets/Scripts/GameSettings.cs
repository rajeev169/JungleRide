using UnityEngine;

public enum ControlMode { Buttons = 0, Tilt = 1, Joystick = 2 }

/// <summary>Player choices and records, saved on the phone with PlayerPrefs.</summary>
public static class GameSettings
{
    public static ControlMode Control
    {
        get => (ControlMode)PlayerPrefs.GetInt("controls", (int)ControlMode.Buttons);
        set { PlayerPrefs.SetInt("controls", (int)value); PlayerPrefs.Save(); }
    }

    /// <summary>Tilt steering sensitivity, 0.5 .. 2.0</summary>
    public static float TiltSensitivity
    {
        get => PlayerPrefs.GetFloat("tiltSens", 1f);
        set { PlayerPrefs.SetFloat("tiltSens", Mathf.Clamp(value, 0.5f, 2f)); PlayerPrefs.Save(); }
    }

    /// <summary>Best time in seconds (0 = none yet).</summary>
    public static float BestTrailTime
    {
        get => PlayerPrefs.GetFloat("bestTrail", 0f);
        set { PlayerPrefs.SetFloat("bestTrail", value); PlayerPrefs.Save(); }
    }

    /// <summary>Best endless distance in metres.</summary>
    public static float BestEndless
    {
        get => PlayerPrefs.GetFloat("bestEndless", 0f);
        set { PlayerPrefs.SetFloat("bestEndless", value); PlayerPrefs.Save(); }
    }

    /// <summary>Highest unlocked level (1 = only level 1).</summary>
    public static int LevelsUnlocked
    {
        get => Mathf.Clamp(PlayerPrefs.GetInt("levelsUnlocked", 1), 1, TrackConfig.LevelCount);
        set { PlayerPrefs.SetInt("levelsUnlocked", Mathf.Clamp(value, 1, TrackConfig.LevelCount)); PlayerPrefs.Save(); }
    }

    public static float BestLevelTime(int level) => PlayerPrefs.GetFloat("bestLevel" + level, 0f);

    public static void SetBestLevelTime(int level, float seconds)
    {
        PlayerPrefs.SetFloat("bestLevel" + level, seconds);
        PlayerPrefs.Save();
    }

    public static string FormatTime(float seconds)
    {
        if (seconds <= 0f) return "--:--.-";
        int m = (int)(seconds / 60f);
        float s = seconds - m * 60;
        return string.Format("{0}:{1:00.0}", m, s);
    }
}
