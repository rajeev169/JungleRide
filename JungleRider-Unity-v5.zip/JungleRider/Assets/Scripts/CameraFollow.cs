using UnityEngine;

/// <summary>Chase camera behind the bike. In the menu it slowly circles the bike instead.</summary>
public class CameraFollow : MonoBehaviour
{
    public Transform target;
    public bool orbit;
    public float distance = 5.5f;
    public float height = 2.3f;
    public float orbitDistance = 4.2f, orbitHeight = 1.6f;   // bigger for the summit view
    float orbitAngle;
    Vector3 smoothForward = Vector3.forward;

    public void SnapBehind()
    {
        if (!target) return;
        smoothForward = Flat(target.forward);
        transform.position = target.position - smoothForward * distance + Vector3.up * height;
        transform.LookAt(target.position + Vector3.up * 1f + smoothForward * 2f);
    }

    static Vector3 Flat(Vector3 v)
    {
        v.y = 0f;
        return v.sqrMagnitude < 1e-4f ? Vector3.forward : v.normalized;
    }

    void LateUpdate()
    {
        if (!target) return;
        float dt = Time.unscaledDeltaTime;

        if (orbit)
        {
            orbitAngle += dt * 12f;
            Vector3 offset = Quaternion.Euler(0, orbitAngle, 0) * new Vector3(0, orbitHeight, -orbitDistance);
            transform.position = Vector3.Lerp(transform.position, target.position + offset, dt * 2f);
            transform.LookAt(target.position + Vector3.up * 0.8f);
            return;
        }

        smoothForward = Vector3.Slerp(smoothForward, Flat(target.forward), dt * 3f);
        Vector3 desired = target.position - smoothForward * distance + Vector3.up * height;

        // keep the camera above the ground / out of the banks
        // (only looks a few metres up, so the mountain road above does not lift the camera)
        if (Physics.Raycast(desired + Vector3.up * 8f, Vector3.down, out RaycastHit hit, 16f, ~(1 << 2), QueryTriggerInteraction.Ignore))
            desired.y = Mathf.Max(desired.y, hit.point.y + 1.2f);

        transform.position = Vector3.Lerp(transform.position, desired, dt * 6f);
        transform.LookAt(target.position + Vector3.up * 1f + smoothForward * 2f);
    }
}
