using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// One adventure on the trail, in path indices. Between <see cref="start"/> and <see cref="end"/> the trail
/// is straight and flat; <see cref="gapStart"/>..<see cref="gapEnd"/> is the special part
/// (the gorge under a bridge, the river water, the waterfall gap, the temple, ...).
/// </summary>
public class Zone
{
    public FeatureType type;
    public int start, gapStart, gapEnd, end;
    public int id;
    public float baseY;
    public bool Contains(int i) => i >= start && i <= end;
    public bool InGap(int i) => i >= gapStart && i <= gapEnd;
    public bool IsGorge => type == FeatureType.WoodBridge || type == FeatureType.RopeBridge || type == FeatureType.Waterfall;
}

/// <summary>A mango or gem placed along the trail.</summary>
public struct PickupSpot
{
    public int id;
    public bool gem;
    public float index;     // fractional path index
    public float lateral;
    public float lift;      // metres above the trail (or above the ground when onGround)
    public bool onGround;
}

/// <summary>
/// The centre line of the jungle trail: one point every 4 m, generated on demand from noise,
/// so the same seed always gives the same trail and endless mode can keep going forever.
/// Adventures (bridges, river, temple, waterfall, the spiral mountain road) shape the trail around them.
/// </summary>
public class TrailPath
{
    public const float SegLen = 4f;
    public const int StartIndex = 4;          // the bike starts on this point
    public const float TrailHalfWidth = 3.4f; // ridable dirt strip
    public const float GorgeDepth = 24f;
    public const float WaterfallDrop = 3f;
    public const float RiverDip = 0.5f;

    // Spiral mountain: the road circles round 3 times, moving 12 m inwards and 18 m up each round.
    public const float SpiralR0 = 60f, SpiralStepIn = 12f, SpiralRise = 18f, SpiralRounds = 3f;

    // Cross-section of the ground: lateral offset (m) -> height above the trail centre (m).
    // The banks rise steeply so you stay in the jungle corridor.
    public static readonly float[] Offsets = { -34f, -20f, -11f, -6f, -3.4f, -1.5f, 0f, 1.5f, 3.4f, 6f, 11f, 20f, 34f };
    static readonly float[] Heights = { 12f, 7.5f, 3.2f, 0.9f, 0.08f, -0.04f, -0.06f, -0.04f, 0.08f, 0.9f, 3.2f, 7.5f, 12f };

    readonly TrackConfig cfg;
    readonly List<Vector3> pts = new List<Vector3>();
    readonly List<float> headings = new List<float>();
    readonly List<Zone> zones = new List<Zone>();
    int finishIndex;
    int zonesGeneratedTo;

    // spiral
    Zone spiral;
    int spiralSegs;
    readonly List<int> spiralRounds = new List<int>();
    Vector3 spiralCentre;
    float spiralH0, spiralY0;
    readonly List<float> spiralTheta = new List<float>();

    public TrackConfig Config => cfg;
    public IReadOnlyList<Zone> Zones => zones;
    public bool HasSpiral => spiral != null;
    public Zone SpiralZone => spiral;
    public Vector3 SpiralCentre { get { if (spiral != null) Point(spiral.start); return spiralCentre; } }
    public float SummitY => spiralY0 + SpiralRise * SpiralRounds;

    public TrailPath(TrackConfig config)
    {
        cfg = config;
        pts.Add(Vector3.zero);
        headings.Add(0f);
        finishIndex = StartIndex + Mathf.CeilToInt(cfg.length / SegLen);

        if (!cfg.endless && cfg.features != null)
        {
            var list = new List<FeatureSpec>(cfg.features);
            list.Sort((a, b) => a.at.CompareTo(b.at));
            foreach (var f in list) AddZone(f.type, StartIndex + Mathf.RoundToInt(f.at / SegLen));
            if (spiral != null)
            {
                // count the segments of the three rounds (same steps as the generator below)
                float th = 0f;
                spiralSegs = 0;
                int nextRound = 1;
                while (th < Mathf.PI * 2f * SpiralRounds)
                {
                    th += SegLen / SpiralRadius(th);
                    spiralSegs++;
                    if (th >= Mathf.PI * 2f * nextRound && nextRound < SpiralRounds)
                    {
                        spiralRounds.Add(spiral.start + spiralSegs);
                        nextRound++;
                    }
                }
                finishIndex = spiral.start + spiralSegs;
                spiral.gapEnd = finishIndex;
                cfg.length = (finishIndex - StartIndex) * SegLen;
            }
        }
    }

    /// <summary>Index of the finish line (int.MaxValue in endless mode).</summary>
    public int FinishIndex => cfg.endless ? int.MaxValue : finishIndex;

    /// <summary>Path indices where each new round of the mountain road starts (checkpoints).</summary>
    public IReadOnlyList<int> SpiralRoundStarts => spiralRounds;

    void AddZone(FeatureType type, int a)
    {
        var z = new Zone { type = type, id = zones.Count };
        switch (type)
        {
            case FeatureType.WoodBridge: z.start = a - 4; z.gapStart = a; z.gapEnd = a + 6; z.end = a + 9; break;
            case FeatureType.RopeBridge: z.start = a - 4; z.gapStart = a; z.gapEnd = a + 8; z.end = a + 11; break;
            case FeatureType.River: z.start = a - 3; z.gapStart = a; z.gapEnd = a + 2; z.end = a + 5; break;
            case FeatureType.Monkeys: z.start = a - 2; z.gapStart = a + 3; z.gapEnd = a + 3; z.end = a + 6; break;
            case FeatureType.Temple: z.start = a - 2; z.gapStart = a; z.gapEnd = a + 8; z.end = a + 10; break;
            case FeatureType.Waterfall: z.start = a - 6; z.gapStart = a; z.gapEnd = a + 1; z.end = a + 6; break;
            default: z.start = a; z.gapStart = a; z.gapEnd = int.MaxValue / 4; z.end = int.MaxValue / 4; spiral = z; break;
        }
        zones.Add(z);
    }

    /// <summary>Endless mode: keeps adding random adventures ahead of the rider.</summary>
    void EnsureZones(int upTo)
    {
        if (!cfg.endless) return;
        while (zonesGeneratedTo < upTo + 80)
        {
            var rnd = new System.Random(cfg.seed * 31 + zones.Count * 7919);
            int last = zones.Count > 0 ? zones[zones.Count - 1].end : StartIndex + 40;
            int a = last + 80 + rnd.Next(60);
            var type = (FeatureType)rnd.Next(6); // everything except the spiral mountain
            AddZone(type, a);
            zonesGeneratedTo = a;
        }
    }

    Zone lastZone;
    public Zone ZoneAt(int i)
    {
        EnsureZones(i);
        if (lastZone != null && lastZone.Contains(i)) return lastZone;
        for (int k = 0; k < zones.Count; k++)
            if (zones[k].Contains(i)) { lastZone = zones[k]; return lastZone; }
        return null;
    }

    public bool InSpiral(int i) => spiral != null && i >= spiral.start;

    static float SpiralRadius(float th) => SpiralR0 - SpiralStepIn * Mathf.Min(th, Mathf.PI * 2f * SpiralRounds) / (Mathf.PI * 2f);

    public Vector3 Point(int i)
    {
        if (i < 0) i = 0;
        Ensure(i + 1);
        return pts[i];
    }

    /// <summary>Point between two path indices (fractional index).</summary>
    public Vector3 PointAt(float idx)
    {
        int i = Mathf.FloorToInt(idx);
        return Vector3.Lerp(Point(i), Point(i + 1), idx - i);
    }

    void Ensure(int i)
    {
        while (pts.Count <= i) Next();
    }

    void Next()
    {
        int i = pts.Count;
        Vector3 prev = pts[i - 1];
        float prevHeading = headings[i - 1];
        var z = ZoneAt(i);

        // ---------- spiral mountain road ----------
        if (z != null && z.type == FeatureType.Spiral)
        {
            if (i == z.start)
            {
                spiralH0 = prevHeading;
                float r0 = prevHeading * Mathf.Deg2Rad;
                Vector3 p0 = prev + new Vector3(Mathf.Sin(r0), 0f, Mathf.Cos(r0)) * SegLen;
                p0.y = prev.y;
                spiralY0 = prev.y;
                spiralCentre = p0 + new Vector3(Mathf.Cos(r0), 0f, -Mathf.Sin(r0)) * SpiralR0;
                spiralTheta.Add(0f);
                pts.Add(p0);
                headings.Add(prevHeading);
                return;
            }
            float thPrev = spiralTheta[spiralTheta.Count - 1];
            float th = thPrev + SegLen / SpiralRadius(thPrev);
            spiralTheta.Add(th);
            float r = SpiralRadius(th);
            float h = spiralH0 * Mathf.Deg2Rad + th;
            Vector3 p = spiralCentre + new Vector3(-Mathf.Cos(h), 0f, Mathf.Sin(h)) * r;
            p.y = spiralY0 + SpiralRise * Mathf.Min(th, Mathf.PI * 2f * SpiralRounds) / (Mathf.PI * 2f);
            pts.Add(p);
            headings.Add(h * Mathf.Rad2Deg);
            return;
        }

        float heading;
        float y;
        if (z != null)
        {
            // adventures: straight and flat (a little lower in the river, much lower after the waterfall jump)
            if (i == z.start) z.baseY = prev.y;
            heading = prevHeading;
            y = z.baseY;
            if (z.type == FeatureType.River && z.InGap(i)) y -= RiverDip;
            if (z.type == FeatureType.Waterfall && i >= z.gapStart) y -= WaterfallDrop;
        }
        else
        {
            float d = cfg.DifficultyAt(i * SegLen);
            float curv = cfg.curviness + (1f - cfg.curviness) * d * 0.6f;
            float hill = cfg.hilliness + (1f - cfg.hilliness) * d * 0.6f;

            // 0 = keep straight & flat (start area, after the finish), 1 = full noise
            float shape = Mathf.Clamp01((i - 10) / 10f);
            if (!cfg.endless) shape *= Mathf.Clamp01((finishIndex - 4 - i) / 10f);

            float s = cfg.seed * 0.0137f;
            float n1 = Mathf.PerlinNoise(s + 0.5f, i * 0.035f) * 2f - 1f;
            float n2 = Mathf.PerlinNoise(s + 3.3f, i * 0.11f) * 2f - 1f;
            float turn = (n1 * 0.75f + n2 * 0.25f) * (2f + 7f * curv) * shape;
            // keeps the trail heading forward (the spiral leaves big headings, so wrap first)
            float ph = Mathf.DeltaAngle(0f, prevHeading);
            heading = Mathf.Clamp(ph + turn - ph * 0.03f, -65f, 65f);

            float big = (Mathf.PerlinNoise(s + 7.7f, i * 0.018f) * 2f - 1f) * (4f + 16f * hill);
            float small = (Mathf.PerlinNoise(s + 1.1f, i * 0.07f) * 2f - 1f) * (0.5f + 2.5f * hill);
            float targetY = Mathf.Lerp(prev.y, big + small, shape);
            float maxStep = SegLen * (0.12f + 0.12f * hill);
            y = prev.y + Mathf.Clamp(targetY - prev.y, -maxStep, maxStep);
        }

        float rad = heading * Mathf.Deg2Rad;
        Vector3 dir = new Vector3(Mathf.Sin(rad), 0f, Mathf.Cos(rad));
        Vector3 pt = prev + dir * SegLen;
        pt.y = y;
        pts.Add(pt);
        headings.Add(heading);
    }

    /// <summary>Flat (horizontal) direction of travel at point i.</summary>
    public Vector3 Forward(int i)
    {
        Vector3 a = Point(i + 1) - Point(Mathf.Max(0, i - 1));
        a.y = 0f;
        return a.sqrMagnitude < 1e-6f ? Vector3.forward : a.normalized;
    }

    public Vector3 Right(int i)
    {
        Vector3 f = Forward(i);
        return new Vector3(f.z, 0f, -f.x);
    }

    /// <summary>Organic bumps on the banks (not on the dirt strip).</summary>
    public static float BankNoise(Vector3 worldXZ, float lateral)
    {
        float edge = Mathf.Clamp01((Mathf.Abs(lateral) - 3.4f) / 8f);
        float n = Mathf.PerlinNoise(worldXZ.x * 0.08f + 100f, worldXZ.z * 0.08f + 100f) * 2f - 1f;
        float n2 = Mathf.PerlinNoise(worldXZ.x * 0.25f + 50f, worldXZ.z * 0.25f + 50f) * 2f - 1f;
        return (n * 2.2f + n2 * 0.5f) * edge;
    }

    public static float ProfileHeight(float lateral)
    {
        if (lateral <= Offsets[0]) return Heights[0];
        for (int k = 1; k < Offsets.Length; k++)
        {
            if (lateral <= Offsets[k])
            {
                float t = (lateral - Offsets[k - 1]) / (Offsets[k] - Offsets[k - 1]);
                return Mathf.Lerp(Heights[k - 1], Heights[k], t);
            }
        }
        return Heights[Heights.Length - 1];
    }

    /// <summary>World position of the ground at point i, offset sideways by <paramref name="lateral"/> metres.</summary>
    public Vector3 Surface(int i, float lateral)
    {
        if (i < 0) i = 0;
        Ensure(i + 1);
        if (InSpiral(i)) return SpiralSurface(i, lateral);
        Vector3 c = pts[i];
        Vector3 p = c + Right(i) * lateral;
        float h = ProfileHeight(lateral) + BankNoise(p, lateral);
        var z = ZoneAt(i);
        if (z != null && z.InGap(i))
        {
            if (z.IsGorge)
                h -= GorgeDepth * (1f - Mathf.SmoothStep(0f, 1f, (Mathf.Abs(lateral) - 16f) / 16f));
            else if (z.type == FeatureType.River)
                h = Mathf.Min(h, -0.05f);   // river channel cut through the banks
        }
        p.y = c.y + h;
        return p;
    }

    /// <summary>
    /// The mountain is a cone; the road is a flat shelf cut into it. Inside (right) is the rock wall,
    /// outside (left) the drop to the round below. Each round only draws its own strip of the cone.
    /// </summary>
    Vector3 SpiralSurface(int i, float lateral)
    {
        float th = SpiralThetaAt(i);
        bool firstRound = th < Mathf.PI * 2f;
        bool topRound = th >= Mathf.PI * 4f;
        float r = SpiralRadius(th);
        float lat = lateral;
        if (!firstRound && lat < -6f) lat = -6f;   // the round below covers that
        if (!topRound && lat > 6f) lat = 6f;       // the round above covers that
        if (lat > r - 1f) lat = r - 1f;            // never past the centre
        Vector3 c = pts[i];
        Vector3 p = c + Right(i) * lat;
        float h = Mathf.Abs(lat) <= TrailHalfWidth ? ProfileHeight(lat) : 1.5f * lat;
        if (firstRound && lat < 0f) h = Mathf.Max(h, spiralY0 - 0.5f - c.y + (lat < -8f ? BankNoise(p, lat + 4f) * 0.5f : 0f));
        if (topRound && lat > 0f) h = Mathf.Min(h, SummitY + 6f - c.y);
        p.y = c.y + h;
        return p;
    }

    float SpiralThetaAt(int i)
    {
        int k = i - spiral.start;
        if (k < 0) return 0f;
        Ensure(i);
        return spiralTheta[Mathf.Min(k, spiralTheta.Count - 1)];
    }

    /// <summary>A safe place to put the bike back: never above a gorge or the waterfall gap.</summary>
    public int SafeIndex(int i)
    {
        var z = ZoneAt(i);
        if (z != null && z.IsGorge && i >= z.gapStart - 1 && i <= z.gapEnd + 1) return Mathf.Max(StartIndex, z.start - (z.type == FeatureType.Waterfall ? 4 : 0));
        return Mathf.Max(StartIndex, i);
    }

    /// <summary>Closest path index to a world position, searching near a previous guess.</summary>
    public int ClosestIndex(Vector3 pos, int guess)
    {
        int best = Mathf.Max(0, guess);
        float bestD = float.MaxValue;
        for (int i = Mathf.Max(0, guess - 8); i <= guess + 14; i++)
        {
            Vector3 p = Point(i);
            float dx = p.x - pos.x, dz = p.z - pos.z;
            float dd = dx * dx + dz * dz;
            if (dd < bestD) { bestD = dd; best = i; }
        }
        return best;
    }

    /// <summary>Fractional progress along the trail (index units) near index i.</summary>
    public float Progress(Vector3 pos, int i)
    {
        Vector3 a = Point(i), b = Point(i + 1);
        Vector3 ab = b - a; ab.y = 0f;
        Vector3 ap = pos - a; ap.y = 0f;
        return i + Mathf.Clamp(Vector3.Dot(ap, ab) / Mathf.Max(0.01f, ab.sqrMagnitude), -1f, 1f);
    }

    public float LateralOffset(Vector3 pos, int i)
    {
        Vector3 d = pos - Point(i);
        d.y = 0f;
        return Vector3.Dot(d, Right(i));
    }

    // ------------------------------------------------------------------ mangoes & gems
    const int MangoEvery = 20;

    static int Hash(int a, int b)
    {
        unchecked
        {
            int h = a * 73856093 ^ b * 19349663;
            h ^= h >> 13; h *= 0x5bd1e995; h ^= h >> 15;
            return h & 0x7fffffff;
        }
    }

    /// <summary>All mangoes and gems whose spot lies in [i0, i1).</summary>
    public void PickupsIn(int i0, int i1, List<PickupSpot> list)
    {
        int last = cfg.endless ? int.MaxValue : finishIndex - 3;
        for (int i = Mathf.Max(i0, StartIndex + 8); i < i1 && i < last; i++)
        {
            int rel = i - StartIndex - 8;
            var z = ZoneAt(i);
            if (rel % MangoEvery == 0)
            {
                if (z != null && z.type == FeatureType.Waterfall)
                {
                    // an arc of mangoes along the jump
                    Point(z.gapStart + 4);
                    for (int k = 0; k < 5; k++)
                    {
                        float t = k / 4f;
                        float idx = z.gapStart - 1.2f + t * 4.2f;
                        float y = z.baseY + 1.4f + 7.2f * t * (1f - t) - 2.8f * t * t;
                        list.Add(new PickupSpot { id = i * 8 + k, index = idx, lateral = 0f, lift = y - PointAt(idx).y });
                    }
                }
                else
                {
                    float lane = (Hash(cfg.seed, i) % 5 - 2) * 0.8f;
                    if (z != null && z.type == FeatureType.RopeBridge) lane = 0f;
                    if (z != null && z.type == FeatureType.WoodBridge) lane = Mathf.Clamp(lane, -1f, 1f);
                    for (int k = 0; k < 5; k++)
                        list.Add(new PickupSpot { id = i * 8 + k, index = i + k * 0.5f, lateral = lane + 0.35f * Mathf.Sin(k * 1.3f), lift = 0.75f });
                }
            }
            if (z != null && z.type == FeatureType.Temple && i == z.start + 6)
                list.Add(new PickupSpot { id = i * 8 + 5, gem = true, index = i + 0.3f, lateral = -6.6f, lift = 0.7f, onGround = true });  // hidden behind a pillar
            if (z != null && z.type == FeatureType.Waterfall && i == z.gapStart)
            {
                Point(z.gapStart + 4);
                list.Add(new PickupSpot { id = i * 8 + 6, gem = true, index = i + 0.4f, lateral = 0f, lift = z.baseY + 2.6f - PointAt(i + 0.4f).y }); // high over the gap
            }
            if (IsBonusGemIndex(i) && z == null)
                list.Add(new PickupSpot { id = i * 8 + 7, gem = true, index = i, lateral = 4.6f, lift = 0.7f, onGround = true }); // off the trail
        }
    }

    bool IsBonusGemIndex(int i)
    {
        if (cfg.endless) return (i - StartIndex) % 150 == 75;
        int mid = StartIndex + (Mathf.Min(finishIndex, spiral != null ? spiral.start : finishIndex) - StartIndex) / 2;
        // first index at or after the middle that is not inside an adventure
        for (int k = mid; k < mid + 40; k++)
            if (ZoneAt(k) == null) return i == k;
        return false;
    }

    /// <summary>World position of a pickup.</summary>
    public Vector3 PickupPosition(PickupSpot s)
    {
        int i = Mathf.FloorToInt(s.index);
        if (s.onGround)
            return Surface(i, s.lateral) + Vector3.up * s.lift;
        Vector3 c = PointAt(s.index);
        return c + Right(i) * s.lateral + Vector3.up * s.lift;
    }

    /// <summary>How many mangoes this (non-endless) trail has.</summary>
    public int CountMangoes()
    {
        var list = new List<PickupSpot>();
        PickupsIn(0, finishIndex, list);
        int n = 0;
        foreach (var s in list) if (!s.gem) n++;
        return n;
    }
}
