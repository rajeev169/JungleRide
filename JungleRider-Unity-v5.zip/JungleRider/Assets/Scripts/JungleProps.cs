using System.Collections.Generic;
using UnityEngine;

/// <summary>Creates (once) and hands out the low-poly jungle meshes: trees, bushes, rocks, logs, ramps, gates.</summary>
public static class JungleProps
{
    public enum Kind { Palm, Broadleaf, Giant, Bush, Fern, Rock, Log, Ramp, CheckpointGate, FinishGate, Puddle }

    static readonly Dictionary<Kind, Mesh[]> cache = new Dictionary<Kind, Mesh[]>();
    static Material material;

    public static readonly Color Bark = new Color(0.36f, 0.25f, 0.16f);
    public static readonly Color DarkBark = new Color(0.25f, 0.18f, 0.12f);
    public static readonly Color Leaf = new Color(0.16f, 0.45f, 0.14f);
    public static readonly Color LeafLight = new Color(0.32f, 0.6f, 0.18f);
    public static readonly Color LeafDark = new Color(0.08f, 0.3f, 0.1f);
    public static readonly Color Stone = new Color(0.45f, 0.45f, 0.42f);
    public static readonly Color Wood = new Color(0.62f, 0.44f, 0.24f);

    public static Material Material
    {
        get
        {
            if (material == null)
            {
                var shader = Shader.Find("JungleRider/VertexLit");
                if (shader == null) shader = Shader.Find("Standard");
                material = new Material(shader) { name = "JungleVertexLit", enableInstancing = true };
            }
            return material;
        }
    }

    public static Mesh Get(Kind kind, int variant)
    {
        if (!cache.TryGetValue(kind, out var arr))
        {
            arr = new Mesh[3];
            for (int i = 0; i < arr.Length; i++) arr[i] = Build(kind, new System.Random(1000 + (int)kind * 17 + i));
            cache[kind] = arr;
        }
        return arr[Mathf.Abs(variant) % arr.Length];
    }

    /// <summary>Spawns a prop as a child of <paramref name="parent"/>.</summary>
    public static GameObject Spawn(Kind kind, int variant, Transform parent, Vector3 pos, Quaternion rot, float scale = 1f)
    {
        var go = new GameObject(kind.ToString());
        go.transform.SetParent(parent, false);
        go.transform.SetPositionAndRotation(pos, rot);
        go.transform.localScale = Vector3.one * scale;
        go.AddComponent<MeshFilter>().sharedMesh = Get(kind, variant);
        var mr = go.AddComponent<MeshRenderer>();
        mr.sharedMaterial = Material;
        bool smallProp = kind == Kind.Fern || kind == Kind.Bush;
        mr.shadowCastingMode = smallProp ? UnityEngine.Rendering.ShadowCastingMode.Off : UnityEngine.Rendering.ShadowCastingMode.On;
        return go;
    }

    static Color Vary(Color c, System.Random r, float amount = 0.12f)
    {
        float k = 1f + ((float)r.NextDouble() - 0.5f) * 2f * amount;
        return new Color(Mathf.Clamp01(c.r * k), Mathf.Clamp01(c.g * k), Mathf.Clamp01(c.b * k), 1f);
    }

    static Mesh Build(Kind kind, System.Random r)
    {
        var mb = new MeshBuilder();
        switch (kind)
        {
            case Kind.Palm: BuildPalm(mb, r); break;
            case Kind.Broadleaf: BuildBroadleaf(mb, r); break;
            case Kind.Giant: BuildGiant(mb, r); break;
            case Kind.Bush: BuildBush(mb, r); break;
            case Kind.Fern: BuildFern(mb, r); break;
            case Kind.Rock: mb.Blob(new Vector3(0, 0.25f, 0), new Vector3(0.8f, 0.55f, 0.7f), Vary(Stone, r), r, 3, 6, 0.25f); break;
            case Kind.Log: BuildLog(mb, r); break;
            case Kind.Ramp: BuildRamp(mb); break;
            case Kind.CheckpointGate: BuildGate(mb, new Color(1f, 0.78f, 0.1f), false); break;
            case Kind.FinishGate: BuildGate(mb, Color.white, true); break;
            case Kind.Puddle: BuildPuddle(mb, r); break;
        }
        return mb.ToMesh(kind.ToString());
    }

    static void BuildPalm(MeshBuilder mb, System.Random r)
    {
        float h = 7f + (float)r.NextDouble() * 4f;
        float bend = 0.6f + (float)r.NextDouble() * 1.2f;
        Vector3 prev = Vector3.zero;
        int segs = 7;
        for (int i = 1; i <= segs; i++)
        {
            float t = i / (float)segs;
            Vector3 p = new Vector3(bend * t * t, h * t, 0f);
            mb.Cylinder(prev, p, Mathf.Lerp(0.28f, 0.16f, t - 1f / segs), Mathf.Lerp(0.28f, 0.16f, t), 6, i % 2 == 0 ? Bark : DarkBark, false);
            prev = p;
        }
        Vector3 top = prev;
        int leaves = 8;
        for (int i = 0; i < leaves; i++)
        {
            float ang = i * Mathf.PI * 2f / leaves + (float)r.NextDouble() * 0.3f;
            Vector3 dir = new Vector3(Mathf.Cos(ang), 0f, Mathf.Sin(ang));
            Vector3 side = Vector3.Cross(Vector3.up, dir) * 0.45f;
            float len = 3.2f + (float)r.NextDouble() * 1.2f;
            Color col = Vary(i % 2 == 0 ? Leaf : LeafLight, r);
            // three drooping sections
            Vector3 a = top;
            for (int s = 1; s <= 3; s++)
            {
                float t = s / 3f;
                Vector3 b = top + dir * len * t + Vector3.up * (0.6f * t - 1.8f * t * t);
                float w0 = Mathf.Lerp(0.2f, 1f, (s - 1) / 3f) * (s == 1 ? 0.5f : 1f);
                float w1 = s == 3 ? 0.05f : 1f;
                mb.DoubleQuad(a - side * w0, a + side * w0, b + side * w1, b - side * w1, col);
                a = b;
            }
        }
        mb.Blob(top, new Vector3(0.35f, 0.3f, 0.35f), new Color(0.35f, 0.28f, 0.12f), r, 3, 5, 0.1f); // coconuts
    }

    static void BuildBroadleaf(MeshBuilder mb, System.Random r)
    {
        float h = 4f + (float)r.NextDouble() * 2.5f;
        mb.Cylinder(Vector3.zero, new Vector3(0, h, 0), 0.35f, 0.22f, 7, Bark);
        mb.Cylinder(new Vector3(0, h * 0.6f, 0), new Vector3(1.4f, h * 0.95f, 0.3f), 0.15f, 0.08f, 5, Bark);
        int blobs = 4 + r.Next(3);
        for (int i = 0; i < blobs; i++)
        {
            Vector3 c = new Vector3(((float)r.NextDouble() - 0.5f) * 3f, h + (float)r.NextDouble() * 1.8f, ((float)r.NextDouble() - 0.5f) * 3f);
            float s = 1.6f + (float)r.NextDouble() * 1.2f;
            mb.Blob(c, new Vector3(s, s * 0.75f, s), Vary(i % 2 == 0 ? Leaf : LeafDark, r), r);
        }
    }

    static void BuildGiant(MeshBuilder mb, System.Random r)
    {
        float h = 11f + (float)r.NextDouble() * 4f;
        mb.Cylinder(Vector3.zero, new Vector3(0, h, 0), 0.75f, 0.45f, 8, DarkBark);
        for (int i = 0; i < 4; i++) // buttress roots
        {
            float a = i * Mathf.PI / 2f + 0.4f;
            Vector3 d = new Vector3(Mathf.Cos(a), 0, Mathf.Sin(a));
            mb.Box(d * 0.9f + Vector3.up * 0.7f, new Vector3(0.18f, 1.4f, 1.4f), Quaternion.LookRotation(d), Bark);
        }
        for (int i = 0; i < 5; i++)
        {
            Vector3 c = new Vector3(((float)r.NextDouble() - 0.5f) * 5f, h + (float)r.NextDouble() * 1.2f, ((float)r.NextDouble() - 0.5f) * 5f);
            mb.Blob(c, new Vector3(3.2f, 1.6f, 3.2f), Vary(i % 2 == 0 ? LeafDark : Leaf, r), r);
        }
        // hanging vines
        for (int i = 0; i < 4; i++)
        {
            Vector3 top = new Vector3(((float)r.NextDouble() - 0.5f) * 5f, h - 0.5f, ((float)r.NextDouble() - 0.5f) * 5f);
            mb.Cylinder(top, top + Vector3.down * (3f + (float)r.NextDouble() * 4f), 0.05f, 0.04f, 4, LeafDark, false);
        }
    }

    static void BuildBush(MeshBuilder mb, System.Random r)
    {
        int n = 3 + r.Next(2);
        for (int i = 0; i < n; i++)
        {
            Vector3 c = new Vector3(((float)r.NextDouble() - 0.5f) * 1.6f, 0.45f, ((float)r.NextDouble() - 0.5f) * 1.6f);
            float s = 0.6f + (float)r.NextDouble() * 0.5f;
            mb.Blob(c, new Vector3(s, s * 0.8f, s), Vary(i % 2 == 0 ? LeafLight : Leaf, r), r, 3, 6, 0.2f);
        }
    }

    static void BuildFern(MeshBuilder mb, System.Random r)
    {
        int n = 7;
        for (int i = 0; i < n; i++)
        {
            float a = i * Mathf.PI * 2f / n + (float)r.NextDouble() * 0.4f;
            Vector3 d = new Vector3(Mathf.Cos(a), 0, Mathf.Sin(a));
            Vector3 side = Vector3.Cross(Vector3.up, d) * 0.12f;
            float len = 1f + (float)r.NextDouble() * 0.5f;
            Vector3 mid = d * len * 0.5f + Vector3.up * 0.6f;
            Vector3 tip = d * len + Vector3.up * 0.25f;
            Color col = Vary(LeafLight, r);
            mb.DoubleQuad(Vector3.zero - side * 0.3f, Vector3.zero + side * 0.3f, mid + side, mid - side, col);
            mb.DoubleQuad(mid - side, mid + side, tip + side * 0.1f, tip - side * 0.1f, col);
        }
    }

    static void BuildLog(MeshBuilder mb, System.Random r)
    {
        // Lies along the local X axis, length 5 m, radius 0.22 m, centred on origin.
        mb.Cylinder(new Vector3(-2.5f, 0, 0), new Vector3(2.5f, 0, 0), 0.22f, 0.2f, 8, Bark);
        mb.Blob(new Vector3(((float)r.NextDouble() - 0.5f) * 3f, 0.18f, 0), new Vector3(0.5f, 0.12f, 0.25f), LeafDark, r, 2, 5, 0.1f); // moss
    }

    static void BuildRamp(MeshBuilder mb)
    {
        // Wedge: 3.6 m wide (X), 5 m long (Z, rising towards +Z), 1.1 m high. Origin at the low front edge centre.
        float w = 1.8f, l = 5f, h = 1.1f;
        Vector3 a = new Vector3(-w, 0, 0), b = new Vector3(w, 0, 0);
        Vector3 c = new Vector3(w, h, l), d = new Vector3(-w, h, l);
        Vector3 e = new Vector3(w, 0, l), f = new Vector3(-w, 0, l);
        Vector3 inside = new Vector3(0, h * 0.3f, l * 0.6f);
        mb.QuadOut(a, b, c, d, Wood, inside);                    // riding surface
        mb.QuadOut(f, d, c, e, MeshBuilder.Shade(Wood, 0.7f), inside); // back
        mb.TriOut(a, d, f, MeshBuilder.Shade(Wood, 0.85f), inside);    // sides
        mb.TriOut(b, e, c, MeshBuilder.Shade(Wood, 0.85f), inside);
        // planks
        for (int i = 1; i < 5; i++)
        {
            float t = i / 5f;
            mb.Box(new Vector3(0, h * t + 0.02f, l * t), new Vector3(w * 2f, 0.04f, 0.08f), Quaternion.Euler(-Mathf.Atan2(h, l) * Mathf.Rad2Deg, 0, 0), DarkBark);
        }
    }

    static void BuildPuddle(MeshBuilder mb, System.Random r)
    {
        // flat, dark, wet-looking patch of water on the trail
        int n = 16;
        Color water = new Color(0.16f, 0.17f, 0.17f);
        Color rim = new Color(0.22f, 0.17f, 0.11f);
        var pts = new Vector3[n];
        for (int i = 0; i < n; i++)
        {
            float a = i * Mathf.PI * 2f / n;
            float rad = 1f + ((float)r.NextDouble() - 0.5f) * 0.35f;
            pts[i] = new Vector3(Mathf.Cos(a) * rad * 1.3f, 0f, Mathf.Sin(a) * rad * 0.8f);
        }
        Vector3 up = Vector3.up * 5f;
        for (int i = 0; i < n; i++)
        {
            Vector3 a = pts[i], b = pts[(i + 1) % n];
            mb.TriOut(Vector3.zero, a * 0.8f, b * 0.8f, water, -up);
            mb.TriOut(a * 0.8f, a, b, rim, -up);
            mb.TriOut(a * 0.8f, b, b * 0.8f, rim, -up);
        }
    }

    static void BuildGate(MeshBuilder mb, Color banner, bool checkered)
    {
        // Posts at x = +-4.6, banner across the top. Faces along Z.
        mb.Box(new Vector3(-4.6f, 2.2f, 0), new Vector3(0.35f, 4.4f, 0.35f), Quaternion.identity, Wood);
        mb.Box(new Vector3(4.6f, 2.2f, 0), new Vector3(0.35f, 4.4f, 0.35f), Quaternion.identity, Wood);
        if (!checkered)
        {
            mb.Box(new Vector3(0, 4.2f, 0), new Vector3(9.6f, 0.8f, 0.15f), Quaternion.identity, banner);
        }
        else
        {
            int n = 16;
            for (int i = 0; i < n; i++)
                for (int j = 0; j < 2; j++)
                {
                    Color c = (i + j) % 2 == 0 ? Color.white : new Color(0.08f, 0.08f, 0.08f);
                    mb.Box(new Vector3(-4.8f + 9.6f * (i + 0.5f) / n, 3.95f + j * 0.4f, 0), new Vector3(9.6f / n, 0.4f, 0.15f), Quaternion.identity, c);
                }
        }
    }
}
