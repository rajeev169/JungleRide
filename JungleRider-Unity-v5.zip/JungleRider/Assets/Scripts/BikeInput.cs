using UnityEngine;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

/// <summary>
/// Reads the player's controls and turns them into Steer (-1..1), Throttle (0..1) and Brake (0..1).
/// The control type (buttons / tilt / joystick) comes from GameSettings and can be changed in Settings.
/// Keyboard (arrows/WASD + Space) also works for testing in the Unity editor.
/// </summary>
public class BikeInput : MonoBehaviour
{
    public HoldButton left, right, gas, brake;
    public VirtualJoystick joystick;

    public float Steer { get; private set; }
    public float Throttle { get; private set; }
    public float Brake { get; private set; }
    public bool InputActive { get; set; } = true;

    float tiltZero; // calibration: the phone angle that means "straight"

    void OnEnable()
    {
#if ENABLE_INPUT_SYSTEM
        if (Accelerometer.current != null) InputSystem.EnableDevice(Accelerometer.current);
#endif
    }

    /// <summary>Remember the current phone angle as "straight ahead".</summary>
    public void CalibrateTilt() => tiltZero = RawTiltAngle();

    void Update()
    {
        if (!InputActive)
        {
            Steer = Throttle = Brake = 0f;
            return;
        }

        float steer = 0f, thr = 0f, brk = 0f;
        var mode = GameSettings.Control;
        switch (mode)
        {
            case ControlMode.Buttons:
                if (left && left.Pressed) steer -= 1f;
                if (right && right.Pressed) steer += 1f;
                break;
            case ControlMode.Tilt:
                float angle = Mathf.DeltaAngle(tiltZero, RawTiltAngle());
                float sens = GameSettings.TiltSensitivity;
                steer = Mathf.Abs(angle) < 2f ? 0f : Mathf.Clamp(angle * sens / 28f, -1f, 1f);
                break;
            case ControlMode.Joystick:
                if (joystick) steer = joystick.Value.x;
                break;
        }
        if (gas && gas.Pressed) thr = 1f;
        if (brake && brake.Pressed) brk = 1f;

        ReadKeyboard(ref steer, ref thr, ref brk);

        // buttons/keys are on-off, so smooth them a little; analog inputs pass straight through
        bool digital = mode == ControlMode.Buttons || Mathf.Abs(steer) == 1f;
        Steer = digital ? Mathf.MoveTowards(Steer, steer, Time.deltaTime * 4f) : steer;
        Throttle = thr;
        Brake = brk;
    }

    /// <summary>Phone roll angle in degrees (like turning a steering wheel). Positive = turn right.</summary>
    float RawTiltAngle()
    {
        Vector3 a;
#if ENABLE_INPUT_SYSTEM
        if (Accelerometer.current == null) return 0f;
        a = Accelerometer.current.acceleration.ReadValue();
        // The Input System already rotates the values to match the screen orientation by default.
        float gx = a.x, gy = a.y;
#else
        a = Input.acceleration;
        // Old input: values are in portrait device axes. Convert for landscape screens.
        float gx, gy;
        switch (Screen.orientation)
        {
            case ScreenOrientation.LandscapeRight: gx = a.y; gy = -a.x; break;
            case ScreenOrientation.Portrait: gx = a.x; gy = a.y; break;
            default: /* LandscapeLeft */ gx = -a.y; gy = a.x; break;
        }
#endif
        if (Mathf.Abs(gx) < 0.0001f && Mathf.Abs(gy) < 0.0001f) return 0f;
        return Mathf.Atan2(gx, -gy) * Mathf.Rad2Deg;
    }

    void ReadKeyboard(ref float steer, ref float thr, ref float brk)
    {
#if ENABLE_INPUT_SYSTEM
        var k = Keyboard.current;
        if (k == null) return;
        if (k.leftArrowKey.isPressed || k.aKey.isPressed) steer = -1f;
        if (k.rightArrowKey.isPressed || k.dKey.isPressed) steer = 1f;
        if (k.upArrowKey.isPressed || k.wKey.isPressed) thr = 1f;
        if (k.downArrowKey.isPressed || k.sKey.isPressed || k.spaceKey.isPressed) brk = 1f;
#else
        if (Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.A)) steer = -1f;
        if (Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.D)) steer = 1f;
        if (Input.GetKey(KeyCode.UpArrow) || Input.GetKey(KeyCode.W)) thr = 1f;
        if (Input.GetKey(KeyCode.DownArrow) || Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.Space)) brk = 1f;
#endif
    }
}
