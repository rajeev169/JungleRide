using UnityEngine;

/// <summary>
/// Season effects: falling rain and lightning flashes in the monsoon, mud splashes (monsoon) or
/// dust (summer) from the back wheel, and light drifting mist in winter.
/// </summary>
public class WeatherFX : MonoBehaviour
{
    ParticleSystem rain, wheel, mist, water;
    BikeController bike;
    Camera cam;
    Light sun;
    Season season;
    float flash;
    Color baseSky;
    float baseSun;
    static Material particleMat;
    static Texture2D dot;

    public static WeatherFX Create(Camera cam, Light sun)
    {
        var fx = new GameObject("WeatherFX").AddComponent<WeatherFX>();
        fx.cam = cam;
        fx.sun = sun;
        fx.rain = fx.MakeRain();
        fx.mist = fx.MakeMist();
        if (GameAudio.I != null) GameAudio.I.OnThunder += fx.Lightning;
        return fx;
    }

    static Material Mat()
    {
        if (particleMat == null)
        {
            dot = new Texture2D(32, 32, TextureFormat.RGBA32, false) { wrapMode = TextureWrapMode.Clamp };
            var px = new Color32[32 * 32];
            for (int y = 0; y < 32; y++)
                for (int x = 0; x < 32; x++)
                {
                    float d = Vector2.Distance(new Vector2(x + 0.5f, y + 0.5f), new Vector2(16, 16)) / 16f;
                    px[y * 32 + x] = new Color32(255, 255, 255, (byte)(Mathf.Clamp01(1f - d) * Mathf.Clamp01(1f - d) * 255));
                }
            dot.SetPixels32(px);
            dot.Apply();
            var shader = Shader.Find("JungleRider/Particle");
            if (shader == null) shader = Shader.Find("Sprites/Default");
            particleMat = new Material(shader) { mainTexture = dot };
        }
        return particleMat;
    }

    static ParticleSystem NewSystem(string name, Transform parent)
    {
        var go = new GameObject(name);
        go.transform.SetParent(parent, false);
        var ps = go.AddComponent<ParticleSystem>();
        ps.Stop(true, ParticleSystemStopBehavior.StopEmittingAndClear);
        var r = go.GetComponent<ParticleSystemRenderer>();
        r.sharedMaterial = Mat();
        r.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
        r.receiveShadows = false;
        return ps;
    }

    ParticleSystem MakeRain()
    {
        var ps = NewSystem("Rain", cam.transform);
        ps.transform.localPosition = new Vector3(0f, 10f, 8f);
        var main = ps.main;
        main.loop = true;
        main.startLifetime = 1.1f;
        main.startSpeed = 0f;
        main.startSize = new ParticleSystem.MinMaxCurve(0.02f, 0.035f);
        main.startColor = new Color(0.78f, 0.84f, 0.9f, 0.45f);
        main.simulationSpace = ParticleSystemSimulationSpace.World;
        main.maxParticles = 2500;
        var em = ps.emission;
        em.rateOverTime = 1400f;
        var shape = ps.shape;
        shape.shapeType = ParticleSystemShapeType.Box;
        shape.scale = new Vector3(34f, 1f, 34f);
        var vel = ps.velocityOverLifetime;
        vel.enabled = true;
        vel.space = ParticleSystemSimulationSpace.World;
        vel.x = new ParticleSystem.MinMaxCurve(-1.5f, -0.5f);
        vel.y = new ParticleSystem.MinMaxCurve(-20f, -16f);
        vel.z = new ParticleSystem.MinMaxCurve(0f, 0f);
        var r = ps.GetComponent<ParticleSystemRenderer>();
        r.renderMode = ParticleSystemRenderMode.Stretch;
        r.velocityScale = 0.045f;
        r.lengthScale = 1f;
        return ps;
    }

    ParticleSystem MakeMist()
    {
        var ps = NewSystem("Mist", cam.transform);
        ps.transform.localPosition = new Vector3(0f, 0f, 14f);
        var main = ps.main;
        main.loop = true;
        main.startLifetime = 9f;
        main.startSpeed = 0.3f;
        main.startSize = new ParticleSystem.MinMaxCurve(6f, 12f);
        main.startColor = new Color(0.92f, 0.94f, 0.96f, 0.08f);
        main.simulationSpace = ParticleSystemSimulationSpace.World;
        main.maxParticles = 80;
        var em = ps.emission;
        em.rateOverTime = 7f;
        var shape = ps.shape;
        shape.shapeType = ParticleSystemShapeType.Box;
        shape.scale = new Vector3(40f, 4f, 30f);
        var col = ps.colorOverLifetime;
        col.enabled = true;
        var grad = new Gradient();
        grad.SetKeys(new[] { new GradientColorKey(Color.white, 0f), new GradientColorKey(Color.white, 1f) },
                     new[] { new GradientAlphaKey(0f, 0f), new GradientAlphaKey(1f, 0.3f), new GradientAlphaKey(1f, 0.7f), new GradientAlphaKey(0f, 1f) });
        col.color = grad;
        return ps;
    }

    ParticleSystem MakeWheel(Transform bikeTr)
    {
        var ps = NewSystem("WheelSpray", bikeTr);
        ps.transform.localPosition = new Vector3(0f, -0.2f, -0.65f);
        ps.transform.localRotation = Quaternion.Euler(-150f, 0f, 0f); // backwards and up
        var main = ps.main;
        main.loop = true;
        main.simulationSpace = ParticleSystemSimulationSpace.World;
        main.maxParticles = 400;
        var shape = ps.shape;
        shape.shapeType = ParticleSystemShapeType.Cone;
        shape.angle = 25f;
        shape.radius = 0.08f;
        var em = ps.emission;
        em.rateOverTime = 0f;
        return ps;
    }

    public void SetBike(BikeController b)
    {
        bike = b;
        if (wheel == null && b != null) wheel = MakeWheel(b.transform);
        if (water == null && b != null) water = MakeWater(b.transform);
    }

    /// <summary>Water thrown up by both wheels in the river.</summary>
    ParticleSystem MakeWater(Transform bikeTr)
    {
        var ps = NewSystem("WaterSpray", bikeTr);
        ps.transform.localPosition = new Vector3(0f, -0.25f, 0f);
        ps.transform.localRotation = Quaternion.Euler(-90f, 0f, 0f);
        var main = ps.main;
        main.loop = true;
        main.simulationSpace = ParticleSystemSimulationSpace.World;
        main.maxParticles = 300;
        main.startLifetime = 0.7f;
        main.startSpeed = new ParticleSystem.MinMaxCurve(1.5f, 3.5f);
        main.startSize = new ParticleSystem.MinMaxCurve(0.06f, 0.16f);
        main.startColor = new Color(0.85f, 0.93f, 1f, 0.75f);
        main.gravityModifier = 1.2f;
        var shape = ps.shape;
        shape.shapeType = ParticleSystemShapeType.Cone;
        shape.angle = 50f;
        shape.radius = 0.5f;
        var em = ps.emission;
        em.rateOverTime = 0f;
        ps.Play();
        return ps;
    }

    /// <summary>One big burst of water (riding into the river).</summary>
    public void Splash()
    {
        if (water != null) water.Emit(40);
    }

    /// <summary>Soft white spray at the bottom of a waterfall.</summary>
    public static ParticleSystem Mist(Transform parent, Vector3 pos)
    {
        var ps = NewSystem("WaterfallMist", parent);
        ps.transform.position = pos;
        var main = ps.main;
        main.loop = true;
        main.startLifetime = 3.5f;
        main.startSpeed = new ParticleSystem.MinMaxCurve(0.5f, 1.8f);
        main.startSize = new ParticleSystem.MinMaxCurve(2.5f, 5f);
        main.startColor = new Color(0.95f, 0.97f, 1f, 0.22f);
        main.simulationSpace = ParticleSystemSimulationSpace.World;
        main.maxParticles = 60;
        var em = ps.emission;
        em.rateOverTime = 14f;
        var shape = ps.shape;
        shape.shapeType = ParticleSystemShapeType.Box;
        shape.scale = new Vector3(8f, 1f, 3f);
        var col = ps.colorOverLifetime;
        col.enabled = true;
        var grad = new Gradient();
        grad.SetKeys(new[] { new GradientColorKey(Color.white, 0f), new GradientColorKey(Color.white, 1f) },
                     new[] { new GradientAlphaKey(0f, 0f), new GradientAlphaKey(1f, 0.25f), new GradientAlphaKey(0f, 1f) });
        col.color = grad;
        ps.Play();
        return ps;
    }

    public void SetSeason(Season s)
    {
        season = s;
        baseSky = RenderSettings.ambientSkyColor;
        baseSun = sun ? sun.intensity : 1f;
        Toggle(rain, s == Season.Monsoon);
        Toggle(mist, s == Season.Winter);
        if (wheel != null)
        {
            var main = wheel.main;
            if (s == Season.Monsoon)
            {
                main.startLifetime = 0.6f;
                main.startSpeed = new ParticleSystem.MinMaxCurve(2f, 4f);
                main.startSize = new ParticleSystem.MinMaxCurve(0.04f, 0.09f);
                main.startColor = new Color(0.24f, 0.17f, 0.1f, 0.95f);
                main.gravityModifier = 1.5f;
            }
            else
            {
                main.startLifetime = 1.4f;
                main.startSpeed = new ParticleSystem.MinMaxCurve(0.5f, 1.5f);
                main.startSize = new ParticleSystem.MinMaxCurve(0.4f, 0.9f);
                main.startColor = new Color(0.72f, 0.62f, 0.46f, s == Season.Summer ? 0.22f : 0.08f);
                main.gravityModifier = -0.02f;
            }
            wheel.Play();
        }
    }

    static void Toggle(ParticleSystem ps, bool on)
    {
        if (ps == null) return;
        if (on && !ps.isPlaying) ps.Play();
        if (!on) ps.Stop(true, ParticleSystemStopBehavior.StopEmittingAndClear);
    }

    void Lightning()
    {
        if (season == Season.Monsoon) flash = 1f;
    }

    void Update()
    {
        // spray from the back wheel while riding on the ground
        if (wheel != null && bike != null)
        {
            var em = wheel.emission;
            float speed = Mathf.Abs(bike.ForwardSpeed);
            float rate = bike.Grounded && speed > 2f ? speed * (season == Season.Monsoon ? 9f : season == Season.Summer ? 2.5f : 1f) : 0f;
            if (bike.inWater) rate = 0f;
            em.rateOverTime = Time.timeScale == 0f ? 0f : rate;
        }
        if (water != null && bike != null)
        {
            var em = water.emission;
            float speed = Mathf.Abs(bike.ForwardSpeed);
            em.rateOverTime = Time.timeScale == 0f || !bike.inWater ? 0f : 20f + speed * 14f;
        }

        // lightning flash
        if (flash > 0f)
        {
            flash = Mathf.Max(0f, flash - Time.unscaledDeltaTime * 3f);
            float f = flash > 0.66f || (flash > 0.2f && flash < 0.4f) ? flash : 0f; // double flicker
            RenderSettings.ambientSkyColor = Color.Lerp(baseSky, Color.white, f * 0.8f);
            if (sun) sun.intensity = baseSun + f * 1.2f;
            if (flash <= 0f)
            {
                RenderSettings.ambientSkyColor = baseSky;
                if (sun) sun.intensity = baseSun;
            }
        }
    }

    void OnDestroy()
    {
        if (GameAudio.I != null) GameAudio.I.OnThunder -= Lightning;
    }
}
