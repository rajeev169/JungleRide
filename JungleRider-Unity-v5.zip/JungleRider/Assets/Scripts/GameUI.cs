using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

/// <summary>What the result screen shows after a run.</summary>
public class ResultInfo
{
    public string title;
    public int stars = -1;                 // -1 = no stars (not a level)
    public string[] missions;              // 3 mission lines (levels only)
    public string[] missionValues;
    public bool[] missionDone;
    public string body = "";
    public int mangoes, gems, trickScore;
    public bool showNext;
}

/// <summary>
/// All screens: main menu, world map, shop, daily rewards, settings, HUD with minimap and touch controls,
/// pause and results. (Shop, map and daily screens are in GameUI.Screens.cs.)
/// </summary>
public partial class GameUI : MonoBehaviour
{
    // events the game listens to
    public Action OnPause, OnResume, OnRestart, OnMainMenu, OnNextLevel;
    public Action<Season, bool> OnTrailRace;   // season, race against computer riders
    public Action<Season> OnEndless;
    public Action<int, bool> OnLevel;          // level, race
    public Action OnControlsChanged;
    public Action OnLooksChanged;

    GameObject menu, settings, hud, pause, result, seasonPick, modePick;
    Action<Season> seasonCallback;
    Action<bool> modeCallback;
    Text todayLabel, modeTitle;
    ControlIcons icons;
    GameObject ctrlButtons, ctrlTilt, ctrlJoystick, ctrlPedals;
    Text menuBest, menuWallet, hudInfo, hudSpeed, countdown, toast, tiltValue, settingsHint;
    Text dailyMenuLabel;
    readonly Dictionary<ControlMode, Button> controlButtons = new Dictionary<ControlMode, Button>();
    bool settingsFromPause, dailyAutoShown;
    float toastUntil;

    // HUD extras
    Text runMangoes, runGems, racePos;
    GameObject missionPanel, racePanel;
    readonly Image[] missionChecks = new Image[3];
    readonly Text[] missionTexts = new Text[3];
    Text trickName, trickPoints, trickCombo;
    RectTransform trickRoot;
    float trickTime = 99f;
    public Minimap Minimap { get; private set; }

    // result
    Text resultTitle, resultBody, resultEarned;
    readonly Image[] resultStars = new Image[3];
    readonly GameObject[] resultRows = new GameObject[3];
    readonly Text[] resultRowText = new Text[3], resultRowValue = new Text[3];
    readonly Image[] resultRowStar = new Image[3];
    Button nextLevelButton;

    public BikeInput Controls { get; private set; }

    static readonly Color Gold = new Color(1f, 0.82f, 0.22f);
    static readonly Color StarOff = new Color(0.3f, 0.34f, 0.3f, 0.9f);
    static readonly Color OkGreen = new Color(0.55f, 1f, 0.45f);

    public static GameUI Create(BikeInput input, ControlIcons icons)
    {
        var canvasGo = new GameObject("UI", typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
        var canvas = canvasGo.GetComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        canvas.sortingOrder = 10;
        var scaler = canvasGo.GetComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920, 1080);
        scaler.matchWidthOrHeight = 0.6f;

        if (EventSystem.current == null)
        {
            var es = new GameObject("EventSystem", typeof(EventSystem));
#if ENABLE_INPUT_SYSTEM
            es.AddComponent<UnityEngine.InputSystem.UI.InputSystemUIInputModule>();
#else
            es.AddComponent<StandaloneInputModule>();
#endif
        }

        var ui = canvasGo.AddComponent<GameUI>();
        ui.Controls = input;
        ui.icons = icons;
        ui.Build(canvasGo.transform);
        Economy.Changed += ui.RefreshWallets;
        return ui;
    }

    void OnDestroy() => Economy.Changed -= RefreshWallets;

    // ------------------------------------------------------------------ build
    void Build(Transform root)
    {
        BuildMenu(root);
        BuildMap(root);
        BuildHud(root);
        BuildControls(root);
        BuildPause(root);
        BuildResult(root);
        BuildSeasonPicker(root);
        BuildModePicker(root);
        BuildShop(root);
        BuildDaily(root);
        BuildSettings(root);   // last, so it draws on top of pause

        countdown = UIFactory.Label(root, "", 200, TextAnchor.MiddleCenter, Color.white, new Vector2(0.5f, 0.55f), Vector2.zero, new Vector2(800, 300));
        toast = UIFactory.Label(root, "", 60, TextAnchor.MiddleCenter, new Color(1f, 0.92f, 0.4f), new Vector2(0.5f, 0.6f), Vector2.zero, new Vector2(1400, 120));
    }

    /// <summary>Mango + gem counters in a dark pill.</summary>
    Text WalletPill(Transform parent, Vector2 anchor, Vector2 pos, out Text gems, bool withStars, out Text stars)
    {
        var p = UIFactory.Panel("Wallet", parent, anchor, pos, new Vector2(withStars ? 560 : 420, 90), UIFactory.Dark);
        UIFactory.Icon(p.transform, UIFactory.Mango, new Vector2(0f, 0.5f), new Vector2(50, 0), 56, Color.white);
        var m = UIFactory.Label(p.transform, "0", 42, TextAnchor.MiddleLeft, Color.white, new Vector2(0f, 0.5f), new Vector2(165, 0), new Vector2(170, 80));
        UIFactory.Icon(p.transform, UIFactory.Gem, new Vector2(0f, 0.5f), new Vector2(270, 0), 50, Color.white);
        gems = UIFactory.Label(p.transform, "0", 42, TextAnchor.MiddleLeft, Color.white, new Vector2(0f, 0.5f), new Vector2(360, 0), new Vector2(120, 80));
        stars = null;
        if (withStars)
        {
            UIFactory.Icon(p.transform, UIFactory.Star, new Vector2(0f, 0.5f), new Vector2(430, 2), 48, Gold);
            stars = UIFactory.Label(p.transform, "0", 42, TextAnchor.MiddleLeft, Gold, new Vector2(0f, 0.5f), new Vector2(505, 0), new Vector2(100, 80));
        }
        return m;
    }

    Text menuGems;

    void BuildMenu(Transform root)
    {
        menu = UIFactory.Stretch("Menu", root).gameObject;
        var side = UIFactory.Panel("Side", menu.transform, new Vector2(0f, 0.5f), new Vector2(380, 0), new Vector2(700, 1000), UIFactory.Dark);
        var t = side.transform;
        UIFactory.Label(t, "JUNGLE RIDER", 88, TextAnchor.MiddleCenter, new Color(0.6f, 1f, 0.4f), new Vector2(0.5f, 1f), new Vector2(0, -80), new Vector2(680, 110));
        UIFactory.Label(t, "OFFROAD", 56, TextAnchor.MiddleCenter, new Color(1f, 0.8f, 0.3f), new Vector2(0.5f, 1f), new Vector2(0, -155), new Vector2(680, 70));
        float y = -255f;
        const float step = 108f;
        Vector2 size = new Vector2(560, 96);
        UIFactory.MakeButton(t, "TRAIL RACE", new Vector2(0.5f, 1f), new Vector2(0, y), size, UIFactory.Green,
            () => OpenSeasonPicker(sn => OpenModePicker("TRAIL RACE", race => OnTrailRace?.Invoke(sn, race))), 42);
        UIFactory.MakeButton(t, "ENDLESS RIDE", new Vector2(0.5f, 1f), new Vector2(0, y -= step), size, UIFactory.Green, () => OpenSeasonPicker(sn => OnEndless?.Invoke(sn)), 42);
        UIFactory.MakeButton(t, "LEVELS", new Vector2(0.5f, 1f), new Vector2(0, y -= step), size, UIFactory.Green, ShowMap, 42);
        UIFactory.MakeButton(t, "SHOP", new Vector2(0.5f, 1f), new Vector2(0, y -= step), size, UIFactory.Orange, () => OpenShop(ShowMenu), 42);
        var daily = UIFactory.MakeButton(t, "DAILY", new Vector2(0.5f, 1f), new Vector2(0, y -= step), size, UIFactory.Orange, () => OpenDaily(ShowMenu), 42);
        dailyMenuLabel = daily.GetComponentInChildren<Text>();
        UIFactory.MakeButton(t, "SETTINGS", new Vector2(0.5f, 1f), new Vector2(0, y -= step), size, UIFactory.Grey, () => OpenSettings(false), 42);
        menuBest = UIFactory.Label(t, "", 30, TextAnchor.MiddleCenter, new Color(0.85f, 0.95f, 0.85f), new Vector2(0.5f, 0f), new Vector2(0, 75), new Vector2(660, 100));
        menuWallet = WalletPill(menu.transform, new Vector2(1f, 1f), new Vector2(-330, -75), out menuGems, true, out menuStars);
    }

    Text menuStars;

    void BuildSettings(Transform root)
    {
        settings = UIFactory.Stretch("Settings", root).gameObject;
        var dim = settings.AddComponent<Image>();
        dim.color = new Color(0, 0, 0, 0.45f);
        var p = UIFactory.Panel("Box", settings.transform, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(1500, 900), UIFactory.Dark);
        var t = p.transform;
        UIFactory.Label(t, "SETTINGS", 80, TextAnchor.MiddleCenter, Color.white, new Vector2(0.5f, 1f), new Vector2(0, -80), new Vector2(1000, 110));
        UIFactory.Label(t, "Steering controls", 46, TextAnchor.MiddleCenter, new Color(0.8f, 1f, 0.7f), new Vector2(0.5f, 1f), new Vector2(0, -190), new Vector2(1000, 70));

        AddControlOption(t, ControlMode.Buttons, "BUTTONS", -440);
        AddControlOption(t, ControlMode.Tilt, "TILT PHONE", 0);
        AddControlOption(t, ControlMode.Joystick, "JOYSTICK", 440);
        settingsHint = UIFactory.Label(t, "", 34, TextAnchor.MiddleCenter, new Color(0.9f, 0.9f, 0.9f), new Vector2(0.5f, 1f), new Vector2(0, -420), new Vector2(1300, 80));

        UIFactory.Label(t, "Tilt sensitivity", 42, TextAnchor.MiddleCenter, new Color(0.8f, 1f, 0.7f), new Vector2(0.5f, 1f), new Vector2(0, -510), new Vector2(1000, 70));
        UIFactory.MakeButton(t, "-", new Vector2(0.5f, 1f), new Vector2(-260, -610), new Vector2(130, 110), UIFactory.Grey, () => ChangeTilt(-0.1f), 70);
        UIFactory.MakeButton(t, "+", new Vector2(0.5f, 1f), new Vector2(260, -610), new Vector2(130, 110), UIFactory.Grey, () => ChangeTilt(0.1f), 70);
        tiltValue = UIFactory.Label(t, "", 54, TextAnchor.MiddleCenter, Color.white, new Vector2(0.5f, 1f), new Vector2(0, -610), new Vector2(300, 110));
        UIFactory.Label(t, "Tricks: press BRAKE in the air to backflip. Land it fully!", 32, TextAnchor.MiddleCenter, new Color(1f, 0.85f, 0.4f), new Vector2(0.5f, 1f), new Vector2(0, -710), new Vector2(1300, 60));

        UIFactory.MakeButton(t, "DONE", new Vector2(0.5f, 0f), new Vector2(0, 90), new Vector2(360, 110), UIFactory.Green, CloseSettings);
    }

    void AddControlOption(Transform t, ControlMode mode, string label, float x)
    {
        var b = UIFactory.MakeButton(t, label, new Vector2(0.5f, 1f), new Vector2(x, -320), new Vector2(400, 120), UIFactory.Grey, () =>
        {
            GameSettings.Control = mode;
            RefreshSettings();
            RefreshControls();
            OnControlsChanged?.Invoke();
        }, 42);
        controlButtons[mode] = b;
    }

    void BuildHud(Transform root)
    {
        hud = UIFactory.Stretch("HUD", root).gameObject;
        var info = UIFactory.Panel("Info", hud.transform, new Vector2(0f, 1f), new Vector2(300, -70), new Vector2(560, 110), UIFactory.Dark);
        hudInfo = UIFactory.FillLabel(info.transform, "", 40, Color.white);

        // this run's mangoes and gems
        var wallet = UIFactory.Panel("RunWallet", hud.transform, new Vector2(0f, 1f), new Vector2(190, -175), new Vector2(340, 80), UIFactory.Dark);
        UIFactory.Icon(wallet.transform, UIFactory.Mango, new Vector2(0f, 0.5f), new Vector2(45, 0), 50, Color.white);
        runMangoes = UIFactory.Label(wallet.transform, "0", 40, TextAnchor.MiddleLeft, Color.white, new Vector2(0f, 0.5f), new Vector2(140, 0), new Vector2(120, 70));
        UIFactory.Icon(wallet.transform, UIFactory.Gem, new Vector2(0f, 0.5f), new Vector2(225, 0), 44, Color.white);
        runGems = UIFactory.Label(wallet.transform, "0", 40, TextAnchor.MiddleLeft, Color.white, new Vector2(0f, 0.5f), new Vector2(310, 0), new Vector2(100, 70));

        // the three level missions
        missionPanel = UIFactory.Panel("Missions", hud.transform, new Vector2(0f, 1f), new Vector2(300, -305), new Vector2(560, 160), UIFactory.Dark).gameObject;
        for (int k = 0; k < 3; k++)
        {
            float y = 50f - k * 48f;
            var box = UIFactory.Panel("Check", missionPanel.transform, new Vector2(0f, 0.5f), new Vector2(40, y), new Vector2(34, 34), new Color(1f, 1f, 1f, 0.25f));
            missionChecks[k] = UIFactory.Icon(box.transform, UIFactory.Tick, new Vector2(0.5f, 0.5f), Vector2.zero, 30, OkGreen);
            missionTexts[k] = UIFactory.Label(missionPanel.transform, "", 30, TextAnchor.MiddleLeft, Color.white, new Vector2(0f, 0.5f), new Vector2(320, y), new Vector2(520, 46));
        }

        var spd = UIFactory.Panel("Speed", hud.transform, new Vector2(0.5f, 1f), new Vector2(0, -70), new Vector2(300, 110), UIFactory.Dark);
        hudSpeed = UIFactory.FillLabel(spd.transform, "0 km/h", 46, Color.white);
        racePanel = UIFactory.Panel("RacePos", hud.transform, new Vector2(0.5f, 1f), new Vector2(0, -170), new Vector2(240, 76), new Color(0.85f, 0.45f, 0.08f, 0.9f)).gameObject;
        racePos = UIFactory.FillLabel(racePanel.transform, "", 40, Color.white);
        UIFactory.MakeButton(hud.transform, "II", new Vector2(1f, 1f), new Vector2(-90, -75), new Vector2(120, 120), UIFactory.Dark, () => OnPause?.Invoke(), 54, GameAudio.Ui.Pause);

        Minimap = Minimap.Create(hud.transform, new Vector2(1f, 1f), new Vector2(-230, -330), 300f);

        // trick popup: BACKFLIP!  +500  COMBO x2
        trickRoot = UIFactory.MakeRect("Trick", hud.transform, new Vector2(0.5f, 0.72f), Vector2.zero, new Vector2(1200, 220));
        trickName = UIFactory.Label(trickRoot, "", 110, TextAnchor.MiddleCenter, Gold, new Vector2(0.5f, 0.5f), new Vector2(0, 45), new Vector2(1200, 140));
        trickName.fontStyle = FontStyle.Bold;
        var outline = trickName.gameObject.AddComponent<Outline>();
        outline.effectColor = new Color(0.45f, 0.25f, 0f, 0.9f);
        outline.effectDistance = new Vector2(4, -4);
        trickPoints = UIFactory.Label(trickRoot, "", 64, TextAnchor.MiddleRight, Color.white, new Vector2(0.5f, 0.5f), new Vector2(-150, -60), new Vector2(400, 90));
        trickPoints.fontStyle = FontStyle.Bold;
        trickCombo = UIFactory.Label(trickRoot, "", 64, TextAnchor.MiddleLeft, OkGreen, new Vector2(0.5f, 0.5f), new Vector2(230, -60), new Vector2(460, 90));
        trickCombo.fontStyle = FontStyle.Bold;
        trickRoot.gameObject.SetActive(false);
    }

    void BuildControls(Transform root)
    {
        var c = UIFactory.Stretch("Controls", hud.transform);

        // right side: pedal + brake (all modes)
        ctrlPedals = UIFactory.Stretch("Pedals", c).gameObject;
        // 3D icons, no background: the touch area is an invisible box around each icon
        Controls.gas = IconButton(ctrlPedals.transform, "Pedal", icons ? icons.PedalTexture : null, new Vector2(1f, 0f), new Vector2(-190, 235), new Vector2(300, 368));
        Controls.brake = IconButton(ctrlPedals.transform, "Brake", icons ? icons.BrakeTexture : null, new Vector2(1f, 0f), new Vector2(-520, 180), new Vector2(320, 305));

        // left side: one of three steering styles
        ctrlButtons = UIFactory.Stretch("SteerButtons", c).gameObject;
        Controls.left = UIFactory.MakeHoldButton(ctrlButtons.transform, "<", new Vector2(0f, 0f), new Vector2(170, 170), new Vector2(240, 240), new Color(1f, 1f, 1f, 0.28f), 110);
        Controls.right = UIFactory.MakeHoldButton(ctrlButtons.transform, ">", new Vector2(0f, 0f), new Vector2(440, 170), new Vector2(240, 240), new Color(1f, 1f, 1f, 0.28f), 110);

        ctrlTilt = UIFactory.Stretch("SteerTilt", c).gameObject;
        UIFactory.Label(ctrlTilt.transform, "Tilt phone to steer", 36, TextAnchor.MiddleLeft, new Color(1f, 1f, 1f, 0.8f), new Vector2(0f, 0f), new Vector2(260, 80), new Vector2(460, 80));

        ctrlJoystick = UIFactory.Stretch("SteerJoystick", c).gameObject;
        var area = UIFactory.MakeRect("JoystickArea", ctrlJoystick.transform, new Vector2(0f, 0f), new Vector2(260, 260), new Vector2(340, 340));
        var bg = area.gameObject.AddComponent<Image>();
        bg.sprite = UIFactory.Circle;
        bg.color = new Color(1f, 1f, 1f, 0.2f);
        var knob = UIFactory.MakeRect("Knob", area, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(150, 150));
        var kimg = knob.gameObject.AddComponent<Image>();
        kimg.sprite = UIFactory.Circle;
        kimg.color = new Color(1f, 1f, 1f, 0.55f);
        kimg.raycastTarget = false;
        var joy = area.gameObject.AddComponent<VirtualJoystick>();
        joy.knob = knob;
        Controls.joystick = joy;

        RefreshControls();
    }

    HoldButton IconButton(Transform parent, string name, Texture tex, Vector2 anchor, Vector2 pos, Vector2 size)
    {
        var area = UIFactory.MakeRect(name + "Button", parent, anchor, pos, size);
        var hit = area.gameObject.AddComponent<Image>();
        hit.color = new Color(1f, 1f, 1f, 0f);           // invisible, but still catches touches
        if (tex != null)
        {
            var shadow = UIFactory.Stretch("Shadow", area).gameObject.AddComponent<RawImage>();
            shadow.texture = tex;
            shadow.color = new Color(0f, 0f, 0f, 0.45f);
            shadow.raycastTarget = false;
            ((RectTransform)shadow.transform).anchoredPosition = new Vector2(6f, -8f);
            var icon = UIFactory.Stretch("Icon", area).gameObject.AddComponent<RawImage>();
            icon.texture = tex;
            icon.raycastTarget = false;
        }
        else
        {
            UIFactory.FillLabel(area, name.ToUpper(), 46, Color.white);
        }
        var hb = area.gameObject.AddComponent<HoldButton>();
        hb.tintWhenPressed = false;
        return hb;
    }

    void BuildSeasonPicker(Transform root)
    {
        seasonPick = UIFactory.Stretch("SeasonPicker", root).gameObject;
        var p = UIFactory.Panel("Box", seasonPick.transform, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(1500, 820), UIFactory.Dark);
        var t = p.transform;
        UIFactory.Label(t, "CHOOSE SEASON", 76, TextAnchor.MiddleCenter, Color.white, new Vector2(0.5f, 1f), new Vector2(0, -80), new Vector2(1200, 110));
        UIFactory.MakeButton(t, "SUMMER", new Vector2(0.5f, 1f), new Vector2(-460, -260), new Vector2(400, 150), new Color(0.85f, 0.6f, 0.15f, 0.95f), () => PickSeason(Season.Summer), 46);
        UIFactory.MakeButton(t, "MONSOON", new Vector2(0.5f, 1f), new Vector2(0, -260), new Vector2(400, 150), new Color(0.2f, 0.45f, 0.6f, 0.95f), () => PickSeason(Season.Monsoon), 46);
        UIFactory.MakeButton(t, "WINTER", new Vector2(0.5f, 1f), new Vector2(460, -260), new Vector2(400, 150), new Color(0.55f, 0.62f, 0.7f, 0.95f), () => PickSeason(Season.Winter), 46);
        UIFactory.Label(t, "Summer: dry and fast    Monsoon: rain, slippery mud    Winter: thick fog", 32, TextAnchor.MiddleCenter, new Color(0.85f, 0.95f, 0.85f), new Vector2(0.5f, 1f), new Vector2(0, -380), new Vector2(1400, 60));
        var today = UIFactory.MakeButton(t, "", new Vector2(0.5f, 1f), new Vector2(-230, -500), new Vector2(420, 120), UIFactory.Green, () => PickSeason(Seasons.Today()), 38);
        todayLabel = today.GetComponentInChildren<Text>();
        UIFactory.MakeButton(t, "RANDOM", new Vector2(0.5f, 1f), new Vector2(230, -500), new Vector2(420, 120), UIFactory.Green, () => PickSeason(Seasons.Random()), 42);
        UIFactory.MakeButton(t, "BACK", new Vector2(0.5f, 0f), new Vector2(0, 100), new Vector2(360, 110), UIFactory.Grey, () => ShowMenu());
    }

    void OpenSeasonPicker(Action<Season> onPick)
    {
        seasonCallback = onPick;
        Show(seasonPick);
        if (todayLabel) todayLabel.text = "TODAY: " + Seasons.Name(Seasons.Today()).ToUpper();
    }

    void PickSeason(Season s)
    {
        var cb = seasonCallback;
        seasonCallback = null;
        cb?.Invoke(s);
    }

    void BuildModePicker(Transform root)
    {
        modePick = UIFactory.Stretch("ModePicker", root).gameObject;
        var dim = modePick.AddComponent<Image>();
        dim.color = new Color(0, 0, 0, 0.5f);
        var p = UIFactory.Panel("Box", modePick.transform, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(1300, 700), UIFactory.Dark);
        var t = p.transform;
        modeTitle = UIFactory.Label(t, "", 70, TextAnchor.MiddleCenter, Color.white, new Vector2(0.5f, 1f), new Vector2(0, -80), new Vector2(1200, 110));
        UIFactory.MakeButton(t, "SOLO", new Vector2(0.5f, 1f), new Vector2(-300, -290), new Vector2(520, 200), UIFactory.Green, () => PickMode(false), 60);
        UIFactory.MakeButton(t, "RACE", new Vector2(0.5f, 1f), new Vector2(300, -290), new Vector2(520, 200), UIFactory.Orange, () => PickMode(true), 60);
        UIFactory.Label(t, "Ride alone against the clock", 30, TextAnchor.MiddleCenter, new Color(0.85f, 0.95f, 0.85f), new Vector2(0.5f, 1f), new Vector2(-300, -425), new Vector2(560, 50));
        UIFactory.Label(t, "Race 10 computer riders", 30, TextAnchor.MiddleCenter, new Color(0.85f, 0.95f, 0.85f), new Vector2(0.5f, 1f), new Vector2(300, -425), new Vector2(560, 50));
        UIFactory.MakeButton(t, "BACK", new Vector2(0.5f, 0f), new Vector2(0, 90), new Vector2(360, 110), UIFactory.Grey, () => { modePick.SetActive(false); modeCallback = null; });
    }

    void OpenModePicker(string title, Action<bool> onPick)
    {
        modeCallback = onPick;
        modeTitle.text = title;
        modePick.SetActive(true);
        modePick.transform.SetAsLastSibling();
    }

    void PickMode(bool race)
    {
        var cb = modeCallback;
        modeCallback = null;
        modePick.SetActive(false);
        cb?.Invoke(race);
    }

    void BuildPause(Transform root)
    {
        pause = UIFactory.Stretch("Pause", root).gameObject;
        var dim = pause.AddComponent<Image>();
        dim.color = new Color(0, 0, 0, 0.5f);
        var p = UIFactory.Panel("Box", pause.transform, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(700, 820), UIFactory.Dark);
        UIFactory.Label(p.transform, "PAUSED", 80, TextAnchor.MiddleCenter, Color.white, new Vector2(0.5f, 1f), new Vector2(0, -80), new Vector2(600, 110));
        UIFactory.MakeButton(p.transform, "RESUME", new Vector2(0.5f, 1f), new Vector2(0, -220), new Vector2(520, 115), UIFactory.Green, () => OnResume?.Invoke(), 44, GameAudio.Ui.Resume);
        UIFactory.MakeButton(p.transform, "RESTART", new Vector2(0.5f, 1f), new Vector2(0, -360), new Vector2(520, 115), UIFactory.Orange, () => OnRestart?.Invoke(), 44, GameAudio.Ui.Restart);
        UIFactory.MakeButton(p.transform, "SETTINGS", new Vector2(0.5f, 1f), new Vector2(0, -500), new Vector2(520, 115), UIFactory.Grey, () => OpenSettings(true));
        UIFactory.MakeButton(p.transform, "MAIN MENU", new Vector2(0.5f, 1f), new Vector2(0, -640), new Vector2(520, 115), UIFactory.Grey, () => OnMainMenu?.Invoke());
    }

    void BuildResult(Transform root)
    {
        result = UIFactory.Stretch("Result", root).gameObject;
        var dim = result.AddComponent<Image>();
        dim.color = new Color(0, 0, 0, 0.45f);
        var p = UIFactory.Panel("Box", result.transform, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(1300, 940), UIFactory.Dark);
        var t = p.transform;
        resultTitle = UIFactory.Label(t, "", 84, TextAnchor.MiddleCenter, Gold, new Vector2(0.5f, 1f), new Vector2(0, -80), new Vector2(1250, 120));
        resultTitle.fontStyle = FontStyle.Bold;
        for (int k = 0; k < 3; k++)
            resultStars[k] = UIFactory.Icon(t, UIFactory.Star, new Vector2(0.5f, 1f), new Vector2((k - 1) * 120f, k == 1 ? -200 : -215), k == 1 ? 130 : 100, StarOff);
        for (int k = 0; k < 3; k++)
        {
            var row = UIFactory.MakeRect("Mission" + k, t, new Vector2(0.5f, 1f), new Vector2(0, -320 - k * 62), new Vector2(1000, 58));
            resultRows[k] = row.gameObject;
            resultRowStar[k] = UIFactory.Icon(row, UIFactory.Star, new Vector2(0f, 0.5f), new Vector2(25, 0), 40, Color.white);
            resultRowText[k] = UIFactory.Label(row, "", 40, TextAnchor.MiddleLeft, Color.white, new Vector2(0f, 0.5f), new Vector2(380, 0), new Vector2(680, 58));
            resultRowValue[k] = UIFactory.Label(row, "", 40, TextAnchor.MiddleRight, OkGreen, new Vector2(1f, 0.5f), new Vector2(-150, 0), new Vector2(300, 58));
        }
        resultBody = UIFactory.Label(t, "", 42, TextAnchor.UpperCenter, Color.white, new Vector2(0.5f, 1f), new Vector2(0, -500), new Vector2(1200, 200));
        resultEarned = UIFactory.Label(t, "", 42, TextAnchor.MiddleCenter, Color.white, new Vector2(0.5f, 0f), new Vector2(0, 245), new Vector2(1200, 70));
        UIFactory.MakeButton(t, "RETRY", new Vector2(0.5f, 0f), new Vector2(-450, 110), new Vector2(270, 115), UIFactory.Orange, () => OnRestart?.Invoke(), 44, GameAudio.Ui.Restart);
        nextLevelButton = UIFactory.MakeButton(t, "NEXT", new Vector2(0.5f, 0f), new Vector2(-150, 110), new Vector2(270, 115), UIFactory.Green, () => OnNextLevel?.Invoke());
        UIFactory.MakeButton(t, "SHOP", new Vector2(0.5f, 0f), new Vector2(150, 110), new Vector2(270, 115), UIFactory.Grey, () => OpenShop(() => result.SetActive(true)));
        UIFactory.MakeButton(t, "MENU", new Vector2(0.5f, 0f), new Vector2(450, 110), new Vector2(270, 115), UIFactory.Grey, () => OnMainMenu?.Invoke());
    }

    // ------------------------------------------------------------------ screens
    void Show(GameObject screen)
    {
        foreach (var s in new[] { menu, map, settings, hud, pause, result, seasonPick, modePick, shop, daily })
            if (s) s.SetActive(s == screen);
        if (screen == map) RefreshMap();
        RefreshWallets();
    }

    public void ShowMenu()
    {
        Show(menu);
        countdown.text = "";
        toast.text = "";
        float bt = GameSettings.BestTrailTime;
        float be = GameSettings.BestEndless;
        menuBest.text = "Best trail time: " + GameSettings.FormatTime(bt) + "\nBest endless: " + Mathf.FloorToInt(be) + " m";
        if (!Economy.LoginClaimed && !dailyAutoShown)       // the 7-day reward pops up once a day
        {
            dailyAutoShown = true;
            OpenDaily(ShowMenu);
        }
    }

    public void ShowHud()
    {
        Show(hud);
        trickRoot.gameObject.SetActive(false);
        RefreshControls();
    }

    public void ShowPause() { pause.SetActive(true); }
    public void HidePause() { pause.SetActive(false); settings.SetActive(false); }

    public void ShowResult(ResultInfo r)
    {
        hud.SetActive(false);
        pause.SetActive(false);
        result.SetActive(true);
        countdown.text = "";
        resultTitle.text = r.title;
        bool level = r.stars >= 0;
        for (int k = 0; k < 3; k++)
        {
            resultStars[k].gameObject.SetActive(level);
            resultStars[k].color = level && k < r.stars ? Gold : StarOff;
            bool row = level && r.missions != null;
            resultRows[k].SetActive(row);
            if (row)
            {
                bool done = r.missionDone[k];
                resultRowStar[k].color = done ? Gold : StarOff;
                resultRowText[k].text = r.missions[k];
                resultRowText[k].color = done ? Color.white : new Color(0.65f, 0.7f, 0.65f);
                resultRowValue[k].text = r.missionValues[k];
                resultRowValue[k].color = done ? OkGreen : new Color(0.75f, 0.78f, 0.75f);
            }
        }
        var bodyRt = (RectTransform)resultBody.transform;
        bodyRt.anchoredPosition = new Vector2(0, level ? -515 : -230);
        bodyRt.sizeDelta = new Vector2(1200, level ? 120 : 380);
        resultBody.text = r.body;
        resultEarned.text = "Earned:  " + r.mangoes + " mangoes    " + r.gems + " gems    Tricks: " + r.trickScore + " pts";
        nextLevelButton.gameObject.SetActive(r.showNext);
    }

    void OpenSettings(bool fromPause)
    {
        settingsFromPause = fromPause;
        settings.SetActive(true);
        settings.transform.SetAsLastSibling();
        if (!fromPause) menu.SetActive(false);
        RefreshSettings();
    }

    void CloseSettings()
    {
        settings.SetActive(false);
        if (!settingsFromPause) ShowMenu();
    }

    void ChangeTilt(float delta)
    {
        GameSettings.TiltSensitivity = Mathf.Round((GameSettings.TiltSensitivity + delta) * 10f) / 10f;
        RefreshSettings();
    }

    void RefreshSettings()
    {
        var current = GameSettings.Control;
        foreach (var kv in controlButtons)
            kv.Value.GetComponent<Image>().color = kv.Key == current ? UIFactory.Green : UIFactory.Grey;
        tiltValue.text = GameSettings.TiltSensitivity.ToString("0.0") + "x";
        switch (current)
        {
            case ControlMode.Buttons: settingsHint.text = "Left / right buttons to steer, PEDAL and BRAKE on the right."; break;
            case ControlMode.Tilt: settingsHint.text = "Turn the phone like a steering wheel. Hold it straight when the race starts."; break;
            default: settingsHint.text = "Drag the joystick left / right to steer, PEDAL and BRAKE on the right."; break;
        }
    }

    public void RefreshControls()
    {
        if (ctrlButtons == null) return;
        var mode = GameSettings.Control;
        ctrlButtons.SetActive(mode == ControlMode.Buttons);
        ctrlTilt.SetActive(mode == ControlMode.Tilt);
        ctrlJoystick.SetActive(mode == ControlMode.Joystick);
    }

    void RefreshWallets()
    {
        if (menuWallet)
        {
            menuWallet.text = Economy.Mangoes.ToString("N0");
            menuGems.text = Economy.Gems.ToString();
            menuStars.text = Economy.TotalStars().ToString();
        }
        if (dailyMenuLabel)
            dailyMenuLabel.text = (!Economy.LoginClaimed || (Economy.ChallengeDone && !Economy.ChallengeClaimed)) ? "DAILY  (!)" : "DAILY";
        RefreshMapWallet();
        RefreshShopWallet();
    }

    // ------------------------------------------------------------------ HUD
    public void SetHud(string info, float kmh)
    {
        hudInfo.text = info;
        hudSpeed.text = Mathf.RoundToInt(kmh) + " km/h";
    }

    public void SetRunWallet(int mangoes, int gems)
    {
        runMangoes.text = mangoes.ToString();
        runGems.text = gems.ToString();
    }

    /// <summary>Shows the 3 mission lines (pass null to hide the panel).</summary>
    public void SetMissions(string[] lines, bool[] done)
    {
        missionPanel.SetActive(lines != null);
        if (lines == null) return;
        for (int k = 0; k < 3; k++)
        {
            missionTexts[k].text = lines[k];
            missionTexts[k].color = done[k] ? Color.white : Gold;
            missionChecks[k].enabled = done[k];
        }
    }

    /// <summary>Race position like "3rd / 11" (null hides it).</summary>
    public void SetRacePosition(string text)
    {
        racePanel.SetActive(text != null);
        if (text != null) racePos.text = text;
    }

    public void ShowTrick(string name, int points, int combo)
    {
        trickName.text = name;
        trickPoints.text = "+" + points;
        trickCombo.text = combo > 1 ? "COMBO x" + combo : "";
        ((RectTransform)trickPoints.transform).anchoredPosition = new Vector2(combo > 1 ? -150 : 0, -60);
        trickPoints.alignment = combo > 1 ? TextAnchor.MiddleRight : TextAnchor.MiddleCenter;
        trickTime = 0f;
        trickRoot.gameObject.SetActive(true);
    }

    public void SetCountdown(string text) => countdown.text = text;

    public void Toast(string text, float seconds = 1.8f)
    {
        toast.text = text;
        toastUntil = Time.unscaledTime + seconds;
        toast.transform.SetAsLastSibling();
    }

    void Update()
    {
        if (toast.text.Length > 0 && Time.unscaledTime > toastUntil) toast.text = "";

        // trick popup: pops in, holds, fades out
        if (trickTime < 2f && trickRoot.gameObject.activeSelf)
        {
            trickTime += Time.unscaledDeltaTime;
            float s = trickTime < 0.15f ? Mathf.Lerp(0.4f, 1.15f, trickTime / 0.15f) : trickTime < 0.3f ? Mathf.Lerp(1.15f, 1f, (trickTime - 0.15f) / 0.15f) : 1f;
            trickRoot.localScale = Vector3.one * s;
            float a = trickTime > 1.5f ? Mathf.Clamp01(1f - (trickTime - 1.5f) / 0.5f) : 1f;
            SetAlpha(trickName, a); SetAlpha(trickPoints, a); SetAlpha(trickCombo, a);
            if (trickTime >= 2f) trickRoot.gameObject.SetActive(false);
        }
        UpdateDaily();
    }

    static void SetAlpha(Text t, float a)
    {
        var c = t.color;
        c.a = a;
        t.color = c;
    }
}
