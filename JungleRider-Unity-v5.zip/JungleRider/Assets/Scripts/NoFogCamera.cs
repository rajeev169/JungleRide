using UnityEngine;

/// <summary>Turns scene fog off while this camera renders (so the icons stay crisp in misty winter).</summary>
public class NoFogCamera : MonoBehaviour
{
    bool saved;
    void OnPreRender() { saved = RenderSettings.fog; RenderSettings.fog = false; }
    void OnPostRender() { RenderSettings.fog = saved; }
}
