using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Race mode: 10 computer riders on the same trail. They follow the trail at their own pace (slower in curves,
/// in the river, on the rope bridge and up the mountain), change lanes, and jump the waterfall gap.
/// They are ghosts: you can ride through them.
/// </summary>
public class RaceAI : MonoBehaviour
{
    public class Rider
    {
        public string name;
        public Color jersey;
        public Transform tr;
        public RiderRig rig;
        public float s;            // metres from the start line
        public float baseSpeed, speed;
        public float lane, laneTarget, nextLane;
        public bool finished;
        public float finishTime;
        public Vector3 position;
    }

    static readonly string[] Names =
    {
        "Arjun", "Maya", "Leo", "Kiran", "Zara", "Nikhil", "Sofia", "Ravi", "Ananya", "Tom",
        "Ishaan", "Lila", "Dev", "Mira", "Sam", "Priya", "Kabir", "Nina",
    };

    static readonly Color[] Jerseys =
    {
        new Color(0.9f, 0.2f, 0.2f), new Color(0.2f, 0.45f, 0.95f), new Color(0.95f, 0.8f, 0.15f), new Color(0.75f, 0.3f, 0.9f),
        new Color(0.1f, 0.8f, 0.8f), new Color(1f, 0.5f, 0.1f), new Color(0.95f, 0.95f, 0.95f), new Color(0.35f, 0.35f, 0.35f),
        new Color(1f, 0.45f, 0.7f), new Color(0.5f, 0.9f, 0.3f),
    };

    public readonly List<Rider> Riders = new List<Rider>();
    TrailPath path;
    float finishMetres;
    public bool Running;

    public static RaceAI Create()
    {
        return new GameObject("RaceAI").AddComponent<RaceAI>();
    }

    public void Clear()
    {
        foreach (var r in Riders) if (r.tr) Destroy(r.tr.gameObject);
        Riders.Clear();
        Running = false;
    }

    /// <summary>Puts <paramref name="count"/> riders on the start grid behind the player.</summary>
    public void Setup(TrailPath p, int count, float skill, int seed)
    {
        Clear();
        path = p;
        finishMetres = (p.FinishIndex - TrailPath.StartIndex) * TrailPath.SegLen;
        var rnd = new System.Random(seed);
        var names = new List<string>(Names);
        for (int k = 0; k < count; k++)
        {
            int ni = rnd.Next(names.Count);
            var r = new Rider
            {
                name = names[ni],
                jersey = Jerseys[k % Jerseys.Length],
                s = -2.5f - (k / 3) * 2.6f,
                lane = (k % 3 - 1) * 1.6f,
                // spread from easy to fast; better riders on harder levels
                baseSpeed = Mathf.Lerp(7.2f, 11.2f, k / (float)Mathf.Max(1, count - 1)) * (0.92f + 0.16f * skill) * (0.96f + (float)rnd.NextDouble() * 0.08f),
            };
            names.RemoveAt(ni);
            r.laneTarget = r.lane;
            r.nextLane = 2f + (float)rnd.NextDouble() * 4f;

            var go = new GameObject("Rider " + r.name);
            go.transform.SetParent(transform, false);
            var visual = new GameObject("Visual").transform;
            visual.SetParent(go.transform, false);
            var model = RiderRig.Build(visual, null, true);
            if (model != null)
            {
                BikeController.FitModel(model, visual);
                r.rig = model.GetComponent<RiderRig>();
                Color suit = Color.Lerp(Color.white, r.jersey, 0.7f) * 1.25f;
                suit.a = 1f;
                r.rig.SetLook(suit, r.jersey);
                foreach (var rend in model.GetComponentsInChildren<Renderer>())
                    rend.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;   // cheaper
            }
            r.tr = go.transform;
            Riders.Add(r);
            Place(r);
        }
    }

    float SpeedFactor(Rider r)
    {
        int i = TrailPath.StartIndex + Mathf.FloorToInt(r.s / TrailPath.SegLen);
        float f = 1f;
        // slower in sharp curves
        Vector3 a = path.Forward(i), b = path.Forward(i + 3);
        float turn = Vector3.Angle(a, b);
        f *= Mathf.Lerp(1f, 0.6f, Mathf.Clamp01((turn - 8f) / 40f));
        // up and down hills
        float slope = (path.Point(i + 1).y - path.Point(i).y) / TrailPath.SegLen;
        f *= Mathf.Clamp(1f - slope * 2.5f, 0.6f, 1.25f);
        var z = path.ZoneAt(i);
        if (z != null && z.InGap(i))
        {
            if (z.type == FeatureType.River) f *= 0.55f;
            if (z.type == FeatureType.RopeBridge) f *= 0.65f;
            if (z.type == FeatureType.Waterfall) f = Mathf.Max(f, 1.15f);
        }
        if (z != null && z.type == FeatureType.Waterfall && i >= z.gapStart - 4 && i < z.gapStart) f = Mathf.Max(f, 1.15f);   // speed up for the jump
        return f;
    }

    void Place(Rider r)
    {
        float idx = TrailPath.StartIndex + r.s / TrailPath.SegLen;
        idx = Mathf.Max(0f, idx);
        int i = Mathf.FloorToInt(idx);
        Vector3 c = path.PointAt(idx);
        var z = path.ZoneAt(i);
        float lane = r.lane;
        if (z != null && z.type == FeatureType.RopeBridge && z.InGap(i)) lane = Mathf.Clamp(lane, -0.6f, 0.6f);
        Vector3 p = c + path.Right(i) * lane;
        // fly over the waterfall gap
        if (z != null && z.type == FeatureType.Waterfall)
        {
            float t = (idx - (z.gapStart - 1.2f)) / 4.2f;
            if (t > 0f && t < 1f) p.y = z.baseY + 1.2f + 6.8f * t * (1f - t) - 3f * t * t;
        }
        r.position = p;
        Vector3 fwd = path.PointAt(idx + 0.5f) - path.PointAt(Mathf.Max(0f, idx - 0.5f));
        if (fwd.sqrMagnitude < 1e-4f) fwd = path.Forward(i);
        r.tr.SetPositionAndRotation(p, Quaternion.LookRotation(fwd.normalized, Vector3.up));
    }

    /// <summary>Moves everybody on. Call once per frame while racing.</summary>
    public void Tick(float dt, float raceTime, Vector3 playerPos)
    {
        if (path == null) return;
        foreach (var r in Riders)
        {
            if (!r.finished)
            {
                float target = Running ? r.baseSpeed * SpeedFactor(r) * (1f + 0.04f * Mathf.Sin(raceTime * 0.7f + r.baseSpeed)) : 0f;
                r.speed = Mathf.MoveTowards(r.speed, target, dt * (target > r.speed ? 2.5f : 5f));
                r.s += r.speed * dt;
                r.nextLane -= dt;
                if (r.nextLane <= 0f)
                {
                    r.laneTarget = Random.Range(-2f, 2f);
                    r.nextLane = Random.Range(2.5f, 6f);
                }
                r.lane = Mathf.MoveTowards(r.lane, r.laneTarget, dt * 0.8f);
                if (r.s >= finishMetres)
                {
                    r.finished = true;
                    r.finishTime = raceTime;
                    r.speed = 0f;
                }
            }
            Place(r);
            if (r.rig) r.rig.externalSpeed = r.speed;
            bool near = (r.position - playerPos).sqrMagnitude < 230f * 230f;
            if (r.tr.gameObject.activeSelf != near) r.tr.gameObject.SetActive(near);
        }
    }

    /// <summary>1 = first. Counts riders who are further along than the player.</summary>
    public int Position(float playerMetres)
    {
        int ahead = 0;
        foreach (var r in Riders) if (r.finished || r.s > playerMetres) ahead++;
        return ahead + 1;
    }

    public int Count => Riders.Count;

    /// <summary>Finishing order including the player ("YOU") with times; riders still on the trail get an estimate.</summary>
    public List<KeyValuePair<string, float>> Results(float playerTime)
    {
        var list = new List<KeyValuePair<string, float>> { new KeyValuePair<string, float>("YOU", playerTime) };
        foreach (var r in Riders)
        {
            float t = r.finished ? r.finishTime : playerTime + Mathf.Max(0.5f, (finishMetres - r.s) / Mathf.Max(3f, r.baseSpeed * 0.85f));
            list.Add(new KeyValuePair<string, float>(r.name, t));
        }
        list.Sort((a, b) => a.Value.CompareTo(b.Value));
        return list;
    }

    public static string Ordinal(int n)
    {
        if (n % 100 >= 11 && n % 100 <= 13) return n + "th";
        switch (n % 10)
        {
            case 1: return n + "st";
            case 2: return n + "nd";
            case 3: return n + "rd";
            default: return n + "th";
        }
    }
}
