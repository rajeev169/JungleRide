using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// The centre line of the jungle trail: one point every 4 m, generated on demand from noise,
/// so the same seed always gives the same trail and endless mode can keep going forever.
/// </summary>
public class TrailPath
{
    public const float SegLen = 4f;
    public const int StartIndex = 4;          // the bike starts on this point
    public const float TrailHalfWidth = 3.4f; // ridable dirt strip

    // Cross-section of the ground: lateral offset (m) -> height above the trail centre (m).
    // The banks rise steeply so you stay in the jungle corridor.
    public static readonly float[] Offsets = { -34f, -20f, -11f, -6f, -3.4f, -1.5f, 0f, 1.5f, 3.4f, 6f, 11f, 20f, 34f };
    static readonly float[] Heights = { 12f, 7.5f, 3.2f, 0.9f, 0.08f, -0.04f, -0.06f, -0.04f, 0.08f, 0.9f, 3.2f, 7.5f, 12f };

    readonly TrackConfig cfg;
    readonly List<Vector3> pts = new List<Vector3>();
    readonly List<float> headings = new List<float>();

    public TrackConfig Config => cfg;

    public TrailPath(TrackConfig config)
    {
        cfg = config;
        pts.Add(Vector3.zero);
        headings.Add(0f);
    }

    /// <summary>Index of the finish line (int.MaxValue in endless mode).</summary>
    public int FinishIndex => cfg.endless ? int.MaxValue : StartIndex + Mathf.CeilToInt(cfg.length / SegLen);

    public Vector3 Point(int i)
    {
        if (i < 0) i = 0;
        Ensure(i + 1);
        return pts[i];
    }

    void Ensure(int i)
    {
        while (pts.Count <= i) Next();
    }

    void Next()
    {
        int i = pts.Count;
        float d = cfg.DifficultyAt(i * SegLen);
        float curv = cfg.curviness + (1f - cfg.curviness) * d * 0.6f;
        float hill = cfg.hilliness + (1f - cfg.hilliness) * d * 0.6f;

        // 0 = keep straight & flat (start area, after the finish), 1 = full noise
        float shape = Mathf.Clamp01((i - 10) / 10f);
        if (!cfg.endless) shape *= Mathf.Clamp01((FinishIndex - 4 - i) / 10f);

        float s = cfg.seed * 0.0137f;
        float n1 = Mathf.PerlinNoise(s + 0.5f, i * 0.035f) * 2f - 1f;
        float n2 = Mathf.PerlinNoise(s + 3.3f, i * 0.11f) * 2f - 1f;
        float prevHeading = headings[i - 1];
        float turn = (n1 * 0.75f + n2 * 0.25f) * (2f + 7f * curv) * shape;
        float heading = Mathf.Clamp(prevHeading + turn - prevHeading * 0.03f, -65f, 65f); // keeps the trail heading forward

        Vector3 prev = pts[i - 1];
        float big = (Mathf.PerlinNoise(s + 7.7f, i * 0.018f) * 2f - 1f) * (4f + 16f * hill);
        float small = (Mathf.PerlinNoise(s + 1.1f, i * 0.07f) * 2f - 1f) * (0.5f + 2.5f * hill);
        float targetY = Mathf.Lerp(prev.y, big + small, shape);
        float maxStep = SegLen * (0.12f + 0.12f * hill);
        float y = prev.y + Mathf.Clamp(targetY - prev.y, -maxStep, maxStep);

        float rad = heading * Mathf.Deg2Rad;
        Vector3 dir = new Vector3(Mathf.Sin(rad), 0f, Mathf.Cos(rad));
        Vector3 p = prev + dir * SegLen;
        p.y = y;
        pts.Add(p);
        headings.Add(heading);
    }

    /// <summary>Flat (horizontal) direction of travel at point i.</summary>
    public Vector3 Forward(int i)
    {
        Vector3 a = Point(i + 1) - Point(Mathf.Max(0, i - 1));
        a.y = 0f;
        return a.sqrMagnitude < 1e-6f ? Vector3.forward : a.normalized;
    }

    public Vector3 Right(int i)
    {
        Vector3 f = Forward(i);
        return new Vector3(f.z, 0f, -f.x);
    }

    /// <summary>Organic bumps on the banks (not on the dirt strip).</summary>
    public static float BankNoise(Vector3 worldXZ, float lateral)
    {
        float edge = Mathf.Clamp01((Mathf.Abs(lateral) - 3.4f) / 8f);
        float n = Mathf.PerlinNoise(worldXZ.x * 0.08f + 100f, worldXZ.z * 0.08f + 100f) * 2f - 1f;
        float n2 = Mathf.PerlinNoise(worldXZ.x * 0.25f + 50f, worldXZ.z * 0.25f + 50f) * 2f - 1f;
        return (n * 2.2f + n2 * 0.5f) * edge;
    }

    public static float ProfileHeight(float lateral)
    {
        if (lateral <= Offsets[0]) return Heights[0];
        for (int k = 1; k < Offsets.Length; k++)
        {
            if (lateral <= Offsets[k])
            {
                float t = (lateral - Offsets[k - 1]) / (Offsets[k] - Offsets[k - 1]);
                return Mathf.Lerp(Heights[k - 1], Heights[k], t);
            }
        }
        return Heights[Heights.Length - 1];
    }

    /// <summary>World position of the ground at point i, offset sideways by <paramref name="lateral"/> metres.</summary>
    public Vector3 Surface(int i, float lateral)
    {
        Vector3 p = Point(i) + Right(i) * lateral;
        p.y = Point(i).y + ProfileHeight(lateral) + BankNoise(p, lateral);
        return p;
    }

    /// <summary>Closest path index to a world position, searching near a previous guess.</summary>
    public int ClosestIndex(Vector3 pos, int guess)
    {
        int best = Mathf.Max(0, guess);
        float bestD = float.MaxValue;
        for (int i = Mathf.Max(0, guess - 8); i <= guess + 14; i++)
        {
            Vector3 p = Point(i);
            float dx = p.x - pos.x, dz = p.z - pos.z;
            float dd = dx * dx + dz * dz;
            if (dd < bestD) { bestD = dd; best = i; }
        }
        return best;
    }

    public float LateralOffset(Vector3 pos, int i)
    {
        Vector3 d = pos - Point(i);
        d.y = 0f;
        return Vector3.Dot(d, Right(i));
    }
}
