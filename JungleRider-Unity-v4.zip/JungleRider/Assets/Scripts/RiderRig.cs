using System.Collections.Generic;
using System.IO;
using UnityEngine;

/// <summary>
/// The rider + bike model brought to life:
///  - the old wheels were cut out of the TRELLIS model and replaced with real 3D wheels that spin with the bike's speed
///    (the back wheel locks in a hard brake skid, the front wheel turns a little with steering),
///  - a crank with two pedals turns while pedalling,
///  - the legs pedal (bending at hip and knee, feet follow the pedals),
///  - the upper body sways with each stroke, leans forward when pedalling hard, back when braking,
///    into turns, and crouches when landing after a jump; the head stays steadier.
/// Data comes from Resources/RiderRig.bytes (mesh + body-part weights) and Resources/RiderTexture.png.
/// All positions here are in the model's own units (the bike is ~1 unit long; it is scaled up later).
/// </summary>
public class RiderRig : MonoBehaviour
{
    // ----- data from the file -----
    Vector3[] basePos, livePos;
    float[] wThigh, wShin, wTorso, wHead;
    sbyte[] side;
    int[] moving;                  // only these vertices ever move
    Vector2 H, K, A;               // hip, knee, ankle (z, y) in the side plane
    Mesh mesh;

    // ----- pedalling geometry -----
    const float PedalRadius = 0.055f;
    static readonly Vector2 FootToPedal = new Vector2(0.03f, -0.05f);
    Vector2 ankleCentre, bottomBracket;
    float L1, L2, aKnee0, aShin0;

    // ----- parts -----
    Transform rearWheel, frontWheel, frontSteer;
    float wheelRadius;
    Transform[] crankArms = new Transform[2], pedals = new Transform[2];

    // ----- animation state -----
    BikeController bike;
    BikeInput input;
    float crankAngle = Mathf.PI, crankSpeed;
    float rearSpin, frontSpin;
    float pitch, roll, crouch, airTime;
    bool wasGrounded = true;

    public static GameObject Build(Transform parent, BikeController bike)
    {
        var data = Resources.Load<TextAsset>("RiderRig");
        if (data == null) return null;
        var go = new GameObject("RiderRig");
        go.transform.SetParent(parent, false);
        var rig = go.AddComponent<RiderRig>();
        rig.bike = bike;
        rig.input = bike ? bike.input : null;
        try { rig.Load(data.bytes); }
        catch (System.Exception e)
        {
            Debug.LogWarning("RiderRig could not load: " + e.Message);
            Destroy(go);
            return null;
        }
        return go;
    }

    void Load(byte[] bytes)
    {
        using (var br = new BinaryReader(new MemoryStream(bytes)))
        {
            if (new string(br.ReadChars(4)) != "RRIG") throw new IOException("bad header");
            br.ReadInt32(); // version
            int nV = br.ReadInt32(), nI = br.ReadInt32();
            basePos = new Vector3[nV];
            for (int i = 0; i < nV; i++) basePos[i] = new Vector3(br.ReadSingle(), br.ReadSingle(), br.ReadSingle());
            var uv = new Vector2[nV];
            for (int i = 0; i < nV; i++) uv[i] = new Vector2(br.ReadSingle(), br.ReadSingle());
            var idx = new int[nI];
            for (int i = 0; i < nI; i++) idx[i] = br.ReadInt32();
            wThigh = ReadFloats(br, nV); wShin = ReadFloats(br, nV); wTorso = ReadFloats(br, nV); wHead = ReadFloats(br, nV);
            side = new sbyte[nV];
            for (int i = 0; i < nV; i++) side[i] = br.ReadSByte();
            H = new Vector2(br.ReadSingle(), br.ReadSingle());
            K = new Vector2(br.ReadSingle(), br.ReadSingle());
            A = new Vector2(br.ReadSingle(), br.ReadSingle());
            Vector3 rear = new Vector3(br.ReadSingle(), br.ReadSingle(), br.ReadSingle());
            Vector3 front = new Vector3(br.ReadSingle(), br.ReadSingle(), br.ReadSingle());

            mesh = new Mesh { name = "RiderBody" };
            if (nV > 65000) mesh.indexFormat = UnityEngine.Rendering.IndexFormat.UInt32;
            mesh.vertices = basePos;
            mesh.uv = uv;
            mesh.triangles = idx;
            mesh.RecalculateNormals();
            mesh.RecalculateBounds();
            mesh.MarkDynamic();
            livePos = (Vector3[])basePos.Clone();

            var list = new List<int>();
            for (int i = 0; i < nV; i++) if (wThigh[i] + wShin[i] + wTorso[i] > 0.001f) list.Add(i);
            moving = list.ToArray();

            var tex = Resources.Load<Texture2D>("RiderTexture");
            var shader = Shader.Find("JungleRider/TexturedLit");
            if (shader == null) shader = Shader.Find("Standard");
            var mat = new Material(shader) { name = "RiderBody" };
            if (tex) { tex.wrapMode = TextureWrapMode.Clamp; mat.mainTexture = tex; }
            var body = new GameObject("Body");
            body.transform.SetParent(transform, false);
            body.AddComponent<MeshFilter>().sharedMesh = mesh;
            body.AddComponent<MeshRenderer>().sharedMaterial = mat;

            BuildWheels(rear, front);
        }

        // pedalling circle: the ankle travels round a circle that passes through its modelled position
        ankleCentre = new Vector2(A.x + PedalRadius, A.y);
        bottomBracket = ankleCentre + FootToPedal;
        L1 = Vector2.Distance(H, K);
        L2 = Vector2.Distance(K, A);
        aKnee0 = Mathf.Atan2(K.y - H.y, K.x - H.x);
        aShin0 = Mathf.Atan2(A.y - K.y, A.x - K.x);
        BuildCrank();
    }

    static float[] ReadFloats(BinaryReader br, int n)
    {
        var a = new float[n];
        for (int i = 0; i < n; i++) a[i] = br.ReadSingle();
        return a;
    }

    // ------------------------------------------------------------------ parts
    static Material Mat(Color c, Color spec, float shininess)
    {
        var shader = Shader.Find("JungleRider/Metal");
        if (shader == null) shader = Shader.Find("Standard");
        var m = new Material(shader);
        m.SetColor("_Color", c);
        m.SetColor("_SpecColor", spec);
        m.SetFloat("_Shininess", shininess);
        m.SetFloat("_Rim", 0.15f);
        return m;
    }

    void BuildWheels(Vector3 rear, Vector3 front)
    {
        // rear/front are (z, y, radius) of the old wheels in the model
        wheelRadius = (rear.z + front.z) * 0.5f;
        var tyreMat = Mat(new Color(0.1f, 0.1f, 0.1f), new Color(0.15f, 0.15f, 0.15f), 0.1f);
        var rimMat = Mat(new Color(0.25f, 0.68f, 0.23f), new Color(0.6f, 0.6f, 0.6f), 0.4f);
        var metalMat = Mat(new Color(0.78f, 0.8f, 0.83f), Color.white, 0.5f);
        var hubMat = Mat(new Color(0.2f, 0.2f, 0.2f), new Color(0.5f, 0.5f, 0.5f), 0.4f);

        Mesh tyre = WheelTyreMesh(wheelRadius), rim = TorusMesh(wheelRadius * 0.7f, wheelRadius * 0.045f, 40, 8);
        Mesh spokes = SpokeMesh(wheelRadius);

        rearWheel = MakeWheel("RearWheel", new Vector3(0.005f, rear.y, rear.x), tyre, rim, spokes, tyreMat, rimMat, metalMat, hubMat, transform);
        frontSteer = new GameObject("FrontSteer").transform;
        frontSteer.SetParent(transform, false);
        frontSteer.localPosition = new Vector3(0.005f, front.y, front.x);
        frontWheel = MakeWheel("FrontWheel", Vector3.zero, tyre, rim, spokes, tyreMat, rimMat, metalMat, hubMat, frontSteer);
    }

    Transform MakeWheel(string name, Vector3 pos, Mesh tyre, Mesh rim, Mesh spokes, Material tyreMat, Material rimMat, Material metalMat, Material hubMat, Transform parent)
    {
        var w = new GameObject(name).transform;
        w.SetParent(parent, false);
        w.localPosition = pos;
        AddMesh(w, tyre, tyreMat);
        AddMesh(w, rim, rimMat);
        AddMesh(w, spokes, metalMat);
        var hub = AddMesh(w, CylinderX(wheelRadius * 0.1f, wheelRadius * 0.35f, 16), hubMat);
        var disc = AddMesh(w, CylinderX(wheelRadius * 0.38f, 0.004f, 28), metalMat);
        disc.localPosition = new Vector3(0.03f, 0, 0);
        return w;
    }

    static Transform AddMesh(Transform parent, Mesh m, Material mat)
    {
        var go = new GameObject(m.name);
        go.transform.SetParent(parent, false);
        go.AddComponent<MeshFilter>().sharedMesh = m;
        var r = go.AddComponent<MeshRenderer>();
        r.sharedMaterial = mat;
        return go.transform;
    }

    /// <summary>Torus around the X axis (wheel lies in the Y-Z plane).</summary>
    static Mesh TorusMesh(float R, float r, int seg, int tube)
    {
        var v = new List<Vector3>(); var n = new List<Vector3>(); var t = new List<int>();
        for (int i = 0; i <= seg; i++)
        {
            float a = i * Mathf.PI * 2f / seg;
            Vector3 dir = new Vector3(0, Mathf.Sin(a), Mathf.Cos(a));
            for (int j = 0; j <= tube; j++)
            {
                float b = j * Mathf.PI * 2f / tube;
                Vector3 nn = dir * Mathf.Cos(b) + Vector3.right * Mathf.Sin(b);
                v.Add(dir * R + nn * r); n.Add(nn);
            }
        }
        for (int i = 0; i < seg; i++)
            for (int j = 0; j < tube; j++)
            {
                int a0 = i * (tube + 1) + j, a1 = a0 + tube + 1;
                t.Add(a0); t.Add(a0 + 1); t.Add(a1);
                t.Add(a1); t.Add(a0 + 1); t.Add(a1 + 1);
            }
        var m = new Mesh { name = "Torus" };
        m.SetVertices(v); m.SetNormals(n); m.SetTriangles(t, 0);
        FixWinding(m);
        return m;
    }

    /// <summary>Makes every triangle face outward (the same direction as its vertex normals).</summary>
    static void FixWinding(Mesh m)
    {
        var v = m.vertices; var n = m.normals; var t = m.triangles;
        for (int i = 0; i < t.Length; i += 3)
        {
            Vector3 fn = Vector3.Cross(v[t[i + 1]] - v[t[i]], v[t[i + 2]] - v[t[i]]);
            if (Vector3.Dot(fn, n[t[i]] + n[t[i + 1]] + n[t[i + 2]]) < 0f) { int k = t[i + 1]; t[i + 1] = t[i + 2]; t[i + 2] = k; }
        }
        m.triangles = t;
        m.RecalculateBounds();
    }

    static Mesh WheelTyreMesh(float R)
    {
        var torus = TorusMesh(R * 0.86f, R * 0.15f, 48, 12);
        // knobbly tread blocks
        var mb = new MeshBuilder();
        for (int i = 0; i < 40; i++)
        {
            float a = i / 40f * Mathf.PI * 2f;
            Vector3 p = new Vector3(0, Mathf.Sin(a), Mathf.Cos(a)) * R;
            mb.Box(p, new Vector3(R * 0.26f, R * 0.08f, R * 0.09f), Quaternion.Euler(90f - a * Mathf.Rad2Deg, 0, 0), new Color(0.1f, 0.1f, 0.1f));
        }
        var knobs = mb.ToMesh("Knobs");
        var combine = new[]
        {
            new CombineInstance { mesh = torus, transform = Matrix4x4.identity },
            new CombineInstance { mesh = knobs, transform = Matrix4x4.identity },
        };
        var m = new Mesh { name = "Tyre" };
        m.CombineMeshes(combine, true, true);
        return m;
    }

    static Mesh SpokeMesh(float R)
    {
        var parts = new List<CombineInstance>();
        var spoke = CylinderY(0.0025f, R * 0.66f, 5);
        for (int i = 0; i < 24; i++)
        {
            float a = i / 24f * Mathf.PI * 2f;
            Vector3 dir = new Vector3(0, Mathf.Sin(a), Mathf.Cos(a));
            var mtx = Matrix4x4.TRS(dir * R * 0.36f + Vector3.right * ((i % 2 == 0) ? 0.006f : -0.006f), Quaternion.FromToRotation(Vector3.up, dir), Vector3.one);
            parts.Add(new CombineInstance { mesh = spoke, transform = mtx });
        }
        var m = new Mesh { name = "Spokes" };
        m.CombineMeshes(parts.ToArray(), true, true);
        return m;
    }

    static Mesh CylinderY(float radius, float length, int sides)
    {
        var mb = new MeshBuilder();
        mb.Cylinder(new Vector3(0, -length / 2, 0), new Vector3(0, length / 2, 0), radius, radius, sides, Color.white);
        return mb.ToMesh("Cyl");
    }

    static Mesh CylinderX(float radius, float length, int sides)
    {
        var mb = new MeshBuilder();
        mb.Cylinder(new Vector3(-length / 2, 0, 0), new Vector3(length / 2, 0, 0), radius, radius, sides, Color.white);
        return mb.ToMesh("CylX");
    }

    void BuildCrank()
    {
        var crankMat = Mat(new Color(0.13f, 0.13f, 0.15f), new Color(0.6f, 0.6f, 0.65f), 0.4f);
        var ringMat = Mat(new Color(0.6f, 0.63f, 0.66f), Color.white, 0.5f);
        var pedalMat = Mat(new Color(0.1f, 0.1f, 0.1f), new Color(0.4f, 0.4f, 0.4f), 0.3f);
        var ring = AddMesh(transform, CylinderX(0.045f, 0.006f, 28), ringMat);
        ring.localPosition = new Vector3(-0.04f, bottomBracket.y, bottomBracket.x);
        var mb = new MeshBuilder();
        mb.Box(Vector3.zero, new Vector3(0.012f, 0.012f, 1f), Quaternion.identity, Color.white);
        var armMesh = mb.ToMesh("CrankArm");
        mb = new MeshBuilder();
        mb.Box(Vector3.zero, new Vector3(0.05f, 0.008f, 0.04f), Quaternion.identity, Color.white);
        var pedalMesh = mb.ToMesh("Pedal");
        for (int s = 0; s < 2; s++)
        {
            crankArms[s] = AddMesh(transform, armMesh, crankMat);
            pedals[s] = AddMesh(transform, pedalMesh, pedalMat);
        }
    }

    // ------------------------------------------------------------------ animation
    struct Leg { public Vector2 ankle, knee; public float thigh, shin; }

    Leg Solve(float angle)
    {
        Vector2 at = ankleCentre + new Vector2(Mathf.Cos(angle), Mathf.Sin(angle)) * PedalRadius;
        Vector2 d = at - H;
        float dist = Mathf.Clamp(d.magnitude, Mathf.Abs(L1 - L2) + 1e-4f, L1 + L2 - 1e-4f);
        float b = Mathf.Atan2(d.y, d.x);
        float a = Mathf.Acos(Mathf.Clamp((L1 * L1 + dist * dist - L2 * L2) / (2f * L1 * dist), -1f, 1f));
        Vector2 k1 = H + new Vector2(Mathf.Cos(b + a), Mathf.Sin(b + a)) * L1;
        Vector2 k2 = H + new Vector2(Mathf.Cos(b - a), Mathf.Sin(b - a)) * L1;
        Vector2 kn = k1.x > k2.x ? k1 : k2;   // knee points forward
        return new Leg
        {
            ankle = at,
            knee = kn,
            thigh = Mathf.Atan2(kn.y - H.y, kn.x - H.x) - aKnee0,
            shin = Mathf.Atan2(at.y - kn.y, at.x - kn.x) - aShin0,
        };
    }

    static Vector2 Rot(Vector2 p, Vector2 c, float a)
    {
        float cs = Mathf.Cos(a), sn = Mathf.Sin(a);
        Vector2 d = p - c;
        return new Vector2(c.x + d.x * cs - d.y * sn, c.y + d.x * sn + d.y * cs);
    }

    void LateUpdate()
    {
        if (mesh == null) return;
        float dt = Time.deltaTime;
        if (dt <= 0f) return;   // paused

        float speed = bike ? bike.ForwardSpeed : 0f;
        bool grounded = !bike || bike.Grounded;
        float thr = input ? input.Throttle : 0f, brk = input ? input.Brake : 0f, steer = input ? input.Steer : 0f;
        float effort = Mathf.Clamp01(crankSpeed / 6f);

        // ---- wheels: spin with the real speed; back wheel locks in a hard brake skid ----
        float worldRadius = wheelRadius * Mathf.Max(0.0001f, transform.lossyScale.y);
        float spin = speed / worldRadius * Mathf.Rad2Deg * dt;
        frontSpin += spin;
        bool locked = brk > 0f && grounded && Mathf.Abs(speed) > 1f;
        if (!locked || !grounded) rearSpin += spin;
        if (rearWheel) rearWheel.localRotation = Quaternion.Euler(rearSpin, 0f, 0f);
        if (frontWheel) frontWheel.localRotation = Quaternion.Euler(frontSpin, 0f, 0f);
        if (frontSteer) frontSteer.localRotation = Quaternion.Euler(0f, steer * 8f, 0f);

        // ---- crank: turns while pedalling (faster when faster), stops when coasting ----
        float target = thr > 0f ? 2.2f + Mathf.Abs(speed) * 0.45f : 0f;
        crankSpeed = Mathf.Lerp(crankSpeed, target, dt * (thr > 0f ? 3f : 2f));
        crankAngle += crankSpeed * dt;

        // ---- landing crouch ----
        if (!grounded) airTime += dt;
        if (grounded && !wasGrounded && airTime > 0.25f) crouch = 1f;
        if (grounded) airTime = 0f;
        wasGrounded = grounded;
        crouch = Mathf.MoveTowards(crouch, 0f, dt * 2.2f);
        float crouchShape = Mathf.Sin(crouch * Mathf.PI);

        // ---- upper body ----
        float targetPitch = -0.07f * effort;                // lean forward while pushing
        if (brk > 0f && Mathf.Abs(speed) > 0.5f) targetPitch = 0.09f; // lean back on the brakes
        pitch = Mathf.Lerp(pitch, targetPitch, dt * 5f);
        float swayRoll = 0.05f * Mathf.Sin(crankAngle) * effort;
        roll = Mathf.Lerp(roll, -steer * 0.06f, dt * 4f);
        float p = pitch - 0.12f * crouchShape;
        float r = roll + swayRoll;
        float dy = -0.02f * crouchShape;
        float headPitch = -0.55f * p + 0.02f * Mathf.Sin(crankAngle * 2f) * effort;

        // ---- legs + body skinning ----
        Leg right = Solve(crankAngle), left = Solve(crankAngle + Mathf.PI);
        float cr = Mathf.Cos(r), sr = Mathf.Sin(r);
        Vector2 torsoPivot = new Vector2(-0.1f, 0.04f), neckPivot = new Vector2(0.03f, 0.27f);
        for (int n = 0; n < moving.Length; n++)
        {
            int i = moving[n];
            Vector3 v = basePos[i];
            Vector2 zy = new Vector2(v.z, v.y);
            Vector3 o = v;
            float wt = wThigh[i], ws = wShin[i];
            if (wt + ws > 0f)
            {
                Leg L = side[i] > 0 ? right : left;
                Vector2 t = Rot(zy, H, L.thigh);
                Vector2 s = L.knee + (Rot(zy, K, L.shin) - K);
                float w0 = 1f - wt - ws;
                Vector2 z2 = zy * w0 + t * wt + s * ws;
                o = new Vector3(v.x, z2.y, z2.x);
            }
            float wT = wTorso[i];
            if (wT > 0f)
            {
                Vector2 tz = Rot(zy, torsoPivot, p);
                float wh = wHead[i];
                if (wh > 0f) tz = Vector2.Lerp(tz, Rot(tz, neckPivot, headPitch), wh);
                float x = v.x, y = tz.y;
                float rx = x * cr - (y - 0.04f) * sr;
                float ry = 0.04f + x * sr + (y - 0.04f) * cr + dy;
                o = Vector3.Lerp(o, new Vector3(rx, ry, tz.x), wT);
            }
            livePos[i] = o;
        }
        mesh.vertices = livePos;

        // ---- crank arms and pedals ----
        for (int s = 0; s < 2; s++)
        {
            Leg L = s == 0 ? right : left;
            Vector2 ped = L.ankle + FootToPedal;
            Vector2 mid = (bottomBracket + ped) * 0.5f;
            float sideX = s == 0 ? 0.075f : -0.075f;
            crankArms[s].localPosition = new Vector3(sideX, mid.y, mid.x);
            crankArms[s].localRotation = Quaternion.Euler(-Mathf.Atan2(ped.y - bottomBracket.y, ped.x - bottomBracket.x) * Mathf.Rad2Deg, 0f, 0f);
            crankArms[s].localScale = new Vector3(1f, 1f, PedalRadius);
            pedals[s].localPosition = new Vector3(s == 0 ? 0.095f : -0.095f, ped.y - 0.004f, ped.x);
        }
    }
}
