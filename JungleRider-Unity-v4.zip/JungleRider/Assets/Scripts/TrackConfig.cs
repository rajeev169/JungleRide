using UnityEngine;

public enum GameMode { TrailRace, Endless, Levels }

/// <summary>Describes one trail: how long, how twisty, how hilly, how many obstacles.</summary>
[System.Serializable]
public class TrackConfig
{
    public string title;
    public int seed;
    public bool endless;
    public float length = 1000f;          // metres (ignored when endless)
    public float curviness = 0.5f;        // 0..1
    public float hilliness = 0.5f;        // 0..1
    public float obstacles = 0.4f;        // 0..1 logs & rocks on the trail
    public float ramps = 0.3f;            // 0..1
    public float checkpointEvery = 250f;  // metres

    public const int LevelCount = 5;

    public static TrackConfig TrailRace() => new TrackConfig
    {
        title = "Trail Race", seed = 7341, length = 1200f,
        curviness = 0.55f, hilliness = 0.55f, obstacles = 0.45f, ramps = 0.4f, checkpointEvery = 300f
    };

    public static TrackConfig Endless() => new TrackConfig
    {
        title = "Endless Ride", seed = Random.Range(1, 99999), endless = true,
        curviness = 0.3f, hilliness = 0.3f, obstacles = 0.2f, ramps = 0.25f, checkpointEvery = 400f
    };

    /// <summary>Levels 1..5 get longer and harder.</summary>
    public static TrackConfig Level(int level)
    {
        float t = (level - 1) / (float)(LevelCount - 1);
        return new TrackConfig
        {
            title = "Level " + level,
            seed = 500 + level * 97,
            length = Mathf.Round(Mathf.Lerp(500f, 1400f, t)),
            curviness = Mathf.Lerp(0.25f, 0.85f, t),
            hilliness = Mathf.Lerp(0.25f, 0.9f, t),
            obstacles = Mathf.Lerp(0.15f, 0.75f, t),
            ramps = Mathf.Lerp(0.2f, 0.6f, t),
            checkpointEvery = Mathf.Lerp(150f, 250f, t),
        };
    }

    /// <summary>Endless mode gets harder the further you ride. Returns 0..1.</summary>
    public float DifficultyAt(float metres)
    {
        return endless ? Mathf.Clamp01(metres / 3000f) : 0f;
    }
}
