using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

/// <summary>All screens: main menu, level select, settings, HUD, touch controls, pause and results.</summary>
public class GameUI : MonoBehaviour
{
    // events the game listens to
    public Action OnPause, OnResume, OnRestart, OnMainMenu, OnNextLevel;
    public Action<Season> OnTrailRace, OnEndless;
    public Action<int> OnLevel;
    public Action OnControlsChanged;

    GameObject menu, levels, settings, hud, pause, result, seasonPick;
    Action<Season> seasonCallback;
    Text todayLabel;
    ControlIcons icons;
    GameObject ctrlButtons, ctrlTilt, ctrlJoystick, ctrlPedals;
    Text menuBest, hudInfo, hudSpeed, countdown, toast, resultTitle, resultBody, tiltValue, settingsHint;
    Button nextLevelButton;
    readonly List<Button> levelButtons = new List<Button>();
    readonly Dictionary<ControlMode, Button> controlButtons = new Dictionary<ControlMode, Button>();
    bool settingsFromPause;
    float toastUntil;

    public BikeInput Controls { get; private set; }

    public static GameUI Create(BikeInput input, ControlIcons icons)
    {
        var canvasGo = new GameObject("UI", typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
        var canvas = canvasGo.GetComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        canvas.sortingOrder = 10;
        var scaler = canvasGo.GetComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920, 1080);
        scaler.matchWidthOrHeight = 0.6f;

        if (EventSystem.current == null)
        {
            var es = new GameObject("EventSystem", typeof(EventSystem));
#if ENABLE_INPUT_SYSTEM
            es.AddComponent<UnityEngine.InputSystem.UI.InputSystemUIInputModule>();
#else
            es.AddComponent<StandaloneInputModule>();
#endif
        }

        var ui = canvasGo.AddComponent<GameUI>();
        ui.Controls = input;
        ui.icons = icons;
        ui.Build(canvasGo.transform);
        return ui;
    }

    // ------------------------------------------------------------------ build
    void Build(Transform root)
    {
        BuildMenu(root);
        BuildLevels(root);
        BuildHud(root);
        BuildControls(root);
        BuildPause(root);
        BuildResult(root);
        BuildSeasonPicker(root);
        BuildSettings(root);   // last, so it draws on top of pause

        countdown = UIFactory.Label(root, "", 200, TextAnchor.MiddleCenter, Color.white, new Vector2(0.5f, 0.55f), Vector2.zero, new Vector2(800, 300));
        toast = UIFactory.Label(root, "", 60, TextAnchor.MiddleCenter, new Color(1f, 0.92f, 0.4f), new Vector2(0.5f, 0.75f), Vector2.zero, new Vector2(1400, 120));
    }

    void BuildMenu(Transform root)
    {
        menu = UIFactory.Stretch("Menu", root).gameObject;
        var side = UIFactory.Panel("Side", menu.transform, new Vector2(0f, 0.5f), new Vector2(380, 0), new Vector2(700, 1000), UIFactory.Dark);
        var t = side.transform;
        UIFactory.Label(t, "JUNGLE RIDER", 92, TextAnchor.MiddleCenter, new Color(0.6f, 1f, 0.4f), new Vector2(0.5f, 1f), new Vector2(0, -90), new Vector2(680, 120));
        UIFactory.Label(t, "OFFROAD", 60, TextAnchor.MiddleCenter, new Color(1f, 0.8f, 0.3f), new Vector2(0.5f, 1f), new Vector2(0, -170), new Vector2(680, 80));
        UIFactory.MakeButton(t, "TRAIL RACE", new Vector2(0.5f, 1f), new Vector2(0, -300), new Vector2(560, 120), UIFactory.Green, () => OpenSeasonPicker(sn => OnTrailRace?.Invoke(sn)));
        UIFactory.MakeButton(t, "ENDLESS RIDE", new Vector2(0.5f, 1f), new Vector2(0, -440), new Vector2(560, 120), UIFactory.Green, () => OpenSeasonPicker(sn => OnEndless?.Invoke(sn)));
        UIFactory.MakeButton(t, "LEVELS", new Vector2(0.5f, 1f), new Vector2(0, -580), new Vector2(560, 120), UIFactory.Green, () => Show(levels));
        UIFactory.MakeButton(t, "SETTINGS", new Vector2(0.5f, 1f), new Vector2(0, -720), new Vector2(560, 120), UIFactory.Grey, () => OpenSettings(false));
        menuBest = UIFactory.Label(t, "", 34, TextAnchor.MiddleCenter, new Color(0.85f, 0.95f, 0.85f), new Vector2(0.5f, 0f), new Vector2(0, 110), new Vector2(660, 140));
    }

    void BuildLevels(Transform root)
    {
        levels = UIFactory.Stretch("Levels", root).gameObject;
        var p = UIFactory.Panel("Box", levels.transform, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(1500, 820), UIFactory.Dark);
        UIFactory.Label(p.transform, "LEVELS", 80, TextAnchor.MiddleCenter, Color.white, new Vector2(0.5f, 1f), new Vector2(0, -80), new Vector2(1000, 110));
        for (int i = 1; i <= TrackConfig.LevelCount; i++)
        {
            int level = i;
            float x = (i - 3) * 270f;
            var b = UIFactory.MakeButton(p.transform, "", new Vector2(0.5f, 0.5f), new Vector2(x, 20), new Vector2(240, 260), UIFactory.Green, () => OnLevel?.Invoke(level), 40);
            levelButtons.Add(b);
        }
        UIFactory.MakeButton(p.transform, "BACK", new Vector2(0.5f, 0f), new Vector2(0, 110), new Vector2(360, 110), UIFactory.Grey, () => ShowMenu());
    }

    void BuildSettings(Transform root)
    {
        settings = UIFactory.Stretch("Settings", root).gameObject;
        var dim = settings.AddComponent<Image>();
        dim.color = new Color(0, 0, 0, 0.45f);
        var p = UIFactory.Panel("Box", settings.transform, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(1500, 900), UIFactory.Dark);
        var t = p.transform;
        UIFactory.Label(t, "SETTINGS", 80, TextAnchor.MiddleCenter, Color.white, new Vector2(0.5f, 1f), new Vector2(0, -80), new Vector2(1000, 110));
        UIFactory.Label(t, "Steering controls", 46, TextAnchor.MiddleCenter, new Color(0.8f, 1f, 0.7f), new Vector2(0.5f, 1f), new Vector2(0, -190), new Vector2(1000, 70));

        AddControlOption(t, ControlMode.Buttons, "BUTTONS", -440);
        AddControlOption(t, ControlMode.Tilt, "TILT PHONE", 0);
        AddControlOption(t, ControlMode.Joystick, "JOYSTICK", 440);
        settingsHint = UIFactory.Label(t, "", 34, TextAnchor.MiddleCenter, new Color(0.9f, 0.9f, 0.9f), new Vector2(0.5f, 1f), new Vector2(0, -420), new Vector2(1300, 80));

        UIFactory.Label(t, "Tilt sensitivity", 42, TextAnchor.MiddleCenter, new Color(0.8f, 1f, 0.7f), new Vector2(0.5f, 1f), new Vector2(0, -510), new Vector2(1000, 70));
        UIFactory.MakeButton(t, "-", new Vector2(0.5f, 1f), new Vector2(-260, -610), new Vector2(130, 110), UIFactory.Grey, () => ChangeTilt(-0.1f), 70);
        UIFactory.MakeButton(t, "+", new Vector2(0.5f, 1f), new Vector2(260, -610), new Vector2(130, 110), UIFactory.Grey, () => ChangeTilt(0.1f), 70);
        tiltValue = UIFactory.Label(t, "", 54, TextAnchor.MiddleCenter, Color.white, new Vector2(0.5f, 1f), new Vector2(0, -610), new Vector2(300, 110));

        UIFactory.MakeButton(t, "DONE", new Vector2(0.5f, 0f), new Vector2(0, 100), new Vector2(360, 110), UIFactory.Green, CloseSettings);
    }

    void AddControlOption(Transform t, ControlMode mode, string label, float x)
    {
        var b = UIFactory.MakeButton(t, label, new Vector2(0.5f, 1f), new Vector2(x, -320), new Vector2(400, 120), UIFactory.Grey, () =>
        {
            GameSettings.Control = mode;
            RefreshSettings();
            RefreshControls();
            OnControlsChanged?.Invoke();
        }, 42);
        controlButtons[mode] = b;
    }

    void BuildHud(Transform root)
    {
        hud = UIFactory.Stretch("HUD", root).gameObject;
        var info = UIFactory.Panel("Info", hud.transform, new Vector2(0f, 1f), new Vector2(300, -70), new Vector2(560, 110), UIFactory.Dark);
        hudInfo = UIFactory.FillLabel(info.transform, "", 40, Color.white);
        var spd = UIFactory.Panel("Speed", hud.transform, new Vector2(0.5f, 1f), new Vector2(0, -70), new Vector2(300, 110), UIFactory.Dark);
        hudSpeed = UIFactory.FillLabel(spd.transform, "0 km/h", 46, Color.white);
        UIFactory.MakeButton(hud.transform, "II", new Vector2(1f, 1f), new Vector2(-90, -75), new Vector2(120, 120), UIFactory.Dark, () => OnPause?.Invoke(), 54, GameAudio.Ui.Pause);
    }

    void BuildControls(Transform root)
    {
        var c = UIFactory.Stretch("Controls", hud.transform);

        // right side: pedal + brake (all modes)
        ctrlPedals = UIFactory.Stretch("Pedals", c).gameObject;
        // 3D icons, no background: the touch area is an invisible box around each icon
        Controls.gas = IconButton(ctrlPedals.transform, "Pedal", icons ? icons.PedalTexture : null, new Vector2(1f, 0f), new Vector2(-190, 235), new Vector2(300, 368));
        Controls.brake = IconButton(ctrlPedals.transform, "Brake", icons ? icons.BrakeTexture : null, new Vector2(1f, 0f), new Vector2(-520, 180), new Vector2(320, 305));

        // left side: one of three steering styles
        ctrlButtons = UIFactory.Stretch("SteerButtons", c).gameObject;
        Controls.left = UIFactory.MakeHoldButton(ctrlButtons.transform, "<", new Vector2(0f, 0f), new Vector2(170, 170), new Vector2(240, 240), new Color(1f, 1f, 1f, 0.28f), 110);
        Controls.right = UIFactory.MakeHoldButton(ctrlButtons.transform, ">", new Vector2(0f, 0f), new Vector2(440, 170), new Vector2(240, 240), new Color(1f, 1f, 1f, 0.28f), 110);

        ctrlTilt = UIFactory.Stretch("SteerTilt", c).gameObject;
        UIFactory.Label(ctrlTilt.transform, "Tilt phone to steer", 36, TextAnchor.MiddleLeft, new Color(1f, 1f, 1f, 0.8f), new Vector2(0f, 0f), new Vector2(260, 80), new Vector2(460, 80));

        ctrlJoystick = UIFactory.Stretch("SteerJoystick", c).gameObject;
        var area = UIFactory.MakeRect("JoystickArea", ctrlJoystick.transform, new Vector2(0f, 0f), new Vector2(260, 260), new Vector2(340, 340));
        var bg = area.gameObject.AddComponent<Image>();
        bg.sprite = UIFactory.Circle;
        bg.color = new Color(1f, 1f, 1f, 0.2f);
        var knob = UIFactory.MakeRect("Knob", area, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(150, 150));
        var kimg = knob.gameObject.AddComponent<Image>();
        kimg.sprite = UIFactory.Circle;
        kimg.color = new Color(1f, 1f, 1f, 0.55f);
        kimg.raycastTarget = false;
        var joy = area.gameObject.AddComponent<VirtualJoystick>();
        joy.knob = knob;
        Controls.joystick = joy;

        RefreshControls();
    }

    HoldButton IconButton(Transform parent, string name, Texture tex, Vector2 anchor, Vector2 pos, Vector2 size)
    {
        var area = UIFactory.MakeRect(name + "Button", parent, anchor, pos, size);
        var hit = area.gameObject.AddComponent<Image>();
        hit.color = new Color(1f, 1f, 1f, 0f);           // invisible, but still catches touches
        if (tex != null)
        {
            var shadow = UIFactory.Stretch("Shadow", area).gameObject.AddComponent<RawImage>();
            shadow.texture = tex;
            shadow.color = new Color(0f, 0f, 0f, 0.45f);
            shadow.raycastTarget = false;
            ((RectTransform)shadow.transform).anchoredPosition = new Vector2(6f, -8f);
            var icon = UIFactory.Stretch("Icon", area).gameObject.AddComponent<RawImage>();
            icon.texture = tex;
            icon.raycastTarget = false;
        }
        else
        {
            UIFactory.FillLabel(area, name.ToUpper(), 46, Color.white);
        }
        var hb = area.gameObject.AddComponent<HoldButton>();
        hb.tintWhenPressed = false;
        return hb;
    }

    void BuildSeasonPicker(Transform root)
    {
        seasonPick = UIFactory.Stretch("SeasonPicker", root).gameObject;
        var p = UIFactory.Panel("Box", seasonPick.transform, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(1500, 820), UIFactory.Dark);
        var t = p.transform;
        UIFactory.Label(t, "CHOOSE SEASON", 76, TextAnchor.MiddleCenter, Color.white, new Vector2(0.5f, 1f), new Vector2(0, -80), new Vector2(1200, 110));
        UIFactory.MakeButton(t, "SUMMER", new Vector2(0.5f, 1f), new Vector2(-460, -260), new Vector2(400, 150), new Color(0.85f, 0.6f, 0.15f, 0.95f), () => PickSeason(Season.Summer), 46);
        UIFactory.MakeButton(t, "MONSOON", new Vector2(0.5f, 1f), new Vector2(0, -260), new Vector2(400, 150), new Color(0.2f, 0.45f, 0.6f, 0.95f), () => PickSeason(Season.Monsoon), 46);
        UIFactory.MakeButton(t, "WINTER", new Vector2(0.5f, 1f), new Vector2(460, -260), new Vector2(400, 150), new Color(0.55f, 0.62f, 0.7f, 0.95f), () => PickSeason(Season.Winter), 46);
        UIFactory.Label(t, "Summer: dry and fast    Monsoon: rain, slippery mud    Winter: thick fog", 32, TextAnchor.MiddleCenter, new Color(0.85f, 0.95f, 0.85f), new Vector2(0.5f, 1f), new Vector2(0, -380), new Vector2(1400, 60));
        var today = UIFactory.MakeButton(t, "", new Vector2(0.5f, 1f), new Vector2(-230, -500), new Vector2(420, 120), UIFactory.Green, () => PickSeason(Seasons.Today()), 38);
        todayLabel = today.GetComponentInChildren<Text>();
        UIFactory.MakeButton(t, "RANDOM", new Vector2(0.5f, 1f), new Vector2(230, -500), new Vector2(420, 120), UIFactory.Green, () => PickSeason(Seasons.Random()), 42);
        UIFactory.MakeButton(t, "BACK", new Vector2(0.5f, 0f), new Vector2(0, 100), new Vector2(360, 110), UIFactory.Grey, () => ShowMenu());
    }

    void OpenSeasonPicker(Action<Season> onPick)
    {
        seasonCallback = onPick;
        Show(seasonPick);
        if (todayLabel) todayLabel.text = "TODAY: " + Seasons.Name(Seasons.Today()).ToUpper();
    }

    void PickSeason(Season s)
    {
        var cb = seasonCallback;
        seasonCallback = null;
        cb?.Invoke(s);
    }

    void BuildPause(Transform root)
    {
        pause = UIFactory.Stretch("Pause", root).gameObject;
        var dim = pause.AddComponent<Image>();
        dim.color = new Color(0, 0, 0, 0.5f);
        var p = UIFactory.Panel("Box", pause.transform, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(700, 820), UIFactory.Dark);
        UIFactory.Label(p.transform, "PAUSED", 80, TextAnchor.MiddleCenter, Color.white, new Vector2(0.5f, 1f), new Vector2(0, -80), new Vector2(600, 110));
        UIFactory.MakeButton(p.transform, "RESUME", new Vector2(0.5f, 1f), new Vector2(0, -220), new Vector2(520, 115), UIFactory.Green, () => OnResume?.Invoke(), 44, GameAudio.Ui.Resume);
        UIFactory.MakeButton(p.transform, "RESTART", new Vector2(0.5f, 1f), new Vector2(0, -360), new Vector2(520, 115), UIFactory.Orange, () => OnRestart?.Invoke(), 44, GameAudio.Ui.Restart);
        UIFactory.MakeButton(p.transform, "SETTINGS", new Vector2(0.5f, 1f), new Vector2(0, -500), new Vector2(520, 115), UIFactory.Grey, () => OpenSettings(true));
        UIFactory.MakeButton(p.transform, "MAIN MENU", new Vector2(0.5f, 1f), new Vector2(0, -640), new Vector2(520, 115), UIFactory.Grey, () => OnMainMenu?.Invoke());
    }

    void BuildResult(Transform root)
    {
        result = UIFactory.Stretch("Result", root).gameObject;
        var dim = result.AddComponent<Image>();
        dim.color = new Color(0, 0, 0, 0.45f);
        var p = UIFactory.Panel("Box", result.transform, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(1100, 760), UIFactory.Dark);
        resultTitle = UIFactory.Label(p.transform, "", 90, TextAnchor.MiddleCenter, new Color(1f, 0.85f, 0.3f), new Vector2(0.5f, 1f), new Vector2(0, -90), new Vector2(1000, 130));
        resultBody = UIFactory.Label(p.transform, "", 46, TextAnchor.MiddleCenter, Color.white, new Vector2(0.5f, 0.5f), new Vector2(0, 50), new Vector2(1000, 300));
        UIFactory.MakeButton(p.transform, "RETRY", new Vector2(0.5f, 0f), new Vector2(-340, 110), new Vector2(300, 115), UIFactory.Orange, () => OnRestart?.Invoke(), 44, GameAudio.Ui.Restart);
        nextLevelButton = UIFactory.MakeButton(p.transform, "NEXT", new Vector2(0.5f, 0f), new Vector2(0, 110), new Vector2(300, 115), UIFactory.Green, () => OnNextLevel?.Invoke());
        UIFactory.MakeButton(p.transform, "MENU", new Vector2(0.5f, 0f), new Vector2(340, 110), new Vector2(300, 115), UIFactory.Grey, () => OnMainMenu?.Invoke());
    }

    // ------------------------------------------------------------------ screens
    void Show(GameObject screen)
    {
        foreach (var s in new[] { menu, levels, settings, hud, pause, result, seasonPick }) if (s) s.SetActive(s == screen);
        if (screen == levels) RefreshLevels();
    }

    public void ShowMenu()
    {
        Show(menu);
        countdown.text = "";
        toast.text = "";
        float bt = GameSettings.BestTrailTime;
        float be = GameSettings.BestEndless;
        menuBest.text = "Best trail time: " + GameSettings.FormatTime(bt) + "\nBest endless: " + Mathf.FloorToInt(be) + " m";
    }

    public void ShowHud()
    {
        Show(hud);
        RefreshControls();
    }

    public void ShowPause() { pause.SetActive(true); }
    public void HidePause() { pause.SetActive(false); settings.SetActive(false); }

    public void ShowResult(string title, string body, bool showNext)
    {
        hud.SetActive(false);
        pause.SetActive(false);
        result.SetActive(true);
        resultTitle.text = title;
        resultBody.text = body;
        nextLevelButton.gameObject.SetActive(showNext);
        countdown.text = "";
    }

    void OpenSettings(bool fromPause)
    {
        settingsFromPause = fromPause;
        settings.SetActive(true);
        if (!fromPause) menu.SetActive(false);
        RefreshSettings();
    }

    void CloseSettings()
    {
        settings.SetActive(false);
        if (!settingsFromPause) ShowMenu();
    }

    void ChangeTilt(float delta)
    {
        GameSettings.TiltSensitivity = Mathf.Round((GameSettings.TiltSensitivity + delta) * 10f) / 10f;
        RefreshSettings();
    }

    void RefreshSettings()
    {
        var current = GameSettings.Control;
        foreach (var kv in controlButtons)
            kv.Value.GetComponent<Image>().color = kv.Key == current ? UIFactory.Green : UIFactory.Grey;
        tiltValue.text = GameSettings.TiltSensitivity.ToString("0.0") + "x";
        switch (current)
        {
            case ControlMode.Buttons: settingsHint.text = "Left / right buttons to steer, PEDAL and BRAKE on the right."; break;
            case ControlMode.Tilt: settingsHint.text = "Turn the phone like a steering wheel. Hold it straight when the race starts."; break;
            default: settingsHint.text = "Drag the joystick left / right to steer, PEDAL and BRAKE on the right."; break;
        }
    }

    public void RefreshControls()
    {
        if (ctrlButtons == null) return;
        var mode = GameSettings.Control;
        ctrlButtons.SetActive(mode == ControlMode.Buttons);
        ctrlTilt.SetActive(mode == ControlMode.Tilt);
        ctrlJoystick.SetActive(mode == ControlMode.Joystick);
    }

    void RefreshLevels()
    {
        int unlocked = GameSettings.LevelsUnlocked;
        for (int i = 0; i < levelButtons.Count; i++)
        {
            int level = i + 1;
            bool open = level <= unlocked;
            levelButtons[i].interactable = open;
            levelButtons[i].GetComponent<Image>().color = open ? UIFactory.Green : UIFactory.Grey;
            float best = GameSettings.BestLevelTime(level);
            string text = "LEVEL " + level + "\n" + Seasons.Name(Seasons.ForLevel(level)).ToUpper();
            if (!open) text += "\n\nLOCKED";
            else text += "\n\n" + (best > 0 ? GameSettings.FormatTime(best) : "new");
            UIFactory.SetButtonText(levelButtons[i], text);
        }
    }

    // ------------------------------------------------------------------ HUD
    public void SetHud(string info, float kmh)
    {
        hudInfo.text = info;
        hudSpeed.text = Mathf.RoundToInt(kmh) + " km/h";
    }

    public void SetCountdown(string text) => countdown.text = text;

    public void Toast(string text, float seconds = 1.8f)
    {
        toast.text = text;
        toastUntil = Time.unscaledTime + seconds;
    }

    void Update()
    {
        if (toast.text.Length > 0 && Time.unscaledTime > toastUntil) toast.text = "";
    }
}
