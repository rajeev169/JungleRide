using System;
using UnityEngine;

/// <summary>
/// All game sound: soft jungle background (B4), monsoon rain and thunder, the brake skid (C5),
/// the pedal / chain / freewheel sounds (P2) that follow the bike's speed, and the wooden button knocks (UI_2).
/// Sound files live in Resources/Audio.
/// </summary>
public class GameAudio : MonoBehaviour
{
    public enum Ui { Tap, Pause, Resume, Restart }

    public static GameAudio I { get; private set; }
    public event Action OnThunder;

    AudioSource ambient, rain, skid, tyre, sfx, ui;
    AudioLowPassFilter ambientFilter, skidFilter;
    AudioClip brakeClick, freewheel, uiTap, uiPause, uiResume, uiRestart;
    AudioClip[] ticks, thumps, thunders;

    BikeController bike;
    BikeInput input;
    SeasonLook look = Seasons.Get(Season.Summer);
    bool riding, paused, wasBraking, wasPedalling;
    float nextTick, nextStroke, nextFreewheel, nextThunder;

    public static GameAudio Create()
    {
        var go = new GameObject("GameAudio");
        DontDestroyOnLoad(go);
        var a = go.AddComponent<GameAudio>();
        I = a;
        a.Setup();
        return a;
    }

    static AudioClip Load(string name)
    {
        var c = Resources.Load<AudioClip>("Audio/" + name);
        if (c == null) Debug.LogWarning("Missing sound: Audio/" + name);
        return c;
    }

    AudioSource Source(AudioClip clip, bool loop, float volume)
    {
        var s = gameObject.AddComponent<AudioSource>();
        s.clip = clip;
        s.loop = loop;
        s.volume = volume;
        s.playOnAwake = false;
        s.spatialBlend = 0f;
        s.ignoreListenerPause = true;
        return s;
    }

    void Setup()
    {
        brakeClick = Load("brake_click");
        freewheel = Load("freewheel_tick");
        uiTap = Load("ui_tap");
        uiPause = Load("ui_pause");
        uiResume = Load("ui_resume");
        uiRestart = Load("ui_restart");
        ticks = new[] { Load("chain_tick_0"), Load("chain_tick_1"), Load("chain_tick_2"), Load("chain_tick_3") };
        thumps = new[] { Load("pedal_thump_0"), Load("pedal_thump_1"), Load("pedal_thump_2") };
        thunders = new[] { Load("thunder_0"), Load("thunder_1") };

        // A low-pass filter affects every source on its GameObject, so filtered sources get their own child object.
        var ambGo = new GameObject("Ambient"); ambGo.transform.SetParent(transform, false);
        ambient = MakeChildSource(ambGo, Load("jungle_ambience"), true, 0f);
        ambientFilter = ambGo.AddComponent<AudioLowPassFilter>();
        ambientFilter.cutoffFrequency = 22000f;

        var skidGo = new GameObject("Skid"); skidGo.transform.SetParent(transform, false);
        skid = MakeChildSource(skidGo, Load("brake_skid_loop"), true, 0f);
        skidFilter = skidGo.AddComponent<AudioLowPassFilter>();
        skidFilter.cutoffFrequency = 22000f;

        rain = Source(Load("rain_loop"), true, 0f);
        tyre = Source(Load("tyre_roll_loop"), true, 0f);
        sfx = Source(null, false, 1f);
        ui = Source(null, false, 1f);

        foreach (var s in new[] { ambient, rain, skid, tyre }) if (s.clip) s.Play();
    }

    AudioSource MakeChildSource(GameObject go, AudioClip clip, bool loop, float volume)
    {
        var s = go.AddComponent<AudioSource>();
        s.clip = clip;
        s.loop = loop;
        s.volume = volume;
        s.playOnAwake = false;
        s.spatialBlend = 0f;
        s.ignoreListenerPause = true;
        return s;
    }

    public void Attach(BikeController b, BikeInput i)
    {
        bike = b;
        input = i;
    }

    public void SetSeason(SeasonLook l)
    {
        look = l;
        nextThunder = Time.unscaledTime + UnityEngine.Random.Range(8f, 20f);
    }

    /// <summary>Bike sounds only play while riding (not in menus or results).</summary>
    public void SetRiding(bool on) => riding = on;
    public void SetPaused(bool on) => paused = on;

    public void PlayUi(Ui kind)
    {
        AudioClip c = kind == Ui.Pause ? uiPause : kind == Ui.Resume ? uiResume : kind == Ui.Restart ? uiRestart : uiTap;
        if (c) ui.PlayOneShot(c, 0.55f);
    }

    void Update()
    {
        float dt = Time.unscaledDeltaTime;
        float now = Time.unscaledTime;

        // ---------- background ----------
        float ambTarget = 0.75f * look.ambientVolume * (paused ? 0.35f : 1f) * (riding ? 1f : 0.7f);
        ambient.volume = Mathf.MoveTowards(ambient.volume, ambTarget, dt * 0.5f);
        ambientFilter.cutoffFrequency = Mathf.Lerp(ambientFilter.cutoffFrequency, look.ambientCutoff, dt * 2f);
        float rainTarget = look.rain ? 0.6f * (paused ? 0.4f : 1f) : 0f;
        rain.volume = Mathf.MoveTowards(rain.volume, rainTarget, dt * 0.5f);

        if (look.rain && now > nextThunder)
        {
            var t = thunders[UnityEngine.Random.Range(0, thunders.Length)];
            if (t) sfx.PlayOneShot(t, 0.5f);
            OnThunder?.Invoke();
            nextThunder = now + UnityEngine.Random.Range(15f, 35f);
        }

        // ---------- bike ----------
        bool active = riding && !paused && bike && input;
        float speed = active ? Mathf.Abs(bike.ForwardSpeed) : 0f;
        float sp01 = Mathf.Clamp01(speed / 14f);
        bool grounded = active && bike.Grounded;

        // tyres rolling on the dirt
        tyre.volume = Mathf.Lerp(tyre.volume, grounded ? sp01 * 0.5f : 0f, dt * 6f);
        tyre.pitch = 0.8f + sp01 * 0.45f;

        // brake: soft click, then a skid that is longer/louder the faster you go
        bool braking = active && input.Brake > 0f;
        if (braking && !wasBraking && brakeClick) sfx.PlayOneShot(brakeClick, 0.5f);
        wasBraking = braking;
        float skidTarget = braking && grounded && speed > 1f ? Mathf.Clamp01(speed / 10f) * (look.rain ? 1f : 0.85f) : 0f;
        skid.volume = Mathf.Lerp(skid.volume, skidTarget, dt * (skidTarget > skid.volume ? 10f : 4f));
        skid.pitch = 0.85f + 0.25f * sp01;
        skidFilter.cutoffFrequency = look.rain ? 650f : 22000f;  // wetter, duller skid in the monsoon

        // pedalling: chain over the cogs + a soft push on every stroke; freewheel ticks when coasting
        bool pedalling = active && input.Throttle > 0f;
        if (pedalling && !wasPedalling) { nextTick = now; nextStroke = now + 0.05f; }
        wasPedalling = pedalling;
        if (pedalling)
        {
            float cadence = Mathf.Lerp(0.6f, 1.5f, sp01); // pedal turns per second
            if (now >= nextTick)
            {
                var c = ticks[UnityEngine.Random.Range(0, ticks.Length)];
                if (c) sfx.PlayOneShot(c, 0.16f + 0.08f * UnityEngine.Random.value);
                nextTick = now + 1f / (8f + cadence * 20f) * UnityEngine.Random.Range(0.85f, 1.15f);
            }
            if (now >= nextStroke)
            {
                var c = thumps[UnityEngine.Random.Range(0, thumps.Length)];
                if (c) sfx.PlayOneShot(c, 0.42f * UnityEngine.Random.Range(0.85f, 1.15f));
                nextStroke = now + 1f / (cadence * 2f) * UnityEngine.Random.Range(0.95f, 1.05f);
            }
        }
        else if (active && speed > 0.8f && freewheel)
        {
            if (now >= nextFreewheel)
            {
                sfx.PlayOneShot(freewheel, 0.06f + 0.14f * sp01);
                nextFreewheel = now + 1f / (6f + sp01 * 26f);
            }
        }
    }
}
