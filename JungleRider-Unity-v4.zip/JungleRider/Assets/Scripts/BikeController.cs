using UnityEngine;
#if UNITY_6000_0_OR_NEWER
using PhysMat = UnityEngine.PhysicsMaterial;
#else
using PhysMat = UnityEngine.PhysicMaterial;
#endif

/// <summary>
/// Arcade bicycle physics: two raycast "wheels" with springs, drive/brake force, sideways grip,
/// steering by yaw torque and a self-righting torque so the bike stays up (it leans only visually).
/// The bike's origin is at wheel-axle height, centred between the wheels.
/// </summary>
[RequireComponent(typeof(Rigidbody))]
public class BikeController : MonoBehaviour
{
    // ---- model fitting ----
    public const float ModelLength = 1.8f;      // the GLB is scaled so the bike is 1.8 m long
    public const float ModelYawOffset = 0f;     // rotate if the model faces the wrong way
    public const float AxleHeight = 0.35f;      // axle height above ground when resting

    [Header("Driving")]
    public float maxSpeed = 17f;          // m/s (about 60 km/h)
    public float acceleration = 7.5f;
    public float brakeDecel = 12f;
    public float reverseSpeed = 3f;
    public float turnRate = 95f;          // degrees per second
    public float lateralGrip = 9f;

    [Header("Season (ground)")]
    public float gripMul = 1f;    // monsoon mud is slippery
    public float brakeMul = 1f;   // longer braking in mud
    public float accelMul = 1f;

    [Header("Suspension")]
    public float wheelOffset = 0.58f;     // front/back wheel distance from centre
    public float rayStart = 0.3f;         // ray starts this far above the axle
    public float restDistance = 0.65f;    // ray hit distance when resting (rayStart + AxleHeight)
    public float rayLength = 0.9f;
    public float springK = 1500f;
    public float damper = 250f;

    const int BikeLayer = 2; // built-in "Ignore Raycast" layer
    const int GroundMask = ~(1 << BikeLayer);

    public BikeInput input;
    public bool Grounded { get; private set; }
    public Vector3 GroundNormal { get; private set; } = Vector3.up;
    public float ForwardSpeed { get; private set; }
    public bool Crashed => upsideTimer > 1.3f;

    Rigidbody rb;
    Transform visual;
    float upsideTimer;
    float lean;

    Vector3 Velocity
    {
#if UNITY_6000_0_OR_NEWER
        get => rb.linearVelocity; set => rb.linearVelocity = value;
#else
        get => rb.velocity; set => rb.velocity = value;
#endif
    }

    public float SpeedKmh => Velocity.magnitude * 3.6f;

    /// <summary>Creates the bike with physics, colliders and the rider model.</summary>
    public static BikeController Create(BikeInput input)
    {
        var go = new GameObject("Bike");
        go.layer = BikeLayer; // so the wheel rays don't hit the bike itself
        var rb = go.AddComponent<Rigidbody>();
        rb.mass = 80f;
#if UNITY_6000_0_OR_NEWER
        rb.linearDamping = 0.05f;
        rb.angularDamping = 2f;
#else
        rb.drag = 0.05f;
        rb.angularDrag = 2f;
#endif
        rb.interpolation = RigidbodyInterpolation.Interpolate;
        rb.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;

        var slippery = new PhysMat("BikeBody") { dynamicFriction = 0.1f, staticFriction = 0.1f, bounciness = 0.05f };
        var body = go.AddComponent<CapsuleCollider>();
        body.direction = 2;
        body.radius = 0.22f;
        body.height = 1.5f;
        body.center = new Vector3(0, 0.5f, 0);
        body.sharedMaterial = slippery;
        var rider = go.AddComponent<BoxCollider>();
        rider.center = new Vector3(0, 1.15f, 0f);
        rider.size = new Vector3(0.45f, 0.8f, 0.5f);
        rider.sharedMaterial = slippery;
        foreach (float z in new[] { -0.58f, 0.58f })
        {
            var w = go.AddComponent<SphereCollider>();
            w.center = new Vector3(0, 0, z);
            w.radius = 0.2f;
            w.sharedMaterial = slippery;
        }
        rb.centerOfMass = new Vector3(0, 0.15f, 0);

        var bike = go.AddComponent<BikeController>();
        bike.rb = rb;
        bike.input = input;
        bike.visual = new GameObject("Visual").transform;
        bike.visual.SetParent(go.transform, false);
        bike.LoadModel();
        return bike;
    }

    void Awake()
    {
        if (!rb) rb = GetComponent<Rigidbody>();
    }

    void LoadModel()
    {
        // Animated rider (spinning wheels, pedalling legs, body movement); falls back to the plain model.
        GameObject model = RiderRig.Build(visual, this);
        var glb = model == null ? Resources.Load<TextAsset>("RiderBike") : null; // Resources/RiderBike.bytes (the .glb file)
        if (glb != null)
        {
            try { model = MiniGlb.Load(glb.bytes, "RiderBikeModel", visual); }
            catch (System.Exception e) { Debug.LogWarning("Could not read RiderBike model: " + e.Message); }
        }
        if (model == null)
        {
            Debug.LogWarning("RiderBike model missing. Using a simple stand-in bike.");
            model = BuildFallbackBike(visual);
        }
        model.transform.localRotation = Quaternion.Euler(0, ModelYawOffset, 0);

        // Remove any colliders that came with the model; the bike has its own.
        foreach (var c in model.GetComponentsInChildren<Collider>()) Destroy(c);

        var renderers = model.GetComponentsInChildren<Renderer>();
        if (renderers.Length == 0) return;
        Bounds b = WorldBounds(renderers);
        float scale = ModelLength / Mathf.Max(0.01f, Mathf.Max(b.size.z, b.size.x));
        model.transform.localScale *= scale;
        b = WorldBounds(renderers);
        Vector3 local = visual.InverseTransformPoint(b.center);
        Vector3 minLocal = visual.InverseTransformPoint(b.min);
        model.transform.localPosition += new Vector3(-local.x, -AxleHeight - minLocal.y, -local.z);
        foreach (var r in renderers)
        {
            r.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.On;
            r.receiveShadows = true;
        }
    }

    static Bounds WorldBounds(Renderer[] rs)
    {
        Bounds b = rs[0].bounds;
        for (int i = 1; i < rs.Length; i++) b.Encapsulate(rs[i].bounds);
        return b;
    }

    static GameObject BuildFallbackBike(Transform parent)
    {
        var mb = new MeshBuilder();
        var rnd = new System.Random(3);
        Color tyre = new Color(0.1f, 0.1f, 0.1f), frame = new Color(0.2f, 0.75f, 0.2f), shirt = new Color(0.1f, 0.1f, 0.1f);
        foreach (float z in new[] { -0.58f, 0.58f })
            mb.Cylinder(new Vector3(-0.05f, 0, z), new Vector3(0.05f, 0, z), 0.32f, 0.32f, 12, tyre);
        mb.Box(new Vector3(0, 0.3f, 0), new Vector3(0.06f, 0.06f, 1.1f), Quaternion.Euler(-10, 0, 0), frame);
        mb.Box(new Vector3(0, 0.25f, 0.45f), new Vector3(0.06f, 0.7f, 0.06f), Quaternion.Euler(-20, 0, 0), frame);
        mb.Box(new Vector3(0, 0.62f, 0.5f), new Vector3(0.6f, 0.05f, 0.05f), Quaternion.identity, frame);
        mb.Blob(new Vector3(0, 1.0f, 0.05f), new Vector3(0.22f, 0.35f, 0.18f), shirt, rnd);
        mb.Blob(new Vector3(0, 1.45f, 0.2f), new Vector3(0.15f, 0.16f, 0.17f), frame, rnd);
        var go = new GameObject("FallbackBike");
        go.transform.SetParent(parent, false);
        go.AddComponent<MeshFilter>().sharedMesh = mb.ToMesh("FallbackBike");
        go.AddComponent<MeshRenderer>().sharedMaterial = JungleProps.Material;
        return go;
    }

    public void SetSurface(SeasonLook look)
    {
        gripMul = look.grip;
        brakeMul = look.brake;
        accelMul = look.accel;
    }

    /// <summary>Puts the bike back on the trail, standing still.</summary>
    public void Respawn(Vector3 position, Quaternion rotation)
    {
        rb.isKinematic = true;
        transform.SetPositionAndRotation(position, rotation);
        rb.position = position;
        rb.rotation = rotation;
        rb.isKinematic = false;
        Velocity = Vector3.zero;
        rb.angularVelocity = Vector3.zero;
        upsideTimer = 0f;
        lean = 0f;
    }

    public void SetFrozen(bool frozen)
    {
        if (frozen)
        {
            Velocity = Vector3.zero;
            rb.angularVelocity = Vector3.zero;
        }
        rb.isKinematic = frozen;
    }

    void FixedUpdate()
    {
        if (rb.isKinematic) return;

        // ---------- suspension ----------
        Vector3 up = transform.up;
        int hits = 0;
        Vector3 normalSum = Vector3.zero;
        for (int w = 0; w < 2; w++)
        {
            Vector3 origin = transform.TransformPoint(new Vector3(0, rayStart, w == 0 ? wheelOffset : -wheelOffset));
            if (Physics.Raycast(origin, -up, out RaycastHit hit, rayLength, GroundMask, QueryTriggerInteraction.Ignore))
            {
                hits++;
                normalSum += hit.normal;
                float spring = rb.mass * Physics.gravity.magnitude * 0.5f + springK * (restDistance - hit.distance);
                float vel = Vector3.Dot(rb.GetPointVelocity(origin), up);
                float force = Mathf.Max(0f, spring - damper * vel);
                rb.AddForceAtPosition(up * force, origin);
            }
        }
        Grounded = hits > 0;
        GroundNormal = Grounded ? normalSum.normalized : Vector3.up;

        // ---------- drive ----------
        float steer = input ? input.Steer : 0f;
        float thr = input ? input.Throttle : 0f;
        float brk = input ? input.Brake : 0f;

        Vector3 v = Velocity;
        ForwardSpeed = Vector3.Dot(v, transform.forward);
        if (Grounded)
        {
            Vector3 fwd = Vector3.ProjectOnPlane(transform.forward, GroundNormal).normalized;
            if (thr > 0f)
                rb.AddForce(fwd * acceleration * accelMul * thr * Mathf.Clamp01(1f - ForwardSpeed / maxSpeed), ForceMode.Acceleration);
            if (brk > 0f)
            {
                if (ForwardSpeed > 0.5f) rb.AddForce(-fwd * brakeDecel * brakeMul * brk, ForceMode.Acceleration);
                else if (ForwardSpeed > -reverseSpeed) rb.AddForce(-fwd * 3f * brk, ForceMode.Acceleration);
            }
            if (thr <= 0f && brk <= 0f)
                rb.AddForce(-fwd * ForwardSpeed * 0.25f, ForceMode.Acceleration); // rolling resistance

            Vector3 right = Vector3.ProjectOnPlane(transform.right, GroundNormal).normalized;
            float lateral = Vector3.Dot(v, right);
            rb.AddForce(-right * lateral * lateralGrip * gripMul, ForceMode.Acceleration);
        }

        // ---------- steering ----------
        float absSpeed = Mathf.Abs(ForwardSpeed);
        float speedFactor = Mathf.Clamp01(absSpeed / 3f) * Mathf.Lerp(1f, 0.55f, Mathf.Clamp01(absSpeed / maxSpeed));
        float dir = ForwardSpeed < -0.2f ? -1f : 1f;
        float targetYaw = steer * turnRate * Mathf.Deg2Rad * speedFactor * dir * (Grounded ? 1f : 0.3f);
        float yawRate = Vector3.Dot(rb.angularVelocity, up);
        rb.AddTorque(up * (targetYaw - yawRate) * 8f, ForceMode.Acceleration);

        // ---------- stay upright ----------
        Vector3 desiredUp = Grounded ? Vector3.Slerp(GroundNormal, Vector3.up, 0.3f) : Vector3.up;
        Vector3 axis = Vector3.Cross(up, desiredUp);
        Vector3 tilt = rb.angularVelocity - up * yawRate;
        float strength = Grounded ? 40f : 12f;
        float damping = Grounded ? 7f : 2.5f;
        rb.AddTorque(axis * strength - tilt * damping, ForceMode.Acceleration);

        // ---------- crash check ----------
        if (Vector3.Dot(transform.up, Vector3.up) < 0.3f) upsideTimer += Time.fixedDeltaTime;
        else upsideTimer = 0f;
    }

    void Update()
    {
        if (!visual) return;
        float steer = input ? input.Steer : 0f;
        float target = -steer * Mathf.Clamp01(Mathf.Abs(ForwardSpeed) / 6f) * 20f;
        lean = Mathf.Lerp(lean, target, Time.deltaTime * 6f);
        visual.localRotation = Quaternion.Euler(0f, 0f, lean);
    }
}
